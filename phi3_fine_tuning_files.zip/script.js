async function generateResponse() {
    const formData = new FormData();
    const prompt = document.getElementById('prompt').value;
    const temperature = document.getElementById('temperature').value;
    const maxTokens = document.getElementById('max_new_tokens').value;
    
    if (!prompt) {
        alert('Please enter a prompt');
        return;
    }
    
    // Hide previous results until we get a new response
    const responseElement = document.getElementById('responseText');
    document.getElementById('result').style.display = 'none';
    
    // Disable the generate button while processing
    const generateButton = document.querySelector('button');
    generateButton.disabled = true;
    
    formData.append('prompt', prompt);
    formData.append('temperature', temperature);
    formData.append('max_new_tokens', maxTokens);
    
    try {
        const response = await fetch('/generate', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        
        if (data.response) {
            responseElement.textContent = data.response;
            document.getElementById('result').style.display = 'block';
        } else if (data.error) {
            responseElement.textContent = 'Error: ' + data.error;
            document.getElementById('result').style.display = 'block';
        }
    } catch (error) {
        console.error('Error:', error);
        responseElement.textContent = 'Error: ' + error.message;
        document.getElementById('result').style.display = 'block';
    } finally {
        // Re-enable the generate button
        generateButton.disabled = false;
    }
}