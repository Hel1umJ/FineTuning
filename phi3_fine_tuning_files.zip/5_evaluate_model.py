"""
Phi-3-mini Model Evaluation Script (Step 5)

This script evaluates the fine-tuned Phi-3-mini model on the validation dataset,
calculating metrics such as perplexity, BLEU and ROUGE scores.

Usage:
    python 5_evaluate_model.py --model_path ./build/model --data_path ./build/data/val.json
"""

import os
import json
import torch
import argparse
import logging
import numpy as np
from tqdm import tqdm
from pathlib import Path
from PIL import Image
from typing import List, Dict, Union, Optional

from transformers import AutoTokenizer, AutoModelForCausalLM
from nltk.translate.bleu_score import sentence_bleu, SmoothingFunction
from rouge_score import rouge_scorer

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger(__name__)

def parse_args():
    parser = argparse.ArgumentParser(description="Evaluate fine-tuned Phi-3-mini model")
    
    # Model arguments
    parser.add_argument("--model_path", type=str, required=True,
                        help="Path to the fine-tuned model")
    parser.add_argument("--onnx", action="store_true",
                        help="Whether the model is in ONNX format")
    
    # Data arguments
    parser.add_argument("--data_path", type=str, required=True,
                        help="Path to the validation data file")
    
    # Evaluation settings
    parser.add_argument("--max_new_tokens", type=int, default=512,
                        help="Maximum number of tokens to generate")
    parser.add_argument("--batch_size", type=int, default=1,
                        help="Batch size for evaluation")
    parser.add_argument("--num_samples", type=int, default=None,
                        help="Number of samples to evaluate (None for all)")
    parser.add_argument("--output_path", type=str, default=None,
                        help="Path to save evaluation results (default: model_path/eval_results.json)")
    
    args = parser.parse_args()
    
    # Set default output path
    if args.output_path is None:
        args.output_path = os.path.join(args.model_path, "eval_results.json")
    
    return args

def prepare_prompt(prompt: str, processor) -> str:
    """
    Prepare the prompt for the model by ensuring it has the right format.
    """
    # Use processor chat template if available
    if hasattr(processor, "tokenizer") and hasattr(processor.tokenizer, "apply_chat_template"):
        # Get just the prompt part
        if "<|user|>" not in prompt and "<|system|>" not in prompt:
            prompt = f"<|user|>\n{prompt}<|end|>"
    
    return prompt

def generate_response(model, processor, prompt, max_new_tokens=512):
    """
    Generate a response from the model given a prompt.
    """
    # Prepare input prompt
    formatted_prompt = prepare_prompt(prompt, processor)
    
    # Process text
    try:
        # Format as chat
        messages = [{"role": "user", "content": formatted_prompt}]
        
        # Apply chat template
        chat_text = processor.tokenizer.apply_chat_template(
            messages, 
            tokenize=False, 
            add_generation_prompt=True
        )
        
        # Tokenize
        inputs = processor.tokenizer(
            chat_text,
            return_tensors="pt"
        )
        
        # Move inputs to the right device
        device = next(model.parameters()).device
        inputs = {k: v.to(device) for k, v in inputs.items()}
        
        # Generate response
        with torch.no_grad():
            output = model.generate(
                **inputs,
                max_new_tokens=max_new_tokens,
                do_sample=False
            )
            
        # Decode the generated output
        decoded_output = processor.tokenizer.decode(output[0], skip_special_tokens=True)
        
        # Extract just the assistant's response
        if "<|assistant|>" in decoded_output:
            response = decoded_output.split("<|assistant|>")[1].split("<|end|>")[0].strip()
        else:
            # Try to extract after the prompt
            try:
                response = decoded_output[len(formatted_prompt):].strip()
            except:
                response = decoded_output
        
        return response
    
    except Exception as e:
        logger.error(f"Error generating response: {e}")
        return "Error: Failed to generate response"

def calculate_perplexity(model, processor, input_text, target_text):
    """
    Calculate perplexity for text-only responses.
    Lower perplexity means the model is more confident in its predictions.
    """
    try:
        # For Phi-3 models, we'll use a simpler approach to avoid shape mismatches
        # Format as combined text for evaluation
        combined_text = f"{input_text} {target_text}"
        
        # Tokenize combined text
        tokens = processor.tokenizer(combined_text, return_tensors="pt")
        input_len = processor.tokenizer(input_text, return_tensors="pt")["input_ids"].shape[1]
        
        # Move to device
        device = next(model.parameters()).device
        tokens = {k: v.to(device) for k, v in tokens.items()}
        
        # Create labels by shifting input_ids right (standard causal LM approach)
        labels = tokens["input_ids"].clone()
        # Mask out the input portion for loss calculation
        labels[:, :input_len] = -100
        
        # Get loss
        with torch.no_grad():
            outputs = model(**tokens, labels=labels)
            
        # Perplexity = exp(loss)
        perplexity = torch.exp(outputs.loss).item()
        
        return perplexity
    except Exception as e:
        logger.error(f"Error calculating perplexity: {e}")
        return float("inf")

def calculate_text_metrics(prediction, reference):
    """
    Calculate various text metrics:
    - BLEU-1, BLEU-4
    - ROUGE-1, ROUGE-L
    """
    metrics = {}
    
    # BLEU scores
    if not prediction or not reference:
        metrics["bleu_1"] = 0.0
        metrics["bleu_4"] = 0.0
    else:
        smoothie = SmoothingFunction().method1
        prediction_tokens = prediction.lower().split()
        reference_tokens = [reference.lower().split()]
        
        try:
            metrics["bleu_1"] = sentence_bleu(reference_tokens, prediction_tokens, 
                                            weights=(1, 0, 0, 0), 
                                            smoothing_function=smoothie)
            
            metrics["bleu_4"] = sentence_bleu(reference_tokens, prediction_tokens, 
                                            weights=(0.25, 0.25, 0.25, 0.25), 
                                            smoothing_function=smoothie)
        except Exception as e:
            logger.warning(f"Error calculating BLEU: {e}")
            metrics["bleu_1"] = 0.0
            metrics["bleu_4"] = 0.0
    
    # ROUGE scores
    if not prediction or not reference:
        metrics["rouge_1"] = 0.0
        metrics["rouge_l"] = 0.0
    else:
        try:
            scorer = rouge_scorer.RougeScorer(['rouge1', 'rougeL'], use_stemmer=True)
            score = scorer.score(reference, prediction)
            metrics["rouge_1"] = score['rouge1'].fmeasure
            metrics["rouge_l"] = score['rougeL'].fmeasure
        except Exception as e:
            logger.warning(f"Error calculating ROUGE: {e}")
            metrics["rouge_1"] = 0.0
            metrics["rouge_l"] = 0.0
    
    return metrics

def evaluate_model(model, processor, data, max_new_tokens=512, num_samples=None):
    """
    Evaluate the model on the validation dataset.
    """
    results = []
    metrics_sum = {
        "bleu_1": 0.0,
        "bleu_4": 0.0,
        "rouge_1": 0.0,
        "rouge_l": 0.0,
        "perplexity": 0.0
    }
    
    # Limit samples if specified
    if num_samples is not None:
        data = data[:num_samples]
    
    for idx, sample in enumerate(tqdm(data, desc="Evaluating")):
        # Extract instruction, input and output
        instruction = sample.get("instruction", "")
        input_text = sample.get("input", "")
        output = sample.get("output", "")
        
        if not instruction:
            logger.warning(f"No instruction found in sample {idx}")
            continue
        
        # Combine instruction and input (if not empty)
        if input_text:
            prompt = f"{instruction}\n\n{input_text}"
        else:
            prompt = instruction
        
        # Generate prediction
        prediction = generate_response(model, processor, prompt, max_new_tokens)
        
        # Calculate text metrics
        text_metrics = calculate_text_metrics(prediction, output)
        
        # Calculate perplexity
        perplexity = calculate_perplexity(model, processor, prompt, output)
        
        # Accumulate metrics
        for metric, value in text_metrics.items():
            metrics_sum[metric] += value
        
        if perplexity is not None:
            metrics_sum["perplexity"] += perplexity
        
        # Store individual result
        result = {
            "id": str(idx),
            "prompt": prompt,
            "reference": output,
            "prediction": prediction,
            "metrics": {**text_metrics}
        }
        
        if perplexity is not None:
            result["metrics"]["perplexity"] = perplexity
        
        results.append(result)
    
    # Calculate average metrics
    sample_count = len(results)
    avg_metrics = {}
    for metric, total in metrics_sum.items():
        if metric == "perplexity":
            # Only count samples where perplexity was calculated
            valid_samples = sum(1 for r in results if "perplexity" in r["metrics"])
            avg_metrics[metric] = total / valid_samples if valid_samples > 0 else float("inf")
        else:
            avg_metrics[metric] = total / sample_count if sample_count > 0 else 0.0
    
    return {
        "results": results,
        "average_metrics": avg_metrics
    }

def main():
    # Parse arguments
    args = parse_args()
    
    # Load validation data
    logger.info(f"Loading validation data from {args.data_path}")
    with open(args.data_path, 'r') as f:
        validation_data = json.load(f)
    
    # Load model and processor
    logger.info(f"Loading model from {args.model_path}")
    
    if args.onnx:
        logger.error("ONNX evaluation is not supported yet - use the PyTorch model for evaluation")
        return
    
    # For Phi-3-mini, we use AutoTokenizer and AutoModelForCausalLM
    from transformers import AutoTokenizer, AutoModelForCausalLM
    
    # Processor for Phi-3-mini (just a wrapper around tokenizer for compatibility)
    class Phi3MiniProcessor:
        def __init__(self, tokenizer):
            self.tokenizer = tokenizer
    
    # Load tokenizer
    tokenizer = AutoTokenizer.from_pretrained(args.model_path, trust_remote_code=True)
    processor = Phi3MiniProcessor(tokenizer)
    
    # Load model
    model = AutoModelForCausalLM.from_pretrained(
        args.model_path,
        trust_remote_code=True,
        torch_dtype=torch.bfloat16,
        device_map="auto"
    )
    
    # Make sure model is in evaluation mode
    model.eval()
    
    # Evaluate model
    logger.info("Starting evaluation")
    eval_results = evaluate_model(
        model,
        processor,
        validation_data,
        max_new_tokens=args.max_new_tokens,
        num_samples=args.num_samples
    )
    
    # Print average metrics
    logger.info("Evaluation Results:")
    for metric, value in eval_results["average_metrics"].items():
        logger.info(f"  {metric}: {value:.4f}")
    
    # Save evaluation results
    logger.info(f"Saving evaluation results to {args.output_path}")
    os.makedirs(os.path.dirname(args.output_path), exist_ok=True)
    with open(args.output_path, 'w') as f:
        json.dump(eval_results, f, indent=2)
    
    logger.info("Evaluation complete!")

if __name__ == "__main__":
    # Try to import nltk and download required data
    try:
        import nltk
        nltk.download('punkt', quiet=True)
    except ImportError:
        logger.warning("NLTK not installed. Installing required packages...")
        import subprocess
        subprocess.check_call(["pip", "install", "nltk", "rouge-score"])
        import nltk
        nltk.download('punkt', quiet=True)
    
    main()