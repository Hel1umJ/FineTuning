"""
Phi-3-mini-4k-instruct Fine-tuning Data Preparation (Step 3)

This script prepares data for fine-tuning the Phi-3-mini model in the appropriate format.
It supports various data formats and can handle text inputs.

Usage:
    python 3_prepare_data.py --data_path ./sample_data --output_path ./build/data --format json
"""

import os
import json
import argparse
import logging
from pathlib import Path
from tqdm import tqdm

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger(__name__)

def parse_args():
    parser = argparse.ArgumentParser(description="Prepare data for Phi-3-mini fine-tuning")
    parser.add_argument(
        "--data_path",
        type=str,
        default="./sample_data",
        help="Path to the source data directory"
    )
    parser.add_argument(
        "--output_path",
        type=str,
        default="./build/data",
        help="Path to save the prepared data"
    )
    parser.add_argument(
        "--format",
        type=str,
        choices=["json", "csv", "auto"],
        default="auto",
        help="Format of the input data (json, csv, or auto for automatic detection)"
    )
    parser.add_argument(
        "--split",
        type=float,
        default=0.9,
        help="Train/validation split ratio"
    )
    return parser.parse_args()

def convert_to_phi_format(data_path, output_path, format_type="auto"):
    """
    Convert data to Phi-3-mini format
    
    Args:
        data_path: Path to source data
        output_path: Path to save formatted data
        format_type: Format of the input data
        
    Returns:
        Paths to the formatted train and validation JSON files
    """
    data_path = Path(data_path)
    
    # Auto-detect format if 'auto' is specified
    if format_type == "auto":
        if data_path.is_dir():
            # If it's a directory, look for data files
            json_files = list(data_path.glob("*.json"))
            csv_files = list(data_path.glob("*.csv"))
            
            if json_files:
                format_type = "json"
                # Use sample_data.json if available, otherwise use the first JSON file
                sample_data_path = data_path / "sample_data.json"
                data_path = sample_data_path if sample_data_path.exists() else json_files[0]
                logger.info(f"Using JSON file: {data_path}")
            elif csv_files:
                format_type = "csv"
                data_path = csv_files[0]
                logger.info(f"Using CSV file: {data_path}")
            else:
                # If no data files found, assume we're using the sample data structure
                format_type = "sample"
                logger.info("No data files found, using sample data structure")
        else:
            # If it's a file, determine type by extension
            if data_path.suffix.lower() == ".json":
                format_type = "json"
                logger.info(f"Using JSON file: {data_path}")
            elif data_path.suffix.lower() == ".csv":
                format_type = "csv"
                logger.info(f"Using CSV file: {data_path}")
            else:
                raise ValueError(f"Unrecognized file format: {data_path.suffix}")
    
    # Create output directories
    output_path = Path(output_path)
    os.makedirs(output_path, exist_ok=True)
    
    # Process based on format type
    formatted_data = []
    
    if format_type == "json":
        # Load JSON data
        logger.info(f"Loading JSON data from {data_path}")
        try:
            with open(data_path, 'r') as f:
                source_data = json.load(f)
            
            if isinstance(source_data, list):
                logger.info(f"Loaded {len(source_data)} items from JSON file")
                # Check first few items to debug structure
                if len(source_data) > 0:
                    logger.info(f"First item structure: {list(source_data[0].keys())}")
                else:
                    logger.warning("WARNING: Source data is empty! No items found in JSON file.")
            else:
                logger.error(f"ERROR: Expected JSON array, got {type(source_data)}")
        except json.JSONDecodeError as e:
            logger.error(f"Error decoding JSON: {e}")
            raise
        except Exception as e:
            logger.error(f"Error loading data: {e}")
            raise
            
        # Convert to format
        logger.info("Converting JSON data to Phi-3-mini format")
        for idx, item in enumerate(tqdm(source_data)):
            # Handle different JSON structures
            if "prompt" in item and "completion" in item:
                instruction = item.get("prompt", "")
                completion = item.get("completion", "")
                # For text-only inputs
                if item.get("image_path") is None:
                    formatted_item = {
                        "instruction": instruction,
                        "input": "",
                        "output": completion
                    }
                    formatted_data.append(formatted_item)
            # Handle other possible JSON structures
            elif "instruction" in item and "output" in item:
                # Already in the right format
                formatted_item = {
                    "instruction": item.get("instruction", ""),
                    "input": item.get("input", ""),
                    "output": item.get("output", "")
                }
                formatted_data.append(formatted_item)
            elif "text" in item and "answer" in item:
                formatted_item = {
                    "instruction": item.get("text", ""),
                    "input": "",
                    "output": item.get("answer", "")
                }
                formatted_data.append(formatted_item)
            # Add more conditions for other JSON formats as needed
    
    elif format_type == "csv":
        import pandas as pd
        # Load CSV data
        df = pd.read_csv(data_path)
        logger.info("Converting CSV data to Phi-3-mini format")
        
        # Convert each row to the desired format
        for idx, row in tqdm(df.iterrows(), total=len(df)):
            instruction = None
            input_text = ""
            output = None
            
            # Extract instruction
            for col in ["instruction", "prompt", "text", "question"]:
                if col in df.columns and pd.notna(row[col]):
                    instruction = row[col]
                    break
            
            # Extract input (if available)
            if "input" in df.columns and pd.notna(row["input"]):
                input_text = row["input"]
            
            # Extract output/completion
            for col in ["output", "completion", "answer", "response"]:
                if col in df.columns and pd.notna(row[col]):
                    output = row[col]
                    break
            
            # Skip if missing required fields
            if instruction is None or output is None:
                continue
            
            # Create formatted item
            formatted_item = {
                "instruction": instruction,
                "input": input_text,
                "output": output
            }
            formatted_data.append(formatted_item)
    
    elif format_type == "sample":
        # Create sample data
        logger.info("Creating sample data for fine-tuning")
        
        # Example sample data - replace with your own examples if needed
        sample_items = [
            {
                "instruction": "Explain the concept of machine learning.",
                "input": "",
                "output": "Machine learning is a field of artificial intelligence that uses statistical techniques to give computer systems the ability to 'learn' from data, without being explicitly programmed. The process involves algorithms and statistical models that computer systems use to perform a specific task effectively without using explicit instructions, relying on patterns and inference instead."
            },
            {
                "instruction": "Calculate the sum of these numbers:",
                "input": "23, 45, 67, 89, 12",
                "output": "The sum of the numbers 23, 45, 67, 89, and 12 is 236."
            },
            {
                "instruction": "Write a short poem about autumn.",
                "input": "",
                "output": "Golden leaves dance down,\nCrisp air whispers secrets old,\nAutumn embraces."
            }
        ]
        
        formatted_data.extend(sample_items)
    
    # Split into train and validation sets using the "n from every 10" approach
    import random
    
    # Set a seed for reproducibility
    random.seed(42)
    
    # Calculate how many samples to select from every 10 samples for validation
    # Ensure we always get at least 1 validation sample per chunk by using max(1, ...)
    validation_per_chunk = max(1, min(10, int(10 * (1 - args.split))))
    logger.info(f"Selecting {validation_per_chunk} samples from every 10 for validation (split ratio: {args.split})")
    
    train_data = []
    val_data = []
    
    # Process data in chunks of 10
    for i in range(0, len(formatted_data), 10):
        # Get a chunk of up to 10 items
        chunk = formatted_data[i:min(i+10, len(formatted_data))]
        
        # Debug current chunk
        logger.info(f"Processing chunk {i//10 + 1} with {len(chunk)} items")
        
        # Always take at least 1 validation sample if the chunk has items
        if len(chunk) > 0:
            # Force at least 1 validation sample per chunk if possible
            actual_val_count = max(1, min(validation_per_chunk, len(chunk)))
            logger.info(f"Taking {actual_val_count} validation samples from this chunk")
            
            # Randomly select indices for validation
            val_indices = set(random.sample(range(len(chunk)), actual_val_count))
            logger.info(f"Selected validation indices: {val_indices}")
            
            # Split the chunk into train and validation
            chunk_val_count = 0
            for j, item in enumerate(chunk):
                if j in val_indices:
                    val_data.append(item)
                    chunk_val_count += 1
                else:
                    train_data.append(item)
            
            logger.info(f"Added {chunk_val_count} items to validation from this chunk")
        else:
            # Empty chunk (shouldn't happen, but just in case)
            logger.warning(f"Empty chunk found at index {i}")
    
    logger.info(f"Split data: {len(train_data)} training samples, {len(val_data)} validation samples")
    logger.info(f"Actual split ratio: {len(train_data) / (len(train_data) + len(val_data)):.4f}")
    
    # Save train data
    train_path = output_path / "train.json"
    with open(train_path, 'w') as f:
        json.dump(train_data, f, indent=2)
    
    # Save validation data
    val_path = output_path / "val.json"
    with open(val_path, 'w') as f:
        json.dump(val_data, f, indent=2)
    
    logger.info(f"Data prepared successfully: {len(train_data)} training, {len(val_data)} validation samples")
    logger.info(f"Train data saved to: {train_path}")
    logger.info(f"Validation data saved to: {val_path}")
    
    return train_path, val_path

if __name__ == "__main__":
    args = parse_args()
    
    try:
        train_path, val_path = convert_to_phi_format(
            args.data_path,
            args.output_path,
            args.format
        )
        
        print(f"✅ Data preparation complete!")
        print(f"   Training data: {train_path}")
        print(f"   Validation data: {val_path}")
        
    except Exception as e:
        logger.error(f"Error during data preparation: {e}")
        raise