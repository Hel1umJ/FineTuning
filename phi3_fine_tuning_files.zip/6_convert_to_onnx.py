"""
Phi-3-mini ONNX Conversion Script (Step 6)

This script converts a fine-tuned Phi-3-mini model to ONNX format for efficient deployment.

Usage:
    python 6_convert_to_onnx.py --model_path ./build/model --output_path ./build/onnx_model
"""

import os
import torch
import logging
import argparse
from pathlib import Path

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger(__name__)

def parse_args():
    parser = argparse.ArgumentParser(description="Convert Phi-3-mini model to ONNX format")
    
    parser.add_argument("--model_path", type=str, required=True,
                        help="Path to the fine-tuned model directory")
    parser.add_argument("--base_model", type=str, default="microsoft/Phi-3-mini-4k-instruct",
                        help="Base model identifier (if needed)")
    parser.add_argument("--output_path", type=str, default="./build/onnx_model",
                        help="Path to save the ONNX model")
    parser.add_argument("--lora_weights", type=str, default=None,
                        help="Path to LoRA weights (if applicable)")
    parser.add_argument("--optimize", action="store_true",
                        help="Optimize the ONNX model after conversion")
    parser.add_argument("--fp16", action="store_true",
                        help="Export in fp16 precision")
    parser.add_argument("--batch_size", type=int, default=1,
                        help="Batch size for export")
    parser.add_argument("--sequence_length", type=int, default=512,
                        help="Sequence length for export")
    
    args = parser.parse_args()
    
    # Create output directory if it doesn't exist
    os.makedirs(args.output_path, exist_ok=True)
    
    return args

def convert_model_to_onnx(args):
    """Convert model to ONNX format"""
    from transformers import AutoModelForCausalLM, AutoTokenizer
    import gc  # For garbage collection to free up memory
    
    # Create a config.json file in the output directory to identify this as a transformers model
    import json
    os.makedirs(args.output_path, exist_ok=True)
    with open(os.path.join(args.output_path, "config.json"), "w") as f:
        json.dump({
            "library_name": "transformers",
            "model_type": "phi",
            "architectures": ["PhiForCausalLM"]
        }, f)
    
    # Set CUDA environment variables to force CUDA 12.8
    os.environ["CUDA_HOME"] = "/usr/local/cuda-12.8"
    os.environ["CUDA_PATH"] = "/usr/local/cuda-12.8" 
    os.environ["CUDA_ROOT"] = "/usr/local/cuda-12.8"
    
    # Force optimum version to 1.16.0
    try:
        import pkg_resources
        current_optimum_version = pkg_resources.get_distribution("optimum").version
        logger.info(f"Current optimum version: {current_optimum_version}")
        
        # Check for compatibility - version 1.16.0 is known to work
        if current_optimum_version != "1.16.0":
            logger.warning(f"Optimum version {current_optimum_version} might not be compatible with Phi-3 models")
            logger.warning("Consider installing optimum==1.16.0 for better compatibility")
    except:
        logger.warning("Could not check optimum version")
    
    # Load tokenizer
    try:
        tokenizer = AutoTokenizer.from_pretrained(args.model_path, trust_remote_code=True)
    except Exception as e:
        logger.warning(f"Could not load tokenizer from {args.model_path}: {e}")
        logger.info(f"Loading tokenizer from base model: {args.base_model}")
        tokenizer = AutoTokenizer.from_pretrained(args.base_model, trust_remote_code=True)
    
    # Set up model loading kwargs - with specific memory optimizations
    model_kwargs = {
        "trust_remote_code": True,
        "torch_dtype": torch.float16 if args.fp16 else torch.float32,
        "low_cpu_mem_usage": True,  # Optimize CPU memory usage
        "offload_folder": os.path.join(args.output_path, "tmp_offload"),  # For temporary offloading
    }
    
    # Create offload folder if it doesn't exist
    os.makedirs(os.path.join(args.output_path, "tmp_offload"), exist_ok=True)
    
    # Check if model is a LoRA model
    is_lora_model = os.path.exists(os.path.join(args.model_path, "adapter_config.json"))
    
    # Load model
    try:
        if is_lora_model and args.base_model:
            # If this is a LoRA model, load the base model first
            logger.info(f"Detected LoRA model. Loading base model from {args.base_model}")
            model = AutoModelForCausalLM.from_pretrained(
                args.base_model,
                **model_kwargs
            )
            
            # Then load LoRA adapters
            from peft import PeftModel
            logger.info(f"Loading LoRA weights from {args.model_path}")
            model = PeftModel.from_pretrained(model, args.model_path)
            
            # Merge weights
            logger.info("Merging LoRA weights with base model")
            model = model.merge_and_unload()
        else:
            model = AutoModelForCausalLM.from_pretrained(
                args.model_path,
                **model_kwargs
            )
    except Exception as e:
        logger.error(f"Error loading model: {e}")
        raise e
    
    # If LoRA weights are provided separately, merge them
    if args.lora_weights:
        from peft import PeftModel
        logger.info(f"Loading additional LoRA weights from {args.lora_weights}")
        model = PeftModel.from_pretrained(model, args.lora_weights)
        model = model.merge_and_unload()
    
    # Save the tokenizer
    tokenizer.save_pretrained(args.output_path)
    
    # Clean up memory before conversion
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    
    # Make sure model is in evaluation mode
    model.eval()
    
    try:
        logger.info("Starting ONNX conversion with direct torch.onnx.export...")
        
        # This is the clean, direct approach that doesn't rely on optimum library
        # which has known issues with Phi-3 models due to the missing split method
        
        # Create a simple wrapper module to avoid issues with the model's forward method
        class Phi3Wrapper(torch.nn.Module):
            def __init__(self, model):
                super().__init__()
                self.model = model
            
            def forward(self, input_ids, attention_mask):
                # Forward directly to the model with these inputs only
                outputs = self.model(input_ids=input_ids, attention_mask=attention_mask)
                return outputs.logits
        
        # Wrap the model
        wrapped_model = Phi3Wrapper(model)
        
        # Prepare export parameters
        model_path = Path(args.output_path)
        batch_size = args.batch_size
        seq_len = args.sequence_length
        
        # Create dummy inputs on appropriate device
        device = "cuda" if torch.cuda.is_available() else "cpu"
        input_ids = torch.ones(batch_size, seq_len, dtype=torch.long).to(device)
        attention_mask = torch.ones(batch_size, seq_len, dtype=torch.long).to(device)
        
        # Move model to the same device
        wrapped_model = wrapped_model.to(device)
        
        logger.info(f"Exporting model to ONNX using device: {device}")
        
        # Export to ONNX
        torch.onnx.export(
            wrapped_model,
            (input_ids, attention_mask),
            f=str(model_path / "model.onnx"),
            input_names=["input_ids", "attention_mask"],
            output_names=["logits"],
            dynamic_axes={
                "input_ids": {0: "batch_size", 1: "sequence_length"},
                "attention_mask": {0: "batch_size", 1: "sequence_length"},
                "logits": {0: "batch_size", 1: "sequence_length"}
            },
            opset_version=17,
            do_constant_folding=True,
            export_params=True
        )
        
        # Copy all necessary files for the tokenizer
        special_tokens_map_path = os.path.join(args.model_path, "special_tokens_map.json")
        tokenizer_config_path = os.path.join(args.model_path, "tokenizer_config.json")
        tokenizer_path = os.path.join(args.model_path, "tokenizer.json")
        
        if os.path.exists(special_tokens_map_path):
            import shutil
            shutil.copy2(special_tokens_map_path, os.path.join(args.output_path, "special_tokens_map.json"))
        
        if os.path.exists(tokenizer_config_path):
            import shutil
            shutil.copy2(tokenizer_config_path, os.path.join(args.output_path, "tokenizer_config.json"))
        
        if os.path.exists(tokenizer_path):
            import shutil
            shutil.copy2(tokenizer_path, os.path.join(args.output_path, "tokenizer.json"))
        
        # Try optimizing with onnxruntime if available and requested
        if args.optimize:
            try:
                logger.info("Optimizing ONNX model with onnxruntime...")
                import onnx
                from onnxruntime.transformers import optimizer
                
                # Load the ONNX model
                onnx_model = onnx.load(str(model_path / "model.onnx"))
                
                # Run optimization
                optimized_model = optimizer.optimize_model(
                    str(model_path / "model.onnx"),
                    model_type="gpt2",  # Use GPT2 as it's close enough
                    num_heads=12,  # This is a placeholder, the actual value isn't critical
                    hidden_size=768,  # This is a placeholder, the actual value isn't critical
                    optimization_level=99  # Maximum optimization
                )
                
                # Save the optimized model
                optimized_model.save_model_to_file(str(model_path / "model_optimized.onnx"))
                
                # If optimization succeeded, replace the original model
                import shutil
                shutil.move(str(model_path / "model_optimized.onnx"), str(model_path / "model.onnx"))
                logger.info("ONNX model optimized successfully")
            except Exception as e:
                logger.warning(f"ONNX optimization failed: {e}")
                logger.info("Continuing with unoptimized model")
        
        logger.info(f"ONNX model saved to {model_path}")
        return True
    
    except Exception as e:
        logger.error(f"Error during ONNX conversion: {e}")
        logger.error("ONNX conversion failed. You can still use the PyTorch model directly for inference.")
        return False

def main():
    args = parse_args()
    
    # Convert model to ONNX
    success = convert_model_to_onnx(args)
    
    if success:
        logger.info("✅ ONNX conversion completed successfully")
    else:
        logger.error("❌ ONNX conversion failed")

if __name__ == "__main__":
    main()