"""
Phi-3 Vision Auto-Processing Script (Step 1)

This script automatically processes unstructured text data
and uses an AI model to transform it into the structured format required for fine-tuning.

Usage:
    python 1_auto_process.py --input_path ./sample_data/DATA --output_path ./build/data/RAW_JSON --api_key your_api_key
"""

import os
import sys
import json
import argparse
import logging
import base64
import requests
import time
import traceback
import subprocess
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple
from PIL import Image
import io
import shutil

# Configure logging
logging.basicConfig(
    level=logging.DEBUG,  # Change to DEBUG for more detailed logs
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger(__name__)

def parse_args():
    parser = argparse.ArgumentParser(description="Auto-process unstructured data for Phi-3 Vision fine-tuning")
    parser.add_argument(
        "--input_path",
        type=str,
        required=True,
        help="Path to the folder containing unstructured data (documents, images, etc.)"
    )
    parser.add_argument(
        "--output_path",
        type=str,
        default="./build/data/RAW_JSON",
        help="Path to save the processed structured data"
    )
    parser.add_argument(
        "--api_key",
        type=str,
        default=None,
        help="API key for AI model endpoint (if using an external API)"
    )
    parser.add_argument(
        "--model",
        type=str,
        default="gpt-4o",
        help="Model to use for processing (gpt-4o, gpt-4-vision-preview, etc.)"
    )
    parser.add_argument(
        "--api_endpoint",
        type=str,
        default=None,
        help="API endpoint URL"
    )
    parser.add_argument(
        "--batch_size",
        type=int,
        default=2,
        help="Number of files to process in a single batch (smaller = more reliable processing)"
    )
    parser.add_argument(
        "--num_examples_per_doc",
        type=int,
        default=30,
        help="Approximate number of examples to generate per document"
    )
    parser.add_argument(
        "--include_images",
        action="store_true",
        help="Process and include images in the structured data"
    )
    parser.add_argument(
        "--include_text",
        action="store_true",
        help="Process and include text files in the structured data"
    )
    parser.add_argument(
        "--prompt_template",
        type=str,
        default=None,
        help="Custom prompt template file for data processing"
    )
    parser.add_argument(
        "--custom_categories",
        type=str,
        default=None,
        help="Path to JSON file with custom categories for processing"
    )
    return parser.parse_args()

def read_text_file(file_path: str) -> str:
    """Read text from a file with various encodings."""
    encodings = ['utf-8', 'latin-1', 'cp1252', 'iso-8859-1']
    
    for encoding in encodings:
        try:
            with open(file_path, 'r', encoding=encoding) as f:
                return f.read()
        except UnicodeDecodeError:
            continue
    
    logger.warning(f"Could not decode file {file_path} with any common encoding")
    return ""

def encode_image_to_base64(image_path: str) -> str:
    """Convert an image to a base64 string."""
    try:
        with open(image_path, "rb") as image_file:
            return base64.b64encode(image_file.read()).decode('utf-8')
    except Exception as e:
        logger.error(f"Error encoding image {image_path}: {e}")
        return ""

def get_file_extension(file_path: str) -> str:
    """Get the extension of a file."""
    return os.path.splitext(file_path)[1].lower()

def is_image_file(file_path: str) -> bool:
    """Check if a file is an image based on its extension."""
    image_extensions = ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp', '.tiff', '.svg']
    return get_file_extension(file_path) in image_extensions

def is_text_file(file_path: str) -> bool:
    """Check if a file is a text file based on its extension."""
    text_extensions = ['.txt', '.md', '.csv', '.json', '.xml', '.html', '.htm', '.log', '.yaml', '.yml', '.py', '.js', '.c', '.cpp', '.h', '.cs', '.java', '.sql']
    return get_file_extension(file_path) in text_extensions

def is_document_file(file_path: str) -> bool:
    """Check if a file is a document based on its extension."""
    doc_extensions = ['.doc', '.docx', '.pdf', '.ppt', '.pptx', '.xls', '.xlsx', '.odt', '.ods', '.odp', '.rtf']
    return get_file_extension(file_path) in doc_extensions

def extract_text_from_document(file_path: str) -> str:
    """Extract text from a document file with improved extraction for better content."""
    try:
        # Try to use textract if available (best extraction quality)
        import textract
        return textract.process(file_path).decode('utf-8')
    except ImportError:
        logger.warning("textract not installed, falling back to basic methods")
        
        ext = get_file_extension(file_path)
        
        # Handle PDF documents
        if ext == '.pdf':
            try:
                # Try to install PyPDF2 dynamically if not already installed
                try:
                    import PyPDF2
                except ImportError:
                    logger.warning("PyPDF2 not installed, attempting to install it...")
                    import subprocess
                    subprocess.check_call([sys.executable, "-m", "pip", "install", "PyPDF2"])
                    import PyPDF2
                
                # Process the PDF with detailed extraction
                with open(file_path, 'rb') as file:
                    reader = PyPDF2.PdfReader(file)
                    num_pages = len(reader.pages)
                    logger.info(f"Extracting text from PDF with {num_pages} pages")
                    
                    # Add document metadata at the beginning
                    text = f"DOCUMENT: {os.path.basename(file_path)}\n"
                    if reader.metadata:
                        for key, value in reader.metadata.items():
                            if value and str(value).strip():
                                text += f"{key}: {value}\n"
                    text += "\n\n"
                    
                    # Extract text from each page with page numbers
                    for page_num in range(num_pages):
                        page = reader.pages[page_num]
                        page_text = page.extract_text()
                        if page_text and page_text.strip():
                            text += f"PAGE {page_num + 1}:\n{page_text}\n\n"
                            
                    # Add document summary at the end
                    text += f"\nEND OF DOCUMENT: {os.path.basename(file_path)} - {num_pages} pages\n"
                    
                    return text
            except Exception as e:
                logger.error(f"Error extracting PDF text: {e}")
                # Try a backup extraction method
                try:
                    import PyPDF2
                    with open(file_path, 'rb') as file:
                        reader = PyPDF2.PdfReader(file)
                        text = ""
                        for page_num in range(len(reader.pages)):
                            text += reader.pages[page_num].extract_text()
                        return text
                except:
                    logger.warning("Failed to extract text with backup method")
                    return f"[Could not extract text from PDF: {os.path.basename(file_path)}]"
        
        # For other formats, show error
        return f"[Could not extract text from document: {os.path.basename(file_path)}]"

def process_file(file_path: str, args: argparse.Namespace) -> Dict:
    """Process a single file and return its metadata."""
    
    file_info = {
        "file_path": file_path,
        "file_name": os.path.basename(file_path),
        "file_type": get_file_extension(file_path),
        "content_type": None,
        "content": None,
        "size_bytes": os.path.getsize(file_path)
    }
    
    # Process based on file type
    if is_image_file(file_path):
        file_info["content_type"] = "image"
        if args.include_images:
            file_info["content"] = encode_image_to_base64(file_path)
    
    elif is_text_file(file_path):
        file_info["content_type"] = "text"
        if args.include_text:
            file_info["content"] = read_text_file(file_path)
    
    elif is_document_file(file_path):
        file_info["content_type"] = "document"
        if args.include_text:
            file_info["content"] = extract_text_from_document(file_path)
    
    else:
        file_info["content_type"] = "unknown"
    
    return file_info

def get_system_prompt(args: argparse.Namespace) -> str:
    """Get the system prompt for data processing."""
    
    if args.prompt_template and os.path.exists(args.prompt_template):
        with open(args.prompt_template, 'r') as f:
            template = f.read()
            # Replace placeholders in the template if they exist
            if "{args.num_examples_per_doc}" in template:
                template = template.replace("{args.num_examples_per_doc}", str(args.num_examples_per_doc))
            return template
    
    # Default system prompt
    system_prompt = f"""
You are an AI assistant that processes technical automotive documentation and converts it into a structured format for fine-tuning vision-language models. Your task is to analyze the provided content and create high-quality, TECHNICALLY DETAILED question-answer pairs about vehicle systems, components, specifications, and engineering data.

For each piece of content provided:
1. Focus on TECHNICAL SPECIFICATIONS, measurements, component names, and engineering details
2. Create diverse question-answer pairs that cover TECHNICAL CONTENT comprehensively (aim for approximately {args.num_examples_per_doc} examples per document)
3. For images, create detailed technical descriptions and specific questions about visible components
4. Format everything according to the required JSON structure

IMPORTANT FORMAT RULES:
- Create questions focusing on SPECIFIC TECHNICAL DETAILS like sensor types, voltages, dimensions, part numbers
- Questions should be direct about the subject matter, not about documents
- BAD: "What sensors does the AITO M9 have?"
- GOOD: "What specific millimeter-wave radar sensors are used in the AITO M9 Autopilot system?"
- BAD: "How does the battery system work?"
- GOOD: "What is the maximum voltage of the high-voltage battery system in the Lotus Eletre R+?"

ANSWER FORMAT REQUIREMENTS:
- Each answer must contain TWO PARTS separated by a blank line:
- PART 1: Direct, factual information with specific technical details (voltages, dimensions, part numbers, etc.)
- PART 2: A reference to the source document where this information can be found
- Example: "The AITO M9 uses Bosch MRR front millimeter-wave radar with 77GHz frequency and 120m detection range.

Reference: This information is detailed in the AITO M9 Autopilot Driving Analysis document, Section 4.2."

Generate about {args.num_examples_per_doc} pairs per document, covering the full range of technical information contained in each document. Focus on the most DETAILED technical specifications and engineering data in each document.

The output must follow this format EXACTLY:
[
  {{
    "prompt": "Question about the content? <image>",
    "image_path": "path/to/image.jpg",  # Only for images, set to null for text
    "completion": "Detailed answer that provides accurate information."
  }},
  ...more entries...
]

Each question should be detailed and specific, and include the <image> tag ONLY when the content is an image. For text content, omit the <image> tag and set image_path to null.

Ensure:
- Generate at least {args.num_examples_per_doc} diverse examples per document
- Include specific details from each document (names, procedures, measurements, specifications)
- Create examples that cover both high-level concepts and specific details
- Create some examples with very specific information that would only be known from reading the document
- Questions are diverse (what, how, why, identify, describe, explain, etc.)
- Answers are comprehensive yet concise
- Technical accuracy in descriptions
- No speculation beyond what's in the content
- No hallucination of details not present

This data will be used to fine-tune a vision-language model to recognize company equipment, understand operational procedures, and assist employees with accurate information.
"""

    # If custom categories are specified, add them to the prompt
    if args.custom_categories and os.path.exists(args.custom_categories):
        try:
            with open(args.custom_categories, 'r') as f:
                categories = json.load(f)
                
                categories_text = "Focus on creating questions in these specific categories:\n"
                for category in categories:
                    categories_text += f"- {category['name']}: {category['description']}\n"
                
                system_prompt += "\n\n" + categories_text
        except:
            pass
    
    return system_prompt

def clean_json_string(json_string):
    """Clean a JSON string to make it parseable, handling common issues including truncation."""
    if not json_string:
        return json_string
        
    # Step 1: Find the outermost array brackets if they exist
    if '[' in json_string and ']' in json_string:
        start_idx = json_string.find('[')
        end_idx = json_string.rfind(']') + 1
        if start_idx >= 0 and end_idx > start_idx:
            json_string = json_string[start_idx:end_idx]
    
    # Step 2: Replace invalid control characters
    import re
    # Remove all control characters except \n, \r, \t
    json_string = re.sub(r'[\x00-\x08\x0B\x0C\x0E-\x1F\x7F-\x9F]', '', json_string)
    
    # Step 3: Fix common JSON formatting issues
    # Fix trailing commas in arrays
    json_string = re.sub(r',\s*]', ']', json_string)
    # Fix trailing commas in objects
    json_string = re.sub(r',\s*}', '}', json_string)
    
    # Step 4: Handle truncated JSON
    # If we don't have a closing bracket but do have an opening one, it might be truncated
    if '[' in json_string and ']' not in json_string:
        logger.warning("JSON appears to be truncated (missing closing brackets)")
        # Extract complete objects where possible
        try:
            # Find all complete objects and build a valid array
            import json as json_module
            objects = []
            current_pos = json_string.find('{')
            
            while current_pos >= 0:
                # Try to find a complete object
                open_braces = 1
                in_string = False
                escape_next = False
                
                for i in range(current_pos + 1, len(json_string)):
                    char = json_string[i]
                    
                    # Handle string delimiters
                    if char == '"' and not escape_next:
                        in_string = not in_string
                    
                    # Handle escape character
                    if char == '\\' and not escape_next:
                        escape_next = True
                    else:
                        escape_next = False
                    
                    # Count braces if not in a string
                    if not in_string:
                        if char == '{':
                            open_braces += 1
                        elif char == '}':
                            open_braces -= 1
                            
                        # If we've closed all braces, we have a complete object
                        if open_braces == 0:
                            # Found a complete object
                            obj_str = json_string[current_pos:i+1]
                            try:
                                # Validate it's actually valid JSON
                                obj = json_module.loads(obj_str)
                                objects.append(obj)
                                logger.debug(f"Extracted complete object from truncated JSON")
                            except:
                                logger.debug(f"Found object structure but it's not valid JSON")
                            
                            # Move past this object
                            current_pos = json_string.find('{', i + 1)
                            break
                
                # If we didn't find a complete object or we're at the end
                if open_braces > 0 or i == len(json_string) - 1:
                    # No more complete objects
                    break
            
            # If we found any complete objects, create a valid JSON array
            if objects:
                logger.info(f"Recovered {len(objects)} complete objects from truncated JSON")
                return json_module.dumps(objects)
            else:
                logger.warning("Could not recover any complete objects from truncated JSON")
        except Exception as e:
            logger.error(f"Error while trying to recover from truncated JSON: {e}")
    
    # Step 5: Fix unclosed quotes
    # Count quotes to see if we have an odd number
    quote_count = json_string.count('"')
    if quote_count % 2 != 0:
        logger.debug("JSON has odd number of quotes, attempting to fix")
        # Find the last quote
        last_quote_idx = json_string.rfind('"')
        # Try to balance by adding a quote
        if last_quote_idx >= 0:
            json_string = json_string[:last_quote_idx+1] + '"' + json_string[last_quote_idx+1:]
    
    # Step 6: Try to ensure the JSON is valid array format
    # Check that it starts with [ and ends with ]
    json_string = json_string.strip()
    if not json_string.startswith('['):
        json_string = '[' + json_string
    if not json_string.endswith(']'):
        json_string = json_string + ']'
    
    # Step 7: Check for malformed records and try to fix them
    try:
        # Check for balanced braces
        opened_braces = 0
        opened_brackets = 0
        in_string = False
        escape_next = False
        
        for i, char in enumerate(json_string):
            # Handle string delimiters
            if char == '"' and not escape_next:
                in_string = not in_string
            
            # Handle escape character
            if char == '\\' and not escape_next:
                escape_next = True
            else:
                escape_next = False
            
            # Count braces and brackets if not in a string
            if not in_string:
                if char == '{':
                    opened_braces += 1
                elif char == '}':
                    opened_braces -= 1
                elif char == '[':
                    opened_brackets += 1
                elif char == ']':
                    opened_brackets -= 1
        
        # Fix unbalanced braces
        if opened_braces != 0:
            logger.warning(f"JSON has unbalanced braces ({opened_braces}), attempting repair")
            if opened_braces > 0:  # We have more open braces than closing
                json_string = json_string[:-1] + ('}'*opened_braces) + ']'
            else:  # We have more closing braces than opening
                json_string = '[' + ('{' * abs(opened_braces)) + json_string[1:]
        
        # Fix unbalanced brackets
        if opened_brackets != 0:
            logger.warning(f"JSON has unbalanced brackets ({opened_brackets}), attempting repair")
            if opened_brackets > 0:  # We have more open brackets than closing
                json_string = json_string + (']'*opened_brackets)
            else:  # We have more closing brackets than opening
                json_string = '['*abs(opened_brackets) + json_string
    
    except Exception as e:
        logger.error(f"Error while trying to balance JSON structure: {e}")
    
    # Step 8: Fix trailing/malformed content
    # Sometimes we have things like text, comments or control characters at the end
    try:
        # Try to find the last valid closing bracket or brace
        last_valid_char = max(json_string.rfind(']'), json_string.rfind('}'))
        if last_valid_char > 0 and last_valid_char < len(json_string) - 1:
            # Truncate anything after the last valid character
            json_string = json_string[:last_valid_char+1]
            # Make sure we end with a closing bracket for the array
            if not json_string.endswith(']'):
                json_string = json_string + ']'
            logger.debug("Removed trailing content after JSON structure")
    except:
        pass
    
    # Step 9: Repair unterminated strings
    try:
        # Check if we can parse it
        import json as json_module
        json_module.loads(json_string)
    except json_module.JSONDecodeError as e:
        # If we have an unterminated string error, try to fix it
        error_msg = str(e)
        if "Unterminated string" in error_msg or "Invalid control character" in error_msg:
            logger.warning(f"JSON error: {error_msg}, attempting string repair")
            
            # Extract the position from error message (varies by Python version)
            try:
                # Extract position information from error message
                import re
                pos_match = re.search(r'char (\d+)', error_msg)
                if pos_match:
                    pos = int(pos_match.group(1))
                    
                    # Try to fix the string at this position
                    # Find the start of the problematic string
                    in_string = False
                    string_start = 0
                    
                    for i in range(pos):
                        if json_string[i] == '"' and (i == 0 or json_string[i-1] != '\\'):
                            if not in_string:
                                string_start = i
                            in_string = not in_string
                    
                    # If we're in a string at the error position, terminate it
                    if in_string:
                        # Insert a quote at the position
                        json_string = json_string[:pos] + '"' + json_string[pos:]
                        logger.debug(f"Fixed unterminated string at position {pos}")
            except Exception as repair_error:
                logger.error(f"Error during string repair: {repair_error}")
    
    return json_string

def chunk_large_text(text, max_chunk_size=2000):
    """Split very large text into manageable chunks for processing.
    
    Uses a smaller default chunk size (2000) to prevent response truncation issues.
    """
    if not text or len(text) <= max_chunk_size:
        return [text]
        
    # Try to split at natural boundaries like paragraphs
    chunks = []
    current_chunk = ""
    
    # Split by double newlines (paragraphs)
    paragraphs = text.split("\n\n")
    
    for para in paragraphs:
        # If adding this paragraph would exceed the limit, store current chunk and start a new one
        if len(current_chunk) + len(para) + 2 > max_chunk_size and current_chunk:
            chunks.append(current_chunk)
            current_chunk = para
        else:
            if current_chunk:
                current_chunk += "\n\n" + para
            else:
                current_chunk = para
    
    # Add the last chunk if not empty
    if current_chunk:
        chunks.append(current_chunk)
        
    # If any chunk is still too large, split it by sentences
    final_chunks = []
    for chunk in chunks:
        if len(chunk) <= max_chunk_size:
            final_chunks.append(chunk)
        else:
            # Split by sentence endings (., !, ?)
            sentences = []
            current_sent = ""
            for char in chunk:
                current_sent += char
                if char in ['.', '!', '?'] and len(current_sent) > 10:
                    sentences.append(current_sent)
                    current_sent = ""
            
            if current_sent:
                sentences.append(current_sent)
                
            current_chunk = ""
            for sent in sentences:
                if len(current_chunk) + len(sent) > max_chunk_size and current_chunk:
                    final_chunks.append(current_chunk)
                    current_chunk = sent
                else:
                    current_chunk += sent
                    
            if current_chunk:
                final_chunks.append(current_chunk)
    
    # Ensure no chunk is too large by force-splitting if necessary
    safer_chunks = []
    for chunk in final_chunks:
        if len(chunk) > max_chunk_size:
            # Force split into smaller pieces if still too large
            for i in range(0, len(chunk), max_chunk_size):
                safer_chunks.append(chunk[i:i+max_chunk_size])
        else:
            safer_chunks.append(chunk)
    
    return safer_chunks

def call_ai_api(content_batch: List[Dict], args: argparse.Namespace) -> str:
    """Call AI API to process a batch of content with robust anti-hanging measures."""
    
    # Watchdog file to track API calls progress
    watchdog_file = "./build/logs/api_watchdog.log"
    os.makedirs(os.path.dirname(watchdog_file), exist_ok=True)
    
    # Create or update watchdog with latest activity
    with open(watchdog_file, 'a') as f:
        f.write(f"\n--- API CALL STARTED: {time.strftime('%Y-%m-%d %H:%M:%S')} ---\n")
        batch_info = ", ".join([f"{content['file_name']}" for content in content_batch])
        f.write(f"Processing files: {batch_info}\n")
    
    # Log a heartbeat to indicate processing is active
    logger.info(f"HEARTBEAT: Starting API call for {len(content_batch)} files at {time.strftime('%H:%M:%S')}")
    
    system_prompt = get_system_prompt(args)
    
    # Prepare content for the API request
    content_text = "Here are the files to process:\n\n"
    
    for idx, content in enumerate(content_batch):
        content_text += f"FILE {idx+1}: {content['file_name']} (Type: {content['content_type']})\n"
        
        if content['content_type'] == "image":
            content_text += "[Image file - analyze the image provided in the message]\n\n"
        else:
            # Get full content and chunk it if needed
            full_content = content.get('content', '')
            
            # For display in log, truncate
            if full_content and len(full_content) > 1000:
                display_content = full_content[:1000] + "...[content truncated for display]"
            else:
                display_content = full_content
                
            content_text += f"{display_content}\n\n"
            
            # Store actual content for processing in chunks if needed
            if full_content and len(full_content) > 8000:
                logger.info(f"Content for {content['file_name']} is large ({len(full_content)} chars), processing in chunks")
                content['content_chunks'] = chunk_large_text(full_content)
            else:
                content['content_chunks'] = [full_content] if full_content else []
    
    # Add specific instructions
    content_text += """
Create TECHNICALLY DETAILED question-answer pairs from these automotive documents for fine-tuning a vision-language model.

REMEMBER: 
- Focus on SPECIFIC TECHNICAL DETAILS like sensor types, voltages, dimensions, part numbers, etc.
- Questions should seek detailed technical information, not general descriptions
- Answers must include PRECISE specifications, measurements, component names, part numbers
- EACH ANSWER MUST have TWO PARTS: 
  1. Direct technical information with specific details
  2. A reference to the source document where this information can be found

EXAMPLE ANSWER FORMAT:
"The high-voltage battery system in the Lotus Eletre R+ operates at a maximum of 723V DC with a capacity of 112 kWh provided by LG Energy Solution prismatic cells arranged in 12 modules.

Reference: This information is found in the Lotus Eletre R+ HV System Analysis document, Section 3.1."

Return ONLY the JSON array with your generated entries. 
Do not include any explanation, introduction, or notes before or after the JSON array.
"""

    # Prepare the request based on the API provider
    if "openai" in args.api_endpoint or "azure" in args.api_endpoint:
        is_azure = "azure" in args.api_endpoint
        logger.debug(f"Using {'Azure' if is_azure else 'OpenAI'} API format")
        
        # Common messages format for both APIs
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": content_text}
        ]
        
        # For multimodal capabilities with OpenAI (not Azure)
        if not is_azure and any(content['content_type'] == "image" for content in content_batch):
            # Use the multimodal format for OpenAI
            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": []}
            ]
            
            # Add content to the message
            user_message = {"type": "text", "text": content_text}
            messages[1]["content"].append(user_message)
            
            # Add images to the message if present
            for content in content_batch:
                if content['content_type'] == "image" and content.get('content'):
                    image_message = {
                        "type": "image_url",
                        "image_url": {"url": f"data:image/jpeg;base64,{content['content']}"}
                    }
                    messages[1]["content"].append(image_message)
        
        # Common payload for both APIs
        payload = {
            "messages": messages,
            "temperature": 0.2,
            "max_tokens": 2500  # Reduced to avoid truncation issues
        }
        
        if is_azure:
            # For Azure, we don't need model parameter, but might need to handle the api version
            # Additional Azure-specific settings
            logger.debug(f"Azure endpoint: {args.api_endpoint}")
            # Do not add any additional parameters for Azure - they should be in the URL
        else:
            # For OpenAI, we need to specify the model
            payload["model"] = args.model
        
        headers = {
            "Content-Type": "application/json"
        }
        
        # Different authorization header format for Azure OpenAI vs regular OpenAI
        if is_azure:
            headers["api-key"] = args.api_key
            logger.debug(f"Using Azure OpenAI API with endpoint: {args.api_endpoint}")
            logger.debug(f"Azure API key (first 5 chars): {args.api_key[:5]}...")
        else:
            headers["Authorization"] = f"Bearer {args.api_key}"
            logger.debug(f"Using standard OpenAI API with endpoint: {args.api_endpoint}")
            logger.debug(f"OpenAI API key (first 5 chars): {args.api_key[:5]}...")
        
    # OpenAI/Azure API is the only supported option now
        
    else:
        # Generic API call format
        payload = {
            "model": args.model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": content_text}
            ],
            "images": [content.get('content') for content in content_batch 
                      if content['content_type'] == "image" and content.get('content')],
            "temperature": 0.2,
            "max_tokens": 2500  # Reduced to avoid truncation issues
        }
        
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {args.api_key}"
        }
    
    # Update watchdog with request preparation completion
    with open(watchdog_file, 'a') as f:
        f.write(f"Request prepared at: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
    
    # Log the API request attempt with timestamps
    api_start_time = time.time()
    logger.info(f"HEARTBEAT: Making API request at {time.strftime('%H:%M:%S')}")
    
    # Update watchdog with request start
    with open(watchdog_file, 'a') as f:
        f.write(f"API request started at: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
    
    # Make API request with timeout to prevent hanging
    try:
        logger.debug(f"Making API request to: {args.api_endpoint}")
        logger.debug(f"Payload structure: {list(payload.keys())}")
        
        # Set a timeout of 60 seconds to prevent hanging on API requests
        # This includes both connection and read timeouts
        response = requests.post(
            args.api_endpoint, 
            headers=headers, 
            json=payload,
            timeout=(10, 120)  # 10s connect timeout, 120s read timeout
        )
        
        # Log completion and time taken
        api_duration = time.time() - api_start_time
        logger.info(f"HEARTBEAT: API request completed in {api_duration:.2f} seconds with status {response.status_code}")
        
        # Update watchdog with request completion
        with open(watchdog_file, 'a') as f:
            f.write(f"API request completed at: {time.strftime('%Y-%m-%d %H:%M:%S')} (took {api_duration:.2f} seconds)\n")
            f.write(f"Status code: {response.status_code}\n")
        
        logger.debug(f"API response status code: {response.status_code}")
        
        # Log HTTP errors if any
        if response.status_code >= 400:
            logger.error(f"API error: HTTP {response.status_code}")
            logger.error(f"Response content: {response.text}")
            
            # Record error in watchdog
            with open(watchdog_file, 'a') as f:
                f.write(f"API ERROR: HTTP {response.status_code}\n")
                f.write(f"Error response: {response.text[:500]}...\n")
                f.write(f"--- API CALL FAILED (HTTP ERROR) ---\n\n")
                
            return None
            
        response.raise_for_status()
        
        # Start parsing the response
        parsing_start_time = time.time()
        logger.info(f"HEARTBEAT: Parsing API response at {time.strftime('%H:%M:%S')}")
        
        # Update watchdog 
        with open(watchdog_file, 'a') as f:
            f.write(f"Parsing response started at: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
        
        response_json = response.json()
        
        logger.debug(f"API response keys: {list(response_json.keys())}")
        
        # Extract text from different API formats
        if "openai" in args.api_endpoint or "azure" in args.api_endpoint:
            if "choices" not in response_json or not response_json.get("choices"):
                logger.error(f"Missing 'choices' in API response: {response_json}")
                
                # Record error in watchdog
                with open(watchdog_file, 'a') as f:
                    f.write(f"ERROR: Missing 'choices' in API response\n")
                    f.write(f"--- API CALL FAILED (INVALID RESPONSE) ---\n\n")
                    
                return None
                
            result = response_json.get("choices", [{}])[0].get("message", {}).get("content", "")
            logger.debug(f"Extracted text length: {len(result)} characters")
            
            if not result:
                logger.error("Failed to extract content from response")
                logger.error(f"Response JSON: {response_json}")
                
                # Record error in watchdog
                with open(watchdog_file, 'a') as f:
                    f.write(f"ERROR: Failed to extract content from response\n")
                    f.write(f"--- API CALL FAILED (EMPTY CONTENT) ---\n\n")
                    
                return None
        else:
            result = response_json.get("response", "")
        
        # Log completion of response parsing
        parsing_duration = time.time() - parsing_start_time
        total_duration = time.time() - api_start_time
        logger.info(f"HEARTBEAT: API call completed successfully in {total_duration:.2f} seconds")
        
        # Update watchdog with successful completion
        with open(watchdog_file, 'a') as f:
            f.write(f"API call completed successfully at: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"Total duration: {total_duration:.2f} seconds\n")
            f.write(f"Response size: {len(result)} characters\n")
            f.write(f"--- API CALL FINISHED ---\n\n")
        
        return result
    
    except requests.exceptions.Timeout:
        # Handle request timeout
        logger.error(f"API request timed out after 120 seconds")
        
        # Record timeout in watchdog
        with open(watchdog_file, 'a') as f:
            f.write(f"ERROR: API request timed out after 120 seconds\n")
            f.write(f"--- API CALL FAILED (TIMEOUT) ---\n\n")
        
        return None
    
    except requests.exceptions.ConnectionError as ce:
        # Handle connection errors
        logger.error(f"Connection error during API call: {ce}")
        
        # Record error in watchdog
        with open(watchdog_file, 'a') as f:
            f.write(f"ERROR: Connection error - {str(ce)[:500]}\n")
            f.write(f"--- API CALL FAILED (CONNECTION) ---\n\n")
        
        return None
        
    except json.JSONDecodeError as je:
        # Handle JSON parse errors in the response
        logger.error(f"JSON decode error in API response: {je}")
        
        # Record error in watchdog
        with open(watchdog_file, 'a') as f:
            f.write(f"ERROR: JSON decode error - {str(je)}\n")
            f.write(f"--- API CALL FAILED (JSON ERROR) ---\n\n")
            
        return None
    
    except Exception as e:
        # Handle other errors
        logger.error(f"API call error: {e}")
        
        # Record error in watchdog
        with open(watchdog_file, 'a') as f:
            f.write(f"ERROR: API call failed - {str(e)[:500]}\n")
            f.write(f"--- API CALL FAILED (GENERAL ERROR) ---\n\n")
            
        return None

def ask_ai_to_fix_json(bad_json: str, args: argparse.Namespace) -> str:
    """Ask AI to fix malformed JSON"""
    
    system_prompt = """You are a JSON validation and repair specialist. 
Your task is to fix malformed JSON that was generated by another AI.
The JSON should be an array of question-answer pairs in this format:

[
  {
    "prompt": "What is X?",
    "image_path": null,
    "completion": "X is Y.\n\nReference: This information is found in Document Z, Section 1.2."
  },
  ...
]

Common errors include:
1. Missing closing brackets or braces
2. Missing closing quotes
3. Missing commas between objects
4. Improperly formatted text (e.g., newlines inside strings without proper escaping)
5. Unterminated strings
6. JSON that is not a valid array of objects

Return ONLY the fixed JSON with no explanations or comments. DO NOT add any content or information.
Make sure the JSON is properly terminated with closing brackets.
"""

    user_prompt = f"""Fix this malformed JSON:

```
{bad_json}
```

Common issues: This JSON is likely incomplete or has formatting errors. Please fix the issues and return a valid JSON array.
"""

    # Use the same API settings as the main process
    if "openai" in args.api_endpoint or "azure" in args.api_endpoint:
        is_azure = "azure" in args.api_endpoint
        
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]
        
        payload = {
            "messages": messages,
            "temperature": 0.1,  # Use low temperature for deterministic repair
            "max_tokens": 4000
        }
        
        if not is_azure:
            payload["model"] = args.model
        
        headers = {
            "Content-Type": "application/json"
        }
        
        if is_azure:
            headers["api-key"] = args.api_key
        else:
            headers["Authorization"] = f"Bearer {args.api_key}"
    
    # Only OpenAI/Azure APIs are supported now
    
    else:
        payload = {
            "model": args.model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            "temperature": 0.1,
            "max_tokens": 4000
        }
        
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {args.api_key}"
        }
    
    # Make API request
    try:
        logger.debug(f"Making JSON repair request to: {args.api_endpoint}")
        
        response = requests.post(args.api_endpoint, headers=headers, json=payload)
        
        logger.debug(f"API response status code: {response.status_code}")
        
        if response.status_code >= 400:
            logger.error(f"API error: HTTP {response.status_code}")
            logger.error(f"Response content: {response.text}")
            return None
            
        response.raise_for_status()
        response_json = response.json()
        
        # Extract text from different API formats
        if "openai" in args.api_endpoint or "azure" in args.api_endpoint:
            if "choices" not in response_json or not response_json.get("choices"):
                logger.error(f"Missing 'choices' in API response: {response_json}")
                return None
                
            result = response_json.get("choices", [{}])[0].get("message", {}).get("content", "")
        # Only OpenAI/Azure APIs are supported now
        else:
            result = response_json.get("response", "")
            
        # Clean up the result
        if result:
            # Remove any markdown code blocks
            if "```json" in result:
                result = result.split("```json")[1].split("```")[0].strip()
            elif "```" in result:
                result = result.split("```")[1].split("```")[0].strip()
            
        return result
    
    except Exception as e:
        logger.error(f"API call error during JSON repair: {e}")
        return None

def extract_and_parse_json(result_text, args=None, max_repair_attempts=2):
    """Extract JSON from API result text and parse it with repair attempts."""
    if not result_text:
        return None
        
    # Try to extract JSON from the result if it's wrapped in markdown code blocks
    if "```json" in result_text:
        logger.debug("Found ```json marker in response")
        result_text = result_text.split("```json")[1].split("```")[0].strip()
    elif "```" in result_text:
        logger.debug("Found ``` marker in response")
        result_text = result_text.split("```")[1].split("```")[0].strip()
    
    # Extract JSON array if present
    if '[' in result_text and ']' in result_text:
        first_bracket = result_text.find('[')
        last_bracket = result_text.rfind(']')
        if first_bracket > 0 or last_bracket < len(result_text) - 1:
            logger.debug(f"Trimming result to extract JSON array from positions {first_bracket} to {last_bracket + 1}")
            result_text = result_text[first_bracket:last_bracket + 1]
    
    # Clean the JSON string
    result_text = clean_json_string(result_text)
    
    # Try parsing the JSON
    try:
        json_data = json.loads(result_text)
        return json_data
    except json.JSONDecodeError as e:
        logger.error(f"JSON decode error: {e}")
        logger.debug(f"Failed JSON (first 200 chars): {result_text[:200]}...")
        
        # If args is provided, try to repair JSON with AI
        if args and max_repair_attempts > 0:
            logger.info(f"Attempting AI-based JSON repair (attempt {3-max_repair_attempts}/2)")
            
            # Save the failed JSON in build/logs directory for debugging
            logs_dir = Path("./build/logs")
            logs_dir.mkdir(parents=True, exist_ok=True)
            debug_file = logs_dir / f"debug_failed_json_{int(time.time())}.txt"
            with open(debug_file, 'w') as f:
                f.write(result_text)
            logger.debug(f"Saved failed JSON to {debug_file}")
            
            # Ask AI to fix the JSON
            fixed_json = ask_ai_to_fix_json(result_text, args)
            if fixed_json:
                logger.info("AI returned a fixed JSON. Trying to parse it...")
                try:
                    json_data = json.loads(fixed_json)
                    logger.info("Successfully parsed the fixed JSON!")
                    return json_data
                except json.JSONDecodeError as repair_error:
                    logger.warning(f"AI repair attempt failed: {repair_error}")
                    # Recursive call with one fewer attempt
                    return extract_and_parse_json(fixed_json, args, max_repair_attempts - 1)
            else:
                logger.warning("AI failed to repair the JSON")
        
        return None

def process_files_with_ai(file_info_list: List[Dict], args: argparse.Namespace) -> List[Dict]:
    """Process files with AI API and return structured data with robust anti-hanging measures."""
    
    structured_data = []
    
    # Create a watchdog file specifically for this function
    watchdog_file = "./build/logs/file_processing_watchdog.log"
    os.makedirs(os.path.dirname(watchdog_file), exist_ok=True)
    
    # Start watchdog
    with open(watchdog_file, 'a') as f:
        f.write(f"\n=== FILE PROCESSING STARTED: {time.strftime('%Y-%m-%d %H:%M:%S')} ===\n")
        f.write(f"Files to process: {len(file_info_list)}\n")
        f.write(f"Batch size: {args.batch_size}\n")
    
    # Process files in batches
    for i in range(0, len(file_info_list), args.batch_size):
        batch = file_info_list[i:i+args.batch_size]
        batch_start_time = time.time()
        
        # Log batch start with file names
        batch_files = ", ".join([file['file_name'] for file in batch])
        logger.info(f"HEARTBEAT: Processing batch {i//args.batch_size + 1}/{(len(file_info_list) + args.batch_size - 1) // args.batch_size} ({len(batch)} files: {batch_files}) at {time.strftime('%H:%M:%S')}")
        
        with open(watchdog_file, 'a') as f:
            f.write(f"Batch {i//args.batch_size + 1} started at: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"Files in batch: {batch_files}\n")
        
        # Set a maximum time for processing a batch (15 minutes per file seems reasonable)
        max_batch_time = 15 * 60 * len(batch)  # 15 minutes per file
        
        # For reliability, always process 1 file at a time
        for file_idx, file in enumerate(batch):
            file_start_time = time.time()
            logger.info(f"HEARTBEAT: Processing file {file_idx+1}/{len(batch)}: {file['file_name']} at {time.strftime('%H:%M:%S')}")
            
            with open(watchdog_file, 'a') as f:
                f.write(f"File {file_idx+1}/{len(batch)} ({file['file_name']}) started at: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
            
            # Set a timeout for processing each file (10 minutes)
            file_timeout = 600  # 10 minutes per file
            
            # Check if file has chunks to process separately
            if 'content_chunks' in file and len(file.get('content_chunks', [])) > 1:
                logger.info(f"File has {len(file['content_chunks'])} chunks and will be processed in parts")
                with open(watchdog_file, 'a') as f:
                    f.write(f"File has {len(file['content_chunks'])} chunks to process\n")
                
                # Process all chunks of the file
                file_results = []
                all_chunks = file.get('content_chunks', [])
                original_content = file.get('content', '')
                
                # Calculate time per chunk based on file timeout
                chunk_timeout = max(60, file_timeout // len(all_chunks))  # At least 60 seconds per chunk
                
                # For long documents, we'll process all chunks to get more examples
                for chunk_idx, chunk in enumerate(all_chunks):
                    chunk_start_time = time.time()
                    
                    # Replace content with current chunk
                    file['content'] = chunk
                    
                    logger.info(f"HEARTBEAT: Processing chunk {chunk_idx+1}/{len(all_chunks)} ({len(chunk)} chars) at {time.strftime('%H:%M:%S')}")
                    with open(watchdog_file, 'a') as f:
                        f.write(f"Chunk {chunk_idx+1}/{len(all_chunks)} started at: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
                    
                    # Process this chunk with retry logic and timeout check
                    max_retries = 2
                    for retry in range(max_retries + 1):
                        # Check if we're approaching the chunk timeout
                        if time.time() - chunk_start_time > chunk_timeout:
                            logger.warning(f"Chunk {chunk_idx+1} approaching timeout ({chunk_timeout} seconds), skipping to next chunk")
                            with open(watchdog_file, 'a') as f:
                                f.write(f"TIMEOUT: Chunk {chunk_idx+1} exceeded {chunk_timeout} seconds, skipping\n")
                            break
                            
                        if retry > 0:
                            logger.info(f"Retry {retry}/{max_retries} for chunk {chunk_idx+1}")
                        
                        # Try to process current chunk
                        try:
                            # Set a hard timeout for this API call
                            result = call_ai_api([file], args)
                            
                            if result:
                                try:
                                    parsed_result = extract_and_parse_json(result, args)
                                    if parsed_result and isinstance(parsed_result, list):
                                        file_results.extend(parsed_result)
                                        logger.info(f"Got {len(parsed_result)} entries from chunk {chunk_idx+1}")
                                        with open(watchdog_file, 'a') as f:
                                            f.write(f"Chunk {chunk_idx+1} success: Got {len(parsed_result)} entries\n")
                                        break  # Success, no need to retry
                                    else:
                                        # If parsing failed, try to reduce chunk size
                                        if retry < max_retries:
                                            smaller_size = len(chunk) // 2
                                            smaller_chunks = chunk_large_text(chunk, smaller_size)
                                            logger.info(f"Retry with {len(smaller_chunks)} smaller chunks of {smaller_size} chars")
                                            
                                            # Try each smaller chunk with timeout checks
                                            sub_results = []
                                            for sub_idx, sub_chunk in enumerate(smaller_chunks):
                                                # Check if we're approaching the chunk timeout
                                                if time.time() - chunk_start_time > chunk_timeout:
                                                    logger.warning(f"Sub-chunk processing approaching timeout, skipping remaining sub-chunks")
                                                    break
                                                    
                                                file['content'] = sub_chunk
                                                logger.info(f"Processing sub-chunk {sub_idx+1}/{len(smaller_chunks)} ({len(sub_chunk)} chars)")
                                                
                                                try:
                                                    sub_result = call_ai_api([file], args)
                                                    
                                                    if sub_result:
                                                        try:
                                                            parsed_sub_result = extract_and_parse_json(sub_result, args)
                                                            if parsed_sub_result and isinstance(parsed_sub_result, list):
                                                                sub_results.extend(parsed_sub_result)
                                                                logger.info(f"Got {len(parsed_sub_result)} entries from sub-chunk {sub_idx+1}")
                                                        except Exception as sub_err:
                                                            logger.error(f"Error in sub-chunk {sub_idx+1}: {sub_err}")
                                                except Exception as api_err:
                                                    logger.error(f"API error in sub-chunk {sub_idx+1}: {api_err}")
                                                
                                                # Short delay between sub-chunks but check timeout first
                                                if time.time() - chunk_start_time <= chunk_timeout - 5:
                                                    time.sleep(2)  # Rate limit between sub-chunks
                                            
                                            if sub_results:
                                                file_results.extend(sub_results)
                                                with open(watchdog_file, 'a') as f:
                                                    f.write(f"Sub-chunks success: Got {len(sub_results)} entries\n")
                                                break  # Success from sub-chunks, no more retries needed
                                except Exception as e:
                                    logger.error(f"Error processing chunk {chunk_idx+1}: {e}")
                                    with open(watchdog_file, 'a') as f:
                                        f.write(f"Error processing chunk {chunk_idx+1}: {e}\n")
                                    if retry < max_retries:
                                        logger.info(f"Will retry chunk {chunk_idx+1}")
                        except Exception as api_error:
                            logger.error(f"API error in chunk {chunk_idx+1}: {api_error}")
                            with open(watchdog_file, 'a') as f:
                                f.write(f"API error in chunk {chunk_idx+1}: {api_error}\n")
                        
                        # Wait before retry but check timeout first
                        if retry < max_retries and time.time() - chunk_start_time <= chunk_timeout - 5:
                            time.sleep(3)
                    
                    # Log chunk completion
                    chunk_duration = time.time() - chunk_start_time
                    logger.info(f"HEARTBEAT: Chunk {chunk_idx+1}/{len(all_chunks)} completed in {chunk_duration:.1f} seconds")
                    with open(watchdog_file, 'a') as f:
                        f.write(f"Chunk {chunk_idx+1} completed in {chunk_duration:.1f} seconds\n")
                    
                    # Check if we're approaching the overall file timeout
                    if time.time() - file_start_time > file_timeout:
                        logger.warning(f"File processing approaching timeout ({file_timeout} seconds), skipping remaining chunks")
                        with open(watchdog_file, 'a') as f:
                            f.write(f"TIMEOUT: File processing exceeded {file_timeout} seconds, skipping remaining chunks\n")
                        break
                    
                    # Short delay between chunks but check timeout first
                    if time.time() - file_start_time <= file_timeout - 5:
                        time.sleep(3)  # Rate limit between chunks
                
                # Restore original content
                file['content'] = original_content
                
                # Add results from this file
                structured_data.extend(file_results)
                logger.info(f"HEARTBEAT: Total of {len(file_results)} entries from all chunks of {file['file_name']}")
                with open(watchdog_file, 'a') as f:
                    f.write(f"File {file['file_name']} completed with {len(file_results)} total entries\n")
            
            else:
                # Process file without chunks
                logger.info(f"HEARTBEAT: Processing {file['file_name']} as single content block at {time.strftime('%H:%M:%S')}")
                with open(watchdog_file, 'a') as f:
                    f.write(f"Processing {file['file_name']} as single content block\n")
                
                # Use an emergency timeout to prevent hanging
                process_start = time.time()
                
                try:
                    # Set a timeout for this operation
                    results = []
                    
                    # Only call the function if we're within the timeout
                    if time.time() - process_start <= file_timeout:
                        results = process_single_file_with_retry(file, args)
                    
                    structured_data.extend(results)
                    logger.info(f"HEARTBEAT: Got {len(results)} entries from {file['file_name']}")
                    with open(watchdog_file, 'a') as f:
                        f.write(f"Completed {file['file_name']} with {len(results)} entries\n")
                    
                except Exception as e:
                    logger.error(f"Error processing single file {file['file_name']}: {e}")
                    with open(watchdog_file, 'a') as f:
                        f.write(f"ERROR processing {file['file_name']}: {e}\n")
            
            # Log file completion and time
            file_duration = time.time() - file_start_time
            logger.info(f"HEARTBEAT: File {file_idx+1}/{len(batch)} ({file['file_name']}) completed in {file_duration:.1f} seconds")
            with open(watchdog_file, 'a') as f:
                f.write(f"File {file_idx+1}/{len(batch)} ({file['file_name']}) completed in {file_duration:.1f} seconds\n")
            
            # Check if we've exceeded the maximum batch time
            if time.time() - batch_start_time > max_batch_time:
                logger.warning(f"Batch processing exceeding maximum time ({max_batch_time/60:.1f} minutes), saving progress and moving on")
                with open(watchdog_file, 'a') as f:
                    f.write(f"TIMEOUT: Batch processing exceeded {max_batch_time/60:.1f} minutes, stopping batch early\n")
                break
            
            # Add a small delay between files but check batch timeout first
            if file_idx < len(batch) - 1 and time.time() - batch_start_time <= max_batch_time - 5:
                time.sleep(3)
        
        # Log batch completion
        batch_duration = time.time() - batch_start_time
        logger.info(f"HEARTBEAT: Batch {i//args.batch_size + 1}/{(len(file_info_list) + args.batch_size - 1) // args.batch_size} completed in {batch_duration:.1f} seconds")
        with open(watchdog_file, 'a') as f:
            f.write(f"Batch {i//args.batch_size + 1} completed in {batch_duration:.1f} seconds\n")
            f.write(f"Entries so far: {len(structured_data)}\n")
            
        # Save current progress after each batch
        try:
            progress_save_path = "./build/logs/processing_progress.json"
            with open(progress_save_path, 'w') as f:
                json.dump({
                    "timestamp": time.strftime('%Y-%m-%d %H:%M:%S'),
                    "entries_processed": len(structured_data),
                    "batches_completed": i//args.batch_size + 1,
                    "total_batches": (len(file_info_list) + args.batch_size - 1) // args.batch_size
                }, f, indent=2)
            logger.info(f"Progress saved to {progress_save_path}")
        except Exception as save_err:
            logger.error(f"Error saving progress: {save_err}")
    
    # Complete the watchdog file
    with open(watchdog_file, 'a') as f:
        f.write(f"\n=== FILE PROCESSING COMPLETED: {time.strftime('%Y-%m-%d %H:%M:%S')} ===\n")
        f.write(f"Total entries generated: {len(structured_data)}\n")
    
    return structured_data

# Old version of extract_and_parse_json was here
# Using the enhanced version with AI repair capability defined above

def process_single_file_with_retry(file, args, max_retries=2):
    """Process a single file with retry mechanism and timeout protection."""
    retry_count = 0
    results = []
    
    # Watchdog file just for this function
    watchdog_file = "./build/logs/file_processing_watchdog.log"
    with open(watchdog_file, 'a') as f:
        f.write(f"Starting file retry mechanism for {file['file_name']}\n")
    
    # Set maximum time for processing this file (5 minutes per retry attempt)
    start_time = time.time()
    max_processing_time = (max_retries + 1) * 300  # 5 minutes per attempt
    
    # Set timeout for each individual attempt (2 minutes)
    individual_timeout = 120  # 2 minutes
    
    while retry_count <= max_retries:
        # Check if we're approaching the maximum processing time
        if time.time() - start_time > max_processing_time:
            logger.warning(f"File {file['file_name']} processing exceeding maximum time ({max_processing_time/60:.1f} minutes), stopping")
            with open(watchdog_file, 'a') as f:
                f.write(f"TIMEOUT: {file['file_name']} processing exceeded {max_processing_time/60:.1f} minutes, stopping\n")
            break
        
        # Start time for this attempt
        attempt_start_time = time.time()
        
        if retry_count > 0:
            logger.info(f"HEARTBEAT: Retry {retry_count}/{max_retries} for file {file['file_name']} at {time.strftime('%H:%M:%S')}")
            with open(watchdog_file, 'a') as f:
                f.write(f"Retry {retry_count}/{max_retries} started at {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
        
        try:
            # Call API with its own internal timeout
            result = call_ai_api([file], args)
            
            # Check if we're still within the individual attempt timeout
            if time.time() - attempt_start_time > individual_timeout:
                logger.warning(f"Attempt {retry_count} for file {file['file_name']} took too long")
                with open(watchdog_file, 'a') as f:
                    f.write(f"SLOW: Attempt {retry_count} took longer than expected\n")
                # Still continue processing if we got a result
            
            # Process the result if we got one
            if result:
                try:
                    # Use the enhanced version with AI repair if needed
                    parsed_result = extract_and_parse_json(result, args)
                    if parsed_result and isinstance(parsed_result, list):
                        logger.info(f"HEARTBEAT: Got {len(parsed_result)} entries from {file['file_name']}")
                        with open(watchdog_file, 'a') as f:
                            f.write(f"Attempt {retry_count} success: Got {len(parsed_result)} entries\n")
                        results.extend(parsed_result)
                        break  # Success, exit retry loop
                    else:
                        logger.warning(f"Failed to parse result for {file['file_name']} (attempt {retry_count+1})")
                        with open(watchdog_file, 'a') as f:
                            f.write(f"Attempt {retry_count} failed: Could not parse result\n")
                except Exception as e:
                    logger.error(f"Error processing file {file['file_name']} (attempt {retry_count+1}): {e}")
                    with open(watchdog_file, 'a') as f:
                        f.write(f"Attempt {retry_count} error: {str(e)[:500]}\n")
            else:
                logger.warning(f"No result from API for {file['file_name']} (attempt {retry_count+1})")
                with open(watchdog_file, 'a') as f:
                    f.write(f"Attempt {retry_count} failed: No result from API\n")
        
        except Exception as outer_e:
            logger.error(f"Outer exception in file processing {file['file_name']} (attempt {retry_count+1}): {outer_e}")
            with open(watchdog_file, 'a') as f:
                f.write(f"Attempt {retry_count} outer exception: {str(outer_e)[:500]}\n")
        
        # Increment retry count
        retry_count += 1
        
        # Calculate attempt duration
        attempt_duration = time.time() - attempt_start_time
        logger.info(f"HEARTBEAT: Attempt {retry_count} for {file['file_name']} took {attempt_duration:.1f} seconds")
        with open(watchdog_file, 'a') as f:
            f.write(f"Attempt {retry_count-1} completed in {attempt_duration:.1f} seconds\n")
        
        # Wait before retrying, but only if we're still within the maximum time
        # and not on the last retry
        if retry_count <= max_retries and time.time() - start_time <= max_processing_time - 10:
            # Wait longer for each retry (exponential backoff)
            wait_time = min(5 * (2 ** (retry_count - 1)), 30)  # Cap at 30 seconds
            logger.info(f"Waiting {wait_time} seconds before retry {retry_count}")
            time.sleep(wait_time)
    
    # Log final result
    total_time = time.time() - start_time
    with open(watchdog_file, 'a') as f:
        f.write(f"Completed processing {file['file_name']} in {total_time:.1f} seconds with {len(results)} entries\n")
        if retry_count > max_retries:
            f.write(f"Note: All {max_retries+1} attempts were used\n")
    
    return results

def process_batch_with_retry(batch, args, max_retries=2):
    """Process a batch of files with retry mechanism and aggressive timeout protection."""
    if not batch:
        return []
    
    # Watchdog file for this function
    watchdog_file = "./build/logs/batch_processing_watchdog.log"
    os.makedirs(os.path.dirname(watchdog_file), exist_ok=True)
    
    # Create a record of this batch processing attempt
    batch_id = f"batch_{int(time.time())}"
    batch_files = ", ".join([file['file_name'] for file in batch])
    with open(watchdog_file, 'a') as f:
        f.write(f"\n=== BATCH {batch_id} STARTED: {time.strftime('%Y-%m-%d %H:%M:%S')} ===\n")
        f.write(f"Files in batch: {batch_files}\n")
        f.write(f"Max retries: {max_retries}\n")
    
    logger.info(f"HEARTBEAT: Processing batch of {len(batch)} files: {batch_files}")
    
    results = []
    batch_size = len(batch)
    retry_count = 0
    
    # Set a maximum time for this batch (5 minutes per file)
    start_time = time.time()
    max_batch_time = 300 * batch_size  # 5 minutes per file in batch
    
    # Try the batch approach first with retries
    while retry_count <= max_retries:
        # Check if we're exceeding the maximum time allowed
        if time.time() - start_time > max_batch_time:
            logger.warning(f"Batch processing exceeding maximum time ({max_batch_time/60:.1f} minutes), switching to individual processing")
            with open(watchdog_file, 'a') as f:
                f.write(f"TIMEOUT: Batch processing exceeded {max_batch_time/60:.1f} minutes\n")
            break
        
        # Track attempt start time
        attempt_start_time = time.time()
        
        if retry_count > 0:
            logger.info(f"HEARTBEAT: Retry {retry_count}/{max_retries} for batch of {batch_size} files at {time.strftime('%H:%M:%S')}")
            with open(watchdog_file, 'a') as f:
                f.write(f"Retry {retry_count}/{max_retries} started at {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
            
            # If we're on the final retry, switch to individual file processing for better reliability
            if retry_count == max_retries:
                logger.info("HEARTBEAT: Final retry: switching to individual file processing for reliability")
                with open(watchdog_file, 'a') as f:
                    f.write(f"STRATEGY: Switching to individual file processing for final retry\n")
                
                # Process each file individually with its own timeout
                for file_idx, file in enumerate(batch):
                    # Check if we're exceeding the maximum time allowed for this batch
                    if time.time() - start_time > max_batch_time:
                        logger.warning(f"Individual processing in batch exceeding maximum time, stopping after file {file_idx+1}/{batch_size}")
                        with open(watchdog_file, 'a') as f:
                            f.write(f"TIMEOUT: Individual processing stopped after file {file_idx+1}/{batch_size}\n")
                        break
                    
                    logger.info(f"HEARTBEAT: Processing file {file_idx+1}/{batch_size}: {file['file_name']}")
                    with open(watchdog_file, 'a') as f:
                        f.write(f"Processing file {file_idx+1}/{batch_size}: {file['file_name']}\n")
                    
                    # Use our robust single file processing with timeout
                    file_results = process_single_file_with_retry(file, args)
                    results.extend(file_results)
                    
                    logger.info(f"HEARTBEAT: Completed file {file_idx+1}/{batch_size} with {len(file_results)} entries")
                    with open(watchdog_file, 'a') as f:
                        f.write(f"File {file_idx+1}/{batch_size} completed with {len(file_results)} entries\n")
                
                # Log individual processing completion
                with open(watchdog_file, 'a') as f:
                    f.write(f"Individual processing completed with {len(results)} total entries\n")
                    f.write(f"=== BATCH {batch_id} COMPLETED (INDIVIDUAL MODE): {time.strftime('%Y-%m-%d %H:%M:%S')} ===\n")
                
                return results
        
        # Try processing the whole batch at once
        try:
            logger.info(f"HEARTBEAT: Attempting batch processing for {batch_size} files at {time.strftime('%H:%M:%S')}")
            with open(watchdog_file, 'a') as f:
                f.write(f"Attempt {retry_count}: Batch processing started\n")
            
            # Use the API with timeout protection
            result = call_ai_api(batch, args)
            
            # Check if the attempt took too long
            attempt_duration = time.time() - attempt_start_time
            if attempt_duration > 180:  # 3 minutes is too long for a batch call
                logger.warning(f"Batch API call took {attempt_duration:.1f} seconds (very slow)")
                with open(watchdog_file, 'a') as f:
                    f.write(f"SLOW: Batch API call took {attempt_duration:.1f} seconds\n")
            
            if not result:
                logger.warning(f"No result from API for batch (attempt {retry_count+1})")
                with open(watchdog_file, 'a') as f:
                    f.write(f"FAILED: No result from API for batch (attempt {retry_count+1})\n")
                retry_count += 1
                continue
            
            # Try to parse the result
            logger.info(f"HEARTBEAT: Parsing API response at {time.strftime('%H:%M:%S')}")
            parsed_result = extract_and_parse_json(result, args)
            
            if parsed_result and isinstance(parsed_result, list):
                logger.info(f"HEARTBEAT: Successfully processed {len(parsed_result)} entries from batch of {batch_size} files")
                with open(watchdog_file, 'a') as f:
                    f.write(f"SUCCESS: Got {len(parsed_result)} entries from batch processing\n")
                results.extend(parsed_result)
                break  # Success, exit retry loop
            else:
                logger.warning(f"Invalid response format - not a list but {type(parsed_result) if parsed_result else 'None'}")
                with open(watchdog_file, 'a') as f:
                    f.write(f"INVALID: Response parsing failed with type {type(parsed_result) if parsed_result else 'None'}\n")
                # Continue to next retry
        except Exception as e:
            logger.error(f"Error processing batch: {e}")
            logger.error(f"Error type: {type(e).__name__}")
            with open(watchdog_file, 'a') as f:
                f.write(f"ERROR: {type(e).__name__} - {str(e)[:500]}\n")
            
            # Try to save the failed response in build/logs directory for debugging
            try:
                logs_dir = Path("./build/logs")
                logs_dir.mkdir(parents=True, exist_ok=True)
                debug_file = logs_dir / f"debug_failed_response_{int(time.time())}.txt"
                try:
                    with open(debug_file, 'w') as f:
                        if 'result' in locals() and result:
                            f.write(str(result)[:50000])  # Limit to 50K chars in case it's huge
                        else:
                            f.write("No result available")
                    logger.debug(f"Saved failed response to {debug_file}")
                    with open(watchdog_file, 'a') as f:
                        f.write(f"DEBUG: Saved failed response to {debug_file}\n")
                except Exception as write_error:
                    logger.error(f"Could not write debug file: {write_error}")
            except Exception as save_error:
                logger.error(f"Could not save debug file: {save_error}")
        
        # Log attempt completion
        attempt_duration = time.time() - attempt_start_time
        logger.info(f"HEARTBEAT: Batch processing attempt {retry_count+1} completed in {attempt_duration:.1f} seconds")
        with open(watchdog_file, 'a') as f:
            f.write(f"Attempt {retry_count} completed in {attempt_duration:.1f} seconds\n")
        
        # Increment retry counter
        retry_count += 1
        
        # Wait between retries, with exponential backoff
        if retry_count <= max_retries and time.time() - start_time <= max_batch_time - 10:
            wait_time = min(5 * (2 ** (retry_count - 1)), 30)  # Cap at 30 seconds
            logger.info(f"Waiting {wait_time} seconds before retry {retry_count}")
            with open(watchdog_file, 'a') as f:
                f.write(f"Waiting {wait_time} seconds before retry {retry_count}\n")
            time.sleep(wait_time)
    
    # If we failed all batch retries and didn't already do individual processing, 
    # try individual processing as a last resort
    if len(results) == 0 and retry_count > max_retries:
        logger.warning(f"HEARTBEAT: Batch processing failed after {max_retries} retries, switching to individual processing")
        with open(watchdog_file, 'a') as f:
            f.write(f"FALLBACK: Batch processing failed, switching to individual processing\n")
        
        # Process each file individually with its own timeout
        for file_idx, file in enumerate(batch):
            # Check if we've exceeded the maximum time allowed
            if time.time() - start_time > max_batch_time:
                logger.warning(f"Individual processing exceeding maximum time, stopping after file {file_idx+1}/{batch_size}")
                with open(watchdog_file, 'a') as f:
                    f.write(f"TIMEOUT: Individual processing stopped after file {file_idx+1}/{batch_size}\n")
                break
            
            logger.info(f"HEARTBEAT: Processing file {file_idx+1}/{batch_size}: {file['file_name']} at {time.strftime('%H:%M:%S')}")
            with open(watchdog_file, 'a') as f:
                f.write(f"Processing file {file_idx+1}/{batch_size}: {file['file_name']}\n")
            
            # Process with robust single file method
            file_results = process_single_file_with_retry(file, args)
            results.extend(file_results)
            
            logger.info(f"HEARTBEAT: Completed file {file_idx+1}/{batch_size} with {len(file_results)} entries")
            with open(watchdog_file, 'a') as f:
                f.write(f"File {file_idx+1}/{batch_size} completed with {len(file_results)} entries\n")
    
    # Log final results 
    total_time = time.time() - start_time
    logger.info(f"HEARTBEAT: Batch processing completed in {total_time:.1f} seconds with {len(results)} total entries")
    with open(watchdog_file, 'a') as f:
        f.write(f"Batch processing completed in {total_time:.1f} seconds\n")
        f.write(f"Total entries: {len(results)}\n")
        f.write(f"=== BATCH {batch_id} COMPLETED: {time.strftime('%Y-%m-%d %H:%M:%S')} ===\n")
    
    return results

def copy_images_to_output(file_info_list: List[Dict], output_dir: str) -> Dict:
    """Copy images to the output directory and return a mapping of original paths to new paths."""
    
    image_path_mapping = {}
    
    # Create images directory
    images_dir = os.path.join(output_dir, "images")
    os.makedirs(images_dir, exist_ok=True)
    
    for file_info in file_info_list:
        if file_info["content_type"] == "image":
            # Create a safe filename
            original_name = os.path.basename(file_info["file_path"])
            safe_name = ''.join(c if c.isalnum() or c in '._- ' else '_' for c in original_name)
            
            # If duplicate, add a counter
            counter = 1
            new_name = safe_name
            while os.path.exists(os.path.join(images_dir, new_name)):
                name_parts = os.path.splitext(safe_name)
                new_name = f"{name_parts[0]}_{counter}{name_parts[1]}"
                counter += 1
            
            # Copy the file
            try:
                shutil.copy2(file_info["file_path"], os.path.join(images_dir, new_name))
                image_path_mapping[file_info["file_path"]] = os.path.join("images", new_name)
                logger.debug(f"Copied image: {file_info['file_path']} -> {os.path.join('images', new_name)}")
            except Exception as e:
                logger.error(f"Error copying image {file_info['file_path']}: {e}")
    
    return image_path_mapping

def discover_files(input_path: str, args: argparse.Namespace) -> List[Dict]:
    """Discover and process files in the input directory."""
    
    file_info_list = []
    
    # Debug: Show directory contents and permissions
    logger.info(f"Inspecting directory: {input_path}")
    try:
        dir_contents = os.listdir(input_path)
        logger.info(f"Directory contents: {dir_contents}")
        
        # Check permissions
        import stat
        dir_stat = os.stat(input_path)
        dir_perms = stat.filemode(dir_stat.st_mode)
        logger.info(f"Directory permissions: {dir_perms}, owner: {dir_stat.st_uid}, group: {dir_stat.st_gid}")
        
        # Check individual files
        for item in dir_contents:
            item_path = os.path.join(input_path, item)
            if os.path.isfile(item_path):
                file_stat = os.stat(item_path)
                file_perms = stat.filemode(file_stat.st_mode)
                file_ext = get_file_extension(item_path)
                logger.info(f"File: {item}, extension: {file_ext}, permissions: {file_perms}, size: {file_stat.st_size} bytes")
    except Exception as e:
        logger.error(f"Error listing directory {input_path}: {e}")
    
    # Walk through directory and gather file information
    for root, dirs, files in os.walk(input_path):
        logger.info(f"Scanning directory: {root}")
        logger.info(f"Found {len(files)} files and {len(dirs)} subdirectories")
        
        for file in files:
            file_path = os.path.join(root, file)
            logger.info(f"Checking file: {file_path}")
            
            # Skip hidden files and directories (files that start with .)
            # But don't skip files with spaces
            if file.startswith('.'):
                logger.info(f"Skipping hidden file: {file_path}")
                continue
                
            # Skip files in hidden directories (ones that start with .)
            hidden_dir = False
            for part in file_path.split(os.sep):
                if part and part.startswith('.') and part != '.' and part != '..':
                    hidden_dir = True
                    break
                    
            if hidden_dir:
                logger.info(f"Skipping file in hidden directory: {file_path}")
                continue
            
            # Show file type info
            file_ext = get_file_extension(file_path)
            is_image = is_image_file(file_path)
            is_text = is_text_file(file_path)
            is_doc = is_document_file(file_path)
            logger.info(f"File type check: extension='{file_ext}', is_image={is_image}, is_text={is_text}, is_doc={is_doc}")
            
            # Process file only if it matches requested types
            should_process = (
                (args.include_images and is_image) or
                (args.include_text and (is_text or is_doc))
            )
            
            logger.info(f"Should process: {should_process} (include_images={args.include_images}, include_text={args.include_text})")
            
            if should_process:
                file_info = process_file(file_path, args)
                file_info_list.append(file_info)
                logger.info(f"Discovered file: {file_path} ({file_info['content_type']})")
            else:
                logger.info(f"Skipping file: {file_path} (doesn't match requested types)")
    
    logger.info(f"Discovered {len(file_info_list)} files: {sum(1 for f in file_info_list if f['content_type']=='image')} images, {sum(1 for f in file_info_list if f['content_type']=='text')} text, {sum(1 for f in file_info_list if f['content_type']=='document')} documents")
    
    return file_info_list

def update_structured_data_paths(structured_data: List[Dict], image_path_mapping: Dict) -> List[Dict]:
    """Update image paths in structured data with the correct relative paths."""
    
    updated_data = []
    
    for item in structured_data:
        if "image_path" in item and item["image_path"]:
            # Try to find the original image path
            original_path = item["image_path"]
            
            # Handle absolute and relative paths
            if os.path.isabs(original_path):
                if original_path in image_path_mapping:
                    item["image_path"] = image_path_mapping[original_path]
            else:
                # Try various path combinations
                for orig_path, new_path in image_path_mapping.items():
                    if os.path.basename(orig_path) == os.path.basename(original_path):
                        item["image_path"] = new_path
                        break
        
        updated_data.append(item)
    
    return updated_data

def save_data(data, output_path):
    """Helper function to save data with error handling"""
    try:
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        with open(output_path, 'w') as f:
            json.dump(data, f, indent=2)
        return True
    except Exception as e:
        logger.error(f"Error saving data to {output_path}: {e}")
        return False

def main():
    start_time = time.time()
    args = parse_args()
    
    # Set defaults for processing
    if not args.include_images and not args.include_text:
        args.include_images = True
        args.include_text = True
    
    # Create output directory
    os.makedirs(args.output_path, exist_ok=True)
    os.makedirs(os.path.join(args.output_path, "images"), exist_ok=True)
    
    # Create logs directory for storing debug information
    logs_dir = Path("./build/logs")
    logs_dir.mkdir(parents=True, exist_ok=True)
    
    # Create a main watchdog file to track overall progress
    watchdog_file = logs_dir / "watchdog.log"
    with open(watchdog_file, 'a') as f:
        f.write(f"\n=== AUTO-PROCESS STARTED: {time.strftime('%Y-%m-%d %H:%M:%S')} ===\n")
        f.write(f"Input path: {args.input_path}\n")
        f.write(f"Output path: {args.output_path}\n")
        f.write(f"Model: {args.model}\n")
        f.write(f"Batch size: {args.batch_size}\n")
        f.write(f"Include images: {args.include_images}\n")
        f.write(f"Include text: {args.include_text}\n")
    
    # Create progress file to track overall progress
    progress_file = logs_dir / "auto_process_progress.json"
    progress_data = {
        "started_at": time.strftime('%Y-%m-%d %H:%M:%S'),
        "status": "started",
        "steps_completed": [],
        "current_step": "initialize"
    }
    save_data(progress_data, progress_file)
    
    logger.info(f"Debug logs will be saved to: {logs_dir}")
    logger.info(f"HEARTBEAT: Auto-processing started at {time.strftime('%H:%M:%S')}")
    
    # For global access in error handler
    file_info_list = []
    image_path_mapping = {}
    structured_data = []
    
    try:
        # Discover and process files
        logger.info(f"HEARTBEAT: Starting discovery of files from {args.input_path}")
        with open(watchdog_file, 'a') as f:
            f.write(f"Starting discovery of files at: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
        
        # Update progress
        progress_data["current_step"] = "discover_files"
        save_data(progress_data, progress_file)
        
        # Set a timeout for file discovery (5 minutes)
        discovery_timeout = 300  # seconds
        discovery_start = time.time()
        
        # Initialize the timeout check
        def check_timeout():
            if time.time() - discovery_start > discovery_timeout:
                logger.error(f"File discovery timed out after {discovery_timeout} seconds")
                with open(watchdog_file, 'a') as f:
                    f.write(f"ERROR: File discovery timed out after {discovery_timeout} seconds\n")
                return True
            return False
        
        file_info_list = discover_files(args.input_path, args)
        
        # Mark discovery as completed
        progress_data["steps_completed"].append("discover_files")
        progress_data["files_discovered"] = len(file_info_list)
        save_data(progress_data, progress_file)
        
        if not file_info_list:
            logger.warning("No files found to process. Check --include_images and --include_text flags.")
            with open(watchdog_file, 'a') as f:
                f.write(f"WARNING: No files found to process at: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write(f"=== AUTO-PROCESS FINISHED (NO FILES): {time.strftime('%Y-%m-%d %H:%M:%S')} ===\n")
            
            # Update progress
            progress_data["status"] = "completed_no_files"
            progress_data["completed_at"] = time.strftime('%Y-%m-%d %H:%M:%S')
            save_data(progress_data, progress_file)
            return
        
        # Copy images to output directory
        logger.info(f"HEARTBEAT: Copying images to output directory at {time.strftime('%H:%M:%S')}")
        with open(watchdog_file, 'a') as f:
            f.write(f"Copying images started at: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
        
        # Update progress
        progress_data["current_step"] = "copy_images"
        save_data(progress_data, progress_file)
        
        image_path_mapping = copy_images_to_output(file_info_list, args.output_path)
        
        # Mark image copying as completed
        progress_data["steps_completed"].append("copy_images")
        progress_data["images_copied"] = len(image_path_mapping)
        save_data(progress_data, progress_file)
        
        with open(watchdog_file, 'a') as f:
            f.write(f"Copied {len(image_path_mapping)} images at: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
        
        # Process with AI API
        if args.api_key:
            logger.info(f"HEARTBEAT: Processing data with AI model: {args.model} at {time.strftime('%H:%M:%S')}")
            with open(watchdog_file, 'a') as f:
                f.write(f"Processing with AI started at: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write(f"Using model: {args.model}\n")
            
            # Update progress
            progress_data["current_step"] = "process_with_ai"
            save_data(progress_data, progress_file)
            
            # Set an overall timeout for API processing (4 hours)
            api_processing_timeout = 4 * 60 * 60  # 4 hours in seconds
            api_processing_start = time.time()
            
            # Process with AI with timeout checks
            structured_data = []
            try:
                # Check if we're about to hit the timeout
                if time.time() - api_processing_start > api_processing_timeout:
                    logger.warning(f"API processing approaching timeout limit of {api_processing_timeout/3600:.1f} hours")
                    raise TimeoutError(f"AI processing timeout after {api_processing_timeout/3600:.1f} hours")
                
                structured_data = process_files_with_ai(file_info_list, args)
                
                # Log heartbeat after successful processing
                logger.info(f"HEARTBEAT: AI processing completed at {time.strftime('%H:%M:%S')}")
                
            except Exception as api_err:
                logger.error(f"Error during AI processing: {api_err}")
                with open(watchdog_file, 'a') as f:
                    f.write(f"ERROR during AI processing: {api_err}\n")
                
                # The process_files_with_ai function may have already processed some files
                # We can still continue with whatever results we got
                logger.warning(f"Continuing with partial results: {len(structured_data)} entries")
                with open(watchdog_file, 'a') as f:
                    f.write(f"Continuing with partial results: {len(structured_data)} entries\n")
            
            # Mark AI processing as completed or failed
            if structured_data:
                progress_data["steps_completed"].append("process_with_ai")
            else:
                progress_data["process_with_ai_failed"] = True
            progress_data["entries_generated"] = len(structured_data)
            save_data(progress_data, progress_file)
            
            # Update image paths in structured data
            logger.info(f"HEARTBEAT: Updating image paths at {time.strftime('%H:%M:%S')}")
            progress_data["current_step"] = "update_image_paths"
            save_data(progress_data, progress_file)
            
            structured_data = update_structured_data_paths(structured_data, image_path_mapping)
            progress_data["steps_completed"].append("update_image_paths")
            save_data(progress_data, progress_file)
            
            # Count expected vs actual entries
            expected_entries = len(file_info_list) * args.num_examples_per_doc
            actual_entries = len(structured_data)
            
            # Calculate success rate and identify potential missing entries
            success_rate = actual_entries / expected_entries if expected_entries > 0 else 0
            missing_entries = expected_entries - actual_entries
            
            # Report on processing statistics and any missing entries
            processing_stats = [
                f"Processing Statistics:",
                f"- Files processed: {len(file_info_list)}",
                f"- Expected entries (target): {expected_entries}",
                f"- Actual entries generated: {actual_entries}",
                f"- Success rate: {success_rate:.2%}"
            ]
            
            for stat in processing_stats:
                logger.info(stat)
            
            if missing_entries > 0:
                warning_messages = [
                    f"⚠️ Some entries may be missing: {missing_entries} fewer entries than expected",
                    f"  This could be due to truncation errors, API limitations, or partial processing.",
                    f"  Check logs in build/logs directory for specific errors."
                ]
                
                for msg in warning_messages:
                    logger.warning(msg)
            
            # Save structured data with statistics
            logger.info(f"HEARTBEAT: Saving output data at {time.strftime('%H:%M:%S')}")
            with open(watchdog_file, 'a') as f:
                f.write(f"Saving output data at: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
            
            # Update progress
            progress_data["current_step"] = "save_data"
            save_data(progress_data, progress_file)
            
            os.makedirs(args.output_path, exist_ok=True)
            output_file = os.path.join(args.output_path, "sample_data.json")
            
            # Save structured data (keeping the original simple format)
            if save_data(structured_data, output_file):
                logger.info(f"Saved output data to: {output_file}")
            else:
                logger.error(f"Failed to save output data to: {output_file}")
            
            # Mark data saving as completed
            progress_data["steps_completed"].append("save_data")
            save_data(progress_data, progress_file)
            
            # Write statistics to a separate log file in the logs directory
            stats_file = logs_dir / f"processing_stats_{time.strftime('%Y%m%d_%H%M%S')}.json"
            
            stats_data = {
                "files_processed": len(file_info_list),
                "expected_entries": expected_entries,
                "actual_entries": actual_entries,
                "success_rate": success_rate,
                "processing_date": time.strftime("%Y-%m-%d %H:%M:%S"),
                "missing_entries": missing_entries,
                "total_runtime_seconds": time.time() - start_time,
                "images_copied": len(image_path_mapping)
            }
            
            if save_data(stats_data, stats_file):
                logger.info(f"Saved statistics to: {stats_file}")
            
            # Mark process as completed
            progress_data["status"] = "completed"
            progress_data["completed_at"] = time.strftime('%Y-%m-%d %H:%M:%S')
            progress_data["runtime_seconds"] = time.time() - start_time
            save_data(progress_data, progress_file)
            
            with open(watchdog_file, 'a') as f:
                f.write(f"=== AUTO-PROCESS FINISHED: {time.strftime('%Y-%m-%d %H:%M:%S')} ===\n")
                f.write(f"Total runtime: {(time.time() - start_time)/60:.1f} minutes\n")
                f.write(f"Files processed: {len(file_info_list)}\n")
                f.write(f"Entries generated: {len(structured_data)}\n")
                f.write(f"Success rate: {success_rate:.2%}\n")
            
            logger.info(f"HEARTBEAT: Auto-processing complete at {time.strftime('%H:%M:%S')} - Runtime: {(time.time() - start_time)/60:.1f} minutes")
            logger.info(f"✅ Generated {len(structured_data)} structured entries")
            logger.info(f"   Output saved to: {output_file}")
            logger.info(f"   Statistics saved to: {stats_file}")
        else:
            logger.warning("No API key provided. Only copying images to output directory.")
            with open(watchdog_file, 'a') as f:
                f.write(f"WARNING: No API key provided, skipping AI processing\n")
                f.write(f"=== AUTO-PROCESS FINISHED (NO API KEY): {time.strftime('%Y-%m-%d %H:%M:%S')} ===\n")
            
            # Mark process as completed without AI processing
            progress_data["status"] = "completed_no_api_key"
            progress_data["completed_at"] = time.strftime('%Y-%m-%d %H:%M:%S')
            progress_data["runtime_seconds"] = time.time() - start_time
            save_data(progress_data, progress_file)
            
            logger.info(f"HEARTBEAT: Auto-processing complete (image copy only) at {time.strftime('%H:%M:%S')}")
            logger.info(f"✅ Image copying complete! Copied {len(image_path_mapping)} images")
    
    except Exception as e:
        logger.error(f"Error during auto-processing: {e}")
        
        # Record error in watchdog
        with open(watchdog_file, 'a') as f:
            f.write(f"ERROR during auto-processing at {time.strftime('%Y-%m-%d %H:%M:%S')}: {e}\n")
            f.write(f"Traceback: {traceback.format_exc()}\n")
            f.write(f"=== AUTO-PROCESS FAILED: {time.strftime('%Y-%m-%d %H:%M:%S')} ===\n")
        
        # Update progress file with error
        progress_data["status"] = "failed"
        progress_data["error"] = str(e)
        progress_data["error_at"] = time.strftime('%Y-%m-%d %H:%M:%S')
        progress_data["runtime_seconds"] = time.time() - start_time
        save_data(progress_data, progress_file)
        
        # Try to save whatever data we have so far as an emergency backup
        try:
            error_output = args.output_path.replace('.json', f'_error_{int(time.time())}.json')
            save_data(structured_data, error_output)
            logger.info(f"Emergency save to: {error_output}")
        except Exception as save_error:
            logger.critical(f"Could not save data after error: {save_error}")
        
        # Re-raise the exception for proper exit code
        raise

# Add signal handlers for graceful shutdown
def setup_signal_handlers():
    import signal
    
    # Global variables to track state
    interrupted = False
    watchdog_file = Path("./build/logs/watchdog.log")
    
    def signal_handler(sig, frame):
        nonlocal interrupted
        if interrupted:
            logger.critical("Forced exit - second interrupt received")
            sys.exit(1)
            
        interrupted = True
        logger.warning("Interrupt received, attempting graceful shutdown...")
        
        # Log the interrupt
        try:
            with open(watchdog_file, 'a') as f:
                f.write(f"INTERRUPT: Signal {sig} received at {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write(f"Attempting graceful shutdown...\n")
        except:
            pass
        
        # Exit with error code
        sys.exit(1)
        
    # Register signal handlers
    signal.signal(signal.SIGINT, signal_handler)  # Ctrl+C
    signal.signal(signal.SIGTERM, signal_handler)  # Termination signal
    
    logger.info("Signal handlers registered for graceful shutdown")

if __name__ == "__main__":
    # Set up signal handlers before starting
    setup_signal_handlers()
    
    # Start the main process
    main()