#!/bin/bash
# ===================================================================
# Pipeline Logging Setup
# ===================================================================
# Create a timestamped log file for this run
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
LOG_DIR="./build/logs"
mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/pipeline_run_$TIMESTAMP.log"

# Log checkpoint function
log_checkpoint() {
    local message="[$(date +'%Y-%m-%d %H:%M:%S')] CHECKPOINT: $1"
    echo "$message" | tee -a "$LOG_FILE"
}

log_checkpoint "Pipeline started"

# ===================================================================
# IMPORTANT PATH WARNING
# ===================================================================
# The project path MUST NOT contain parentheses (), brackets [], braces {},
# spaces, or any special characters. These will cause CUDA compilation 
# to fail during training with errors like "Syntax error: ( unexpected"
#
# Good path example: /home/user/Phi3_Mini_FineTuning
# Bad path example: /home/user/Phi3_Mini_FineTuning(v1)
# ===================================================================
#
# Phi-3-mini Fine-tuning Pipeline
# This script runs the complete pipeline for fine-tuning a Phi-3-mini-4k-instruct model
# 
# Usage:
#   ./run_phi3_mini.sh [--auto-process] [--augment-data] [--skip-data-prep] [--skip-training] [--skip-onnx] [--skip-eval] [--install-cuda] [--clean] [--skip-dependencies] [--use-onnx] [--api-server]
#
# Options:
#   --auto-process: Automatically process PDF documents from sample_data/DATA and convert them to structured JSON format in build/data/RAW_JSON
#   --augment-data: Perform data augmentation on the input dataset (works with either auto-processed or sample data)
#   --include-images: Include image processing when using auto-processing (default is text-only)
#   --skip-data-prep: Skip the data preparation step
#   --skip-training: Skip the model training step
#   --skip-onnx: Skip ONNX conversion
#   --skip-eval: Skip model evaluation step
#   --install-cuda: Install CUDA 12.x on the system (requires sudo)
#   --clean: Clean and recreate the virtual environment
#   --skip-dependencies: Skip the dependency check section
#   --use-onnx: Use ONNX model for inference in the API server
#   --api-server: Start the API server after pipeline completion
#   --raw-data-path: Path to raw data directory for auto-processing (default: ./sample_data/DATA)
#   --api-key: API key for AI model to use with auto-processing (overrides hardcoded key)
#   --api-model: AI model to use for auto-processing (overrides hardcoded model)
#
# Auto-processing:
#   Place PDF documents in the ./sample_data/DATA directory and use the --auto-process flag.
#   The script will process text documents (PDF, TXT) by default and generate JSON data in build/data/RAW_JSON.
#   Use --include-images to also process images (JPG, PNG) from the same directory.
#
# Data Augmentation:
#   Use the --augment-data flag to run data augmentation on the input dataset.
#   The augmented data will be stored in build/data/AUGMENTED_JSON and used for training.

set -e  # Exit on any error

# Hardcoded configuration values
AUTO_PROCESS_MODEL="gpt-4o"
AUTO_PROCESS_ENDPOINT="https://kh-oai-west-us.openai.azure.com/openai/deployments/gpt-4o/chat/completions?api-version=2024-08-01-preview"
AUTO_PROCESS_API_KEY="BM1lfygoycUvEg4Gak6qrGkIpzCNG99L42uC2xa3gwrBNKmPBjRjJQQJ99ALAC4f1cMXJ3w3AAABACOGhB6m"

# Data directories
PDF_DATA_DIR="./sample_data/DATA"
RAW_JSON_DIR="./build/data/RAW_JSON"
AUGMENTED_JSON_DIR="./build/data/AUGMENTED_JSON"

# Model configuration
PHI_MODEL_ID="microsoft/Phi-3-mini-4k-instruct" # The model we're fine-tuning

# Parse command line arguments
SKIP_DATA_PREP=false
SKIP_TRAINING=false
SKIP_ONNX=false
SKIP_EVAL=false
INSTALL_CUDA=false
CLEAN_ENV=false
SKIP_DEPENDENCIES=false
AUTO_PROCESS=false
AUGMENT_DATA=false
USE_ONNX=false
INCLUDE_IMAGES=false # Default to not including images
RAW_DATA_PATH="$PDF_DATA_DIR"
API_KEY=""
API_MODEL="$AUTO_PROCESS_MODEL"
API_SERVER=false # Default to not running the API server

for arg in "$@"
do
    case $arg in
        --skip-data-prep)
        SKIP_DATA_PREP=true
        shift
        ;;
        --skip-training)
        SKIP_TRAINING=true
        shift
        ;;
        --skip-onnx)
        SKIP_ONNX=true
        shift
        ;;
        --skip-eval)
        SKIP_EVAL=true
        shift
        ;;
        --install-cuda)
        INSTALL_CUDA=true
        shift
        ;;
        --clean)
        CLEAN_ENV=true
        shift
        ;;
        --skip-dependencies)
        SKIP_DEPENDENCIES=true
        shift
        ;;
        --auto-process)
        AUTO_PROCESS=true
        shift
        ;;
        --augment-data)
        AUGMENT_DATA=true
        shift
        ;;
        --include-images)
        INCLUDE_IMAGES=true
        shift
        ;;
        --use-onnx)
        USE_ONNX=true
        shift
        ;;
        --api-server)
        API_SERVER=true
        shift
        ;;
        --raw-data-path=*)
        RAW_DATA_PATH="${arg#*=}"
        shift
        ;;
        --api-key=*)
        API_KEY="${arg#*=}"
        shift
        ;;
        --api-model=*)
        API_MODEL="${arg#*=}"
        shift
        ;;
        *)
        # Unknown option
        ;;
    esac
done

# ===================================================================
# SYSTEM CONFIGURATION SECTION
# ===================================================================

# Step 0: Install system dependencies if needed
echo "==================================================================="
echo "Step 0: System Configuration"
echo "==================================================================="
log_checkpoint "Step 0: System Configuration started"

# Check for Python venv
python3 -m venv --help &> /dev/null
if [ $? -ne 0 ]; then
    echo "Python virtual environment module not found."
    echo "Please install it using one of these commands based on your Python version:"
    echo "  For Python 3.12: sudo apt install python3.12-venv"
    echo "  For Python 3.11: sudo apt install python3.11-venv" 
    echo "  For Python 3.10: sudo apt install python3.10-venv"
    echo "  Generic: sudo apt install python3-venv"
    exit 1
fi

# Check if venv exists or --clean flag is provided
if [ ! -d "venv" ] || [ "$CLEAN_ENV" = true ]; then
    echo "Setting up a clean Python virtual environment..."
    # Remove any existing virtual environment and recreate it
    rm -rf venv
    python3 -m venv venv
    if [ $? -ne 0 ]; then
        echo "ERROR: Failed to create virtual environment. Please check your Python installation."
        exit 1
    fi
    echo "Virtual environment created successfully."
else
    echo "Using existing virtual environment..."
fi

# Activate the virtual environment
echo "Activating virtual environment..."
source venv/bin/activate
if [ $? -ne 0 ]; then
    echo "ERROR: Failed to activate virtual environment."
    exit 1
fi
echo "Virtual environment activated successfully."

# Update PATH to use the virtualenv python and ensure it's in the current PATH
PYTHON_PATH="$(pwd)/venv/bin/python"
export PATH="$(pwd)/venv/bin:$PATH"
echo "Using Python from: $PYTHON_PATH"

# If user wants CUDA installation guide
if [ "$INSTALL_CUDA" = true ]; then
    # Run CUDA installation script if it exists
    if [ -f "install_cuda_12.8.sh" ]; then
        echo "Running CUDA 12.8 installation script..."
        sudo bash install_cuda_12.8.sh
        exit 0
    else
        # Print CUDA installation instructions and exit
        echo "====================== CUDA INSTALLATION GUIDE ======================"
        echo "To install CUDA 12.8 on your system using apt package manager:"
        echo ""
        echo "# 1. Add NVIDIA CUDA repository to your system"
        echo "sudo apt-get update"
        echo "sudo apt-get install -y software-properties-common"
        echo "sudo add-apt-repository ppa:graphics-drivers/ppa"
        echo ""
        echo "# 2. Install NVIDIA driver (if not already installed)"
        echo "sudo apt-get update"
        echo "sudo apt-get install -y nvidia-driver-535" # 535 driver works well with CUDA 12.8
        echo ""
        echo "# 3. Install CUDA 12.8 packages"
        echo "sudo apt-get install -y cuda-12-8"
        echo "sudo apt-get install -y cuda-drivers"
        echo ""
        echo "# 4. Install CUDA toolkit 12.8 specific packages"
        echo "sudo apt-get install -y cuda-toolkit-12-8"
        echo "sudo apt-get install -y cuda-tools-12-8"
        echo "sudo apt-get install -y cuda-libraries-12-8"
        echo "sudo apt-get install -y cuda-libraries-dev-12-8"
        echo ""
        echo "# 5. Add CUDA to your PATH (add to your .bashrc to make permanent)"
        echo "echo 'export PATH=/usr/local/cuda-12.8/bin:\$PATH' >> ~/.bashrc"
        echo "echo 'export LD_LIBRARY_PATH=/usr/local/cuda-12.8/lib64:\$LD_LIBRARY_PATH' >> ~/.bashrc"
        echo "source ~/.bashrc"
        echo ""
        echo "# 6. Verify CUDA installation"
        echo "nvidia-smi"
        echo "nvcc --version"
        echo ""
        echo "# 7. Reboot your system after installation"
        echo "sudo reboot"
        echo ""
        echo "After installing CUDA, run this script again without the --install-cuda flag."
        echo "==================================================================="
        exit 0
    fi
fi

# ===================================================================
# DEPENDENCY SETUP
# ===================================================================

if [ "$SKIP_DEPENDENCIES" = false ]; then
    echo "==================================================================="
    echo "Setting up environment and installing dependencies"
    echo "==================================================================="

    # Check for CUDA/GPU (required for this project)
    echo "Checking CUDA/GPU installation..."

    # Check if NVIDIA driver is available
    if ! command -v nvidia-smi &> /dev/null; then
        echo "ERROR: NVIDIA GPU driver not found. GPU capabilities are required."
        echo "Please install NVIDIA drivers before running this script."
        echo "Run this script with --install-cuda to see installation instructions."
        exit 1
    fi

    # Test GPU
    echo "NVIDIA GPU driver found. Testing with nvidia-smi:"
    nvidia-smi | head -n 10

    # Explicitly set up CUDA 12.8 environment variables, ignoring other CUDA versions
    echo "Enforcing CUDA 12.8 environment..."
    
    # Check if CUDA 12.8 is available
    if [ -d "/usr/local/cuda-12.8" ]; then
        # Force CUDA 12.8 regardless of what's in PATH
        export CUDA_HOME="/usr/local/cuda-12.8"
        export CUDA_PATH="/usr/local/cuda-12.8"
        export CUDA_ROOT="/usr/local/cuda-12.8"
        # Add bin directory to front of PATH
        export PATH="/usr/local/cuda-12.8/bin:$PATH"
        # Add lib64 directory to front of LD_LIBRARY_PATH
        export LD_LIBRARY_PATH="/usr/local/cuda-12.8/lib64:$LD_LIBRARY_PATH"
        # Force nvcc path
        export NVCC_PATH="/usr/local/cuda-12.8/bin/nvcc"
        
        echo "CUDA 12.8 environment variables set:"
        echo "CUDA_HOME=$CUDA_HOME"
        echo "PATH includes: /usr/local/cuda-12.8/bin (at front)"
        echo "LD_LIBRARY_PATH includes: /usr/local/cuda-12.8/lib64 (at front)"
    else
        echo "WARNING: CUDA 12.8 not found. Please install CUDA 12.8 with:"
        echo "  sudo ./install_cuda_12.8.sh"
        
        # Try to find any CUDA installation as fallback
        if [ -d "/usr/local/cuda" ]; then
            # Use generic /usr/local/cuda if it exists (should be a symlink to specific version)
            export CUDA_HOME="/usr/local/cuda"
        else
            # Try to find the newest CUDA version available
            for cuda_version in $(ls -d /usr/local/cuda-* 2>/dev/null | sort -r); do
                export CUDA_HOME="$cuda_version"
                break
            done
        fi
        
        if [ -n "$CUDA_HOME" ]; then
            echo "Falling back to CUDA at $CUDA_HOME"
            export PATH="$CUDA_HOME/bin:$PATH"
            export LD_LIBRARY_PATH="$CUDA_HOME/lib64:$LD_LIBRARY_PATH"
            echo "WARNING: Using $CUDA_HOME instead of CUDA 12.8"
            echo "Some features may not work correctly with this CUDA version."
        fi
    fi

    # Set custom HuggingFace cache directory within our build folder
    export HF_HOME="./build/hf_cache"
    mkdir -p $HF_HOME

    # Make sure we're using the venv pip
    echo "Using pip from the virtual environment"
    export PATH="$(pwd)/venv/bin:$PATH"

    # Ensure pip is properly configured
    echo "Checking pip installation in virtual environment..."
    "${PYTHON_PATH}" -m pip --version || {
        echo "Installing pip in the virtual environment..."
        "${PYTHON_PATH}" -m ensurepip --upgrade
        "${PYTHON_PATH}" -m pip install --upgrade pip
    }

    # Install system dependencies for building C++ extensions and CUDA support
    echo "Installing system dependencies for building extensions and CUDA support..."
    # sudo apt-get update -y #causes errors with ubunu 3.10 python install.
    sudo apt-get install -y build-essential ninja-build
    
    # Check for cuDNN installation (either generic libcudnn or CUDA 12-specific version)
    if ! ldconfig -p | grep -q -E 'libcudnn|libcudnn.*cuda-12'; then
        echo "WARNING: cuDNN libraries not found. ONNX inference with GPU acceleration may not work."
        echo "If you plan to use ONNX with GPU acceleration, please run:"
        echo "  sudo ./install_cuda_12.8.sh"
        echo "This script will install both CUDA 12.8 and cuDNN 9, which are required for GPU-accelerated ONNX inference."
        echo ""
    fi

    # Install specific setuptools version for better compatibility
    echo "Installing specific setuptools version for better compatibility..."
    "${PYTHON_PATH}" -m pip install --upgrade pip setuptools==69.0.2 wheel ninja

    # Check if PyTorch is installed, if not install it
    if ! "${PYTHON_PATH}" -c "import torch" &>/dev/null; then
        echo "Installing PyTorch with CUDA support..."
        "${PYTHON_PATH}" -m pip install torch==2.3.0+cu121 torchvision --index-url https://download.pytorch.org/whl/cu121 --no-cache-dir
    else
        echo "PyTorch is already installed, skipping installation..."
    fi

    # Install required packages with specific versions known to work with Phi-3 models
    echo "Installing required packages with compatible versions..."
    "${PYTHON_PATH}" -m pip install transformers==4.40.2 peft==0.11.1 datasets pandas numpy pillow bitsandbytes==0.45.3
    
    # Install onnx and optimum with specific versions
    "${PYTHON_PATH}" -m pip install onnx==1.16.0 optimum==1.16.0
    
    # For onnxruntime-gpu, try the specific version but fall back to latest if not available
    echo "Installing onnxruntime-gpu with version 1.16.3 (or latest if unavailable)..."
    "${PYTHON_PATH}" -m pip install onnxruntime-gpu==1.16.3 || {
        echo "onnxruntime-gpu 1.16.3 not available for this Python version, using latest compatible version..."
        "${PYTHON_PATH}" -m pip install onnxruntime-gpu
    }
    
    # For onnxruntime-genai, try the specific version but fall back to latest if not available
    echo "Installing onnxruntime-genai with version 0.3.0 (or latest if unavailable)..."
    "${PYTHON_PATH}" -m pip install onnxruntime-genai==0.3.0 || {
        echo "onnxruntime-genai 0.3.0 not available for this Python version, using latest compatible version..."
        "${PYTHON_PATH}" -m pip install onnxruntime-genai
    }
    
    # Install other packages
    "${PYTHON_PATH}" -m pip install fastapi uvicorn python-multipart jinja2 gradio tqdm
    
    # Ensure tqdm is available (needed for progress bars)
    echo "Ensuring tqdm is properly installed (required for data preparation)..."
    ${PYTHON_PATH} -c "import tqdm" || ${PYTHON_PATH} -m pip install --force-reinstall tqdm

    # Install DeepSpeed and its dependencies (for efficient training)
    echo "Installing DeepSpeed and its dependencies (for efficient training)..."
    
    # Check if MPI implementation is installed
    echo "Installing MPI implementation (required for mpi4py)..."
    sudo DEBIAN_FRONTEND=noninteractive apt-get update && sudo DEBIAN_FRONTEND=noninteractive apt-get install -y libopenmpi-dev openmpi-bin python3-dev
    sudo apt-get install -y libopenmpi-dev openmpi-bin
    

    # Install ninja, mpi4py and deepspeed with specific versions and build options
    echo "Installing mpi4py and deepspeed with proper configurations..."
    "${PYTHON_PATH}" -m pip install ninja==1.10.2
    # Ensure Python development headers are installed before mpi4py
    sudo apt-get install -y python3-dev
    "${PYTHON_PATH}" -m pip install --no-build-isolation mpi4py==3.1.5
    
    # Install dependencies needed by deepspeed
    echo "Installing dependencies needed by deepspeed..."
    "${PYTHON_PATH}" -m pip install einops hjson msgpack numpy psutil py-cpuinfo tqdm 
    
    # Install deepspeed with minimal CUDA ops to avoid compilation issues
    echo "Installing deepspeed with minimal CUDA ops..."
    # Set environment variables to help with compilation - explicitly using CUDA 12.8
    export CUDA_HOME="/usr/local/cuda-12.8"
    export CUDA_PATH="/usr/local/cuda-12.8"
    export CUDA_ROOT="/usr/local/cuda-12.8"
    export PATH="/usr/local/cuda-12.8/bin:$PATH"
    export LD_LIBRARY_PATH="/usr/local/cuda-12.8/lib64:$LD_LIBRARY_PATH"
    export NVCC_PATH="/usr/local/cuda-12.8/bin/nvcc"
    export CXX=g++
    export CC=gcc
    
    # Disable problematic CUDA ops for installation
    # This is needed to avoid the dskernels module error
    export DS_BUILD_OPS=0                # Disable building all ops initially
    export DS_BUILD_AIO=0                # Disable async_io
    export DS_BUILD_EVOFORMER_ATTN=0     # Disable evoformer attention
    export DS_BUILD_FP_QUANTIZER=0       # Disable fp quantizer
    export DS_BUILD_GDS=0                # Disable GDS
    export DS_BUILD_FUSED_ADAM=0         # Disable fused Adam
    
    # Create a temporary directory for DeepSpeed builds to avoid path conflicts
    export TORCH_EXTENSIONS_DIR="$(pwd)/build/torch_extensions"
    mkdir -p $TORCH_EXTENSIONS_DIR
    
    # Install deepspeed
    "${PYTHON_PATH}" -m pip install "deepspeed>=0.9.3"
    
    # Install auto-processing dependencies
    echo "Installing auto-processing dependencies..."
    "${PYTHON_PATH}" -m pip install requests PyPDF2
    
    # Install data augmentation dependencies
    echo "Installing data augmentation dependencies..."
    "${PYTHON_PATH}" -m pip install nltk spacy tqdm
    
    # Set build directory for all artifacts
    BUILD_DIR="./build"
    
    # Create build directory structure if it doesn't exist
    mkdir -p $BUILD_DIR/{data,model,onnx_model,evaluation,logs}
fi

# ===================================================================
# ENSURE BUILD DIRECTORY ALWAYS EXISTS
# ===================================================================
# Set build directory for all artifacts (this needs to happen regardless of SKIP_DEPENDENCIES)
BUILD_DIR="./build"

# Create build directory structure if it doesn't exist
mkdir -p $BUILD_DIR/{data,model,onnx_model,evaluation,logs}
mkdir -p $RAW_JSON_DIR $AUGMENTED_JSON_DIR
mkdir -p $PDF_DATA_DIR

# ===================================================================
# RUN PIPELINE STEPS
# ===================================================================

# Step 1 (Optional): Auto-processing raw data
if [ "$AUTO_PROCESS" = true ]; then
    echo "==================================================================="
    echo "Step 1: Auto-processing Raw Data"
    echo "==================================================================="
    log_checkpoint "Step 1: Auto-processing Raw Data started"
    
    # Use hardcoded API key but allow override from command line
    CURRENT_API_KEY="$AUTO_PROCESS_API_KEY"
    if [ ! -z "$API_KEY" ]; then
        CURRENT_API_KEY="$API_KEY"
    fi
    
    # Check that API key is set
    if [ -z "$CURRENT_API_KEY" ] || [ "$CURRENT_API_KEY" = "your_api_key_here" ]; then
        echo "ERROR: API key is required for auto-processing. Either set AUTO_PROCESS_API_KEY in the script or use --api-key=YOUR_API_KEY"
        exit 1
    fi
    
    # Check that raw data path exists
    if [ ! -d "$RAW_DATA_PATH" ]; then
        echo "ERROR: Raw data directory $RAW_DATA_PATH does not exist."
        echo "Directory was created but no PDF documents found. Please add documents to $RAW_DATA_PATH"
        exit 1
    fi
    
    echo "Processing raw data from: $RAW_DATA_PATH"
    echo "Using AI model: $AUTO_PROCESS_MODEL"
    echo "Generating approximately 75 examples per document"
    echo "Using enhanced PDF extraction and content chunking"
    echo "This may take some time for large documents..."
    
    # Use hardcoded endpoint since we're using Azure OpenAI
    CURRENT_ENDPOINT="$AUTO_PROCESS_ENDPOINT"
    
    # Only OpenAI/Azure endpoints are supported now
    
    # Execute the command directly instead of building a string
    echo "Executing auto-processing command..."
    
    # Add image processing flag if requested
    if [ "$INCLUDE_IMAGES" = true ]; then
        echo "Including images in auto-processing"
        "${PYTHON_PATH}" 1_auto_process.py \
            --input_path "${RAW_DATA_PATH}" \
            --output_path "${RAW_JSON_DIR}" \
            --api_key "${CURRENT_API_KEY}" \
            --model "${AUTO_PROCESS_MODEL}" \
            --api_endpoint "${CURRENT_ENDPOINT}" \
            --include_text \
            --batch_size 1 \
            --num_examples_per_doc 35 \
            --include_images
    else
        "${PYTHON_PATH}" 1_auto_process.py \
            --input_path "${RAW_DATA_PATH}" \
            --output_path "${RAW_JSON_DIR}" \
            --api_key "${CURRENT_API_KEY}" \
            --model "${AUTO_PROCESS_MODEL}" \
            --api_endpoint "${CURRENT_ENDPOINT}" \
            --include_text \
            --batch_size 1 \
            --num_examples_per_doc 35
    fi
    
    # Check if the script succeeded
    if [ $? -ne 0 ]; then
        echo "ERROR: Auto-processing failed. Check the error messages above."
        exit 1
    fi
    
    echo "Auto-processing complete. Structured data saved to $RAW_JSON_DIR"
    log_checkpoint "Step 1: Auto-processing Raw Data completed successfully"
fi

# Step 2 (Optional): Augment data
if [ "$AUGMENT_DATA" = true ]; then
    echo "==================================================================="
    echo "Step 2: Augmenting Data"
    echo "==================================================================="
    log_checkpoint "Step 2: Augmenting Data started"
    
    # Determine source for augmentation
    DATA_SOURCE="./sample_data/sample_data.json"
    if [ "$AUTO_PROCESS" = true ]; then
        DATA_SOURCE="$RAW_JSON_DIR/sample_data.json"
    fi
    
    # Run augmentation script using the same API as auto-processing
    CURRENT_API_KEY="$AUTO_PROCESS_API_KEY"
    if [ ! -z "$API_KEY" ]; then
        CURRENT_API_KEY="$API_KEY"
    fi
    
    # Use the same API endpoint as auto-processing
    CURRENT_ENDPOINT="$AUTO_PROCESS_ENDPOINT"
    
    "${PYTHON_PATH}" 2_augment_data.py \
        --input_path "$DATA_SOURCE" \
        --output_path "$AUGMENTED_JSON_DIR/augmented_data.json" \
        --augment_factor 3 \
        --api_key "$CURRENT_API_KEY" \
        --model "$AUTO_PROCESS_MODEL" \
        --api_endpoint "$CURRENT_ENDPOINT" \
        --batch_size 2 \
        --temperature 0.6
    
    # Check if the script succeeded
    if [ $? -ne 0 ]; then
        echo "ERROR: Data augmentation failed. Check the error messages above."
        exit 1
    fi
    
    echo "Data augmentation complete. Augmented data saved to $AUGMENTED_JSON_DIR"
    log_checkpoint "Step 2: Augmenting Data completed successfully"
fi

# Step 3: Data Preparation
if [ "$SKIP_DATA_PREP" = false ]; then
    echo "==================================================================="
    echo "Step 3: Data Preparation"
    echo "==================================================================="
    log_checkpoint "Step 3: Data Preparation started"
    
    # Determine which data source to use based on flags
    DATA_DIR="./sample_data"
    
    if [ "$AUTO_PROCESS" = true ]; then
        DATA_DIR="$RAW_JSON_DIR"
        echo "Using auto-processed data from $DATA_DIR"
    fi
    
    if [ "$AUGMENT_DATA" = true ]; then
        DATA_DIR="$AUGMENTED_JSON_DIR"
        echo "Using augmented data from $DATA_DIR"
    fi
    
    OUTPUT_DATA_DIR="$BUILD_DIR/data"
    
    "${PYTHON_PATH}" 3_prepare_data.py --data_path $DATA_DIR --output_path $OUTPUT_DATA_DIR --format auto
    log_checkpoint "Step 3: Data Preparation completed successfully"
else
    echo "==================================================================="
    echo "Step 3: Data Preparation (SKIPPED)"
    echo "==================================================================="
    echo "Using existing data in $BUILD_DIR/data"
fi

# Step 4: Fine-tuning
if [ "$SKIP_TRAINING" = false ]; then
    echo "==================================================================="
    echo "Step 4: Model Fine-tuning"
    echo "==================================================================="
    log_checkpoint "Step 4: Model Fine-tuning started"
    DATA_FILE="$BUILD_DIR/data/train.json"
    OUTPUT_MODEL_DIR="$BUILD_DIR/model"
    
    # Create config directory for DeepSpeed within the build folder
    mkdir -p "$BUILD_DIR/config"
    DS_CONFIG_PATH="$BUILD_DIR/config/ds_config.json"
    mkdir -p "$OUTPUT_MODEL_DIR"
    
    # Set up training arguments
    TRAINING_ARGS="--data_path $DATA_FILE --output_dir $OUTPUT_MODEL_DIR"
    TRAINING_ARGS="$TRAINING_ARGS --model_id $PHI_MODEL_ID" 
    TRAINING_ARGS="$TRAINING_ARGS --num_train_epochs 15 --per_device_train_batch_size 1"
    TRAINING_ARGS="$TRAINING_ARGS --gradient_accumulation_steps 16 --learning_rate 5e-5"
    TRAINING_ARGS="$TRAINING_ARGS --bf16 --lora_enable --lora_rank 16 --lora_alpha 32"
    TRAINING_ARGS="$TRAINING_ARGS --model_max_length 4096"  # Increased max length to capture more context
    TRAINING_ARGS="$TRAINING_ARGS --deepspeed $DS_CONFIG_PATH"
    
    # Create optimized DeepSpeed config
    mkdir -p $(dirname "$DS_CONFIG_PATH")
    cat > "$DS_CONFIG_PATH" << 'EOF_DEEPSPEED'
{
  "fp16": {
    "enabled": "auto",
    "loss_scale": 0,
    "loss_scale_window": 1000,
    "initial_scale_power": 16,
    "hysteresis": 2,
    "min_loss_scale": 1
  },
  "bf16": {
    "enabled": "auto"
  },
  "optimizer": {
    "type": "AdamW",
    "params": {
      "lr": "auto",
      "betas": "auto",
      "eps": "auto",
      "weight_decay": "auto"
    }
  },
  "scheduler": {
    "type": "WarmupLR",
    "params": {
      "warmup_min_lr": 0,
      "warmup_max_lr": "auto",
      "warmup_num_steps": "auto"
    }
  },
  "zero_optimization": {
    "stage": 2,
    "allgather_partitions": true,
    "allgather_bucket_size": 2e8,
    "reduce_scatter": true,
    "reduce_bucket_size": 2e8,
    "overlap_comm": true,
    "contiguous_gradients": true,
    "cpu_offload": false
  },
  "gradient_accumulation_steps": "auto",
  "gradient_clipping": 1.0,
  "train_batch_size": "auto",
  "train_micro_batch_size_per_gpu": "auto",
  "steps_per_print": 10
}
EOF_DEEPSPEED
    
    # Run training script
    "${PYTHON_PATH}" 4_finetune.py $TRAINING_ARGS
    log_checkpoint "Step 4: Model Fine-tuning completed successfully"
else
    echo "==================================================================="
    echo "Step 4: Model Fine-tuning (SKIPPED)"
    echo "==================================================================="
    echo "Using existing model in $BUILD_DIR/model"
fi

# Step 6: ONNX Conversion
if [ "$SKIP_ONNX" = false ]; then
    echo "==================================================================="
    echo "Step 6: Converting to ONNX format"
    echo "==================================================================="
    log_checkpoint "Step 6: Converting to ONNX format started"
    MODEL_DIR="$BUILD_DIR/model"
    ONNX_DIR="$BUILD_DIR/onnx_model"
    
    "${PYTHON_PATH}" 6_convert_to_onnx.py --model_path $MODEL_DIR --output_path $ONNX_DIR --optimize
    log_checkpoint "Step 6: Converting to ONNX format completed successfully"
else
    echo "==================================================================="
    echo "Step 6: Converting to ONNX format (SKIPPED)"
    echo "==================================================================="
    echo "Using existing ONNX model in $BUILD_DIR/onnx_model (if available)"
fi

# Step 5: Model Evaluation
if [ "$SKIP_EVAL" = false ]; then
    echo "==================================================================="
    echo "Step 5: Model Evaluation"
    echo "==================================================================="
    log_checkpoint "Step 5: Model Evaluation started"
    MODEL_DIR="$BUILD_DIR/model"
    DATA_DIR="$BUILD_DIR/data"
    EVAL_DIR="$BUILD_DIR/evaluation"
    mkdir -p $EVAL_DIR

    # Install evaluation dependencies
    echo "Installing evaluation dependencies..."
    "${PYTHON_PATH}" -m pip install nltk rouge-score

    # Run evaluation script
    echo "Evaluating model performance..."
    "${PYTHON_PATH}" 5_evaluate_model.py \
        --model_path $MODEL_DIR \
        --data_path $DATA_DIR/val.json \
        --output_path $EVAL_DIR/eval_results.json \
        --max_new_tokens 512

    # Display evaluation summary
    if [ -f "$EVAL_DIR/eval_results.json" ]; then
        echo "Evaluation summary:"
        echo "Extracting metrics from evaluation results..."
        
        # Using a more robust approach to extract metrics
        python3 -c "
import json
import sys

try:
    with open('$EVAL_DIR/eval_results.json', 'r') as f:
        data = json.load(f)
    metrics = data.get('average_metrics', {})
    print('\n  BLEU-1:    {:.4f}'.format(metrics.get('bleu_1', 0.0)))
    print('  BLEU-4:    {:.4f}'.format(metrics.get('bleu_4', 0.0)))
    print('  ROUGE-1:   {:.4f}'.format(metrics.get('rouge_1', 0.0)))
    print('  ROUGE-L:   {:.4f}'.format(metrics.get('rouge_l', 0.0)))
    if metrics.get('perplexity', float('inf')) == float('inf'):
        print('  Perplexity: inf')
    else:
        print('  Perplexity: {:.4f}'.format(metrics.get('perplexity', 0.0)))
except Exception as e:
    print('Error parsing evaluation results: {}'.format(e))
"
        echo ""
        echo "Detailed evaluation results saved to: $EVAL_DIR/eval_results.json"
        log_checkpoint "Step 5: Model Evaluation completed successfully"
    else
        echo "Evaluation failed or results not saved."
    fi
else
    echo "==================================================================="
    echo "Step 5: Model Evaluation (SKIPPED)"
    echo "==================================================================="
    echo "Skipping evaluation as requested with --skip-eval flag"
fi

# Step 7: Inference and API Server (Optional)
if [ "$API_SERVER" = true ]; then
    echo "==================================================================="
    echo "Step 7: Starting API Server"
    echo "==================================================================="
    log_checkpoint "Step 7: Starting API Server"
    MODEL_DIR="$BUILD_DIR/model"
    ONNX_DIR="$BUILD_DIR/onnx_model"

    # ONNX usage is controlled via the --use-onnx flag

    # Check if ONNX model exists and should be used
    if [ "$USE_ONNX" = true ] && [ -d "$ONNX_DIR" ] && [ -f "$ONNX_DIR/model.onnx" ]; then
        echo "Using ONNX model for API server..."
        
        # Warn about CUDA/cuDNN if they're not detected but ONNX is requested
        if ! ldconfig -p | grep -q -E 'libcudnn|libcudnn.*cuda-12'; then
            echo "WARNING: cuDNN libraries not found, but ONNX mode was requested."
            echo "ONNX inference will attempt to use GPU acceleration but may fall back to CPU."
            echo "For optimal performance with ONNX, install CUDA 12.8 and cuDNN 9:"
            echo "  sudo ./install_cuda_12.8.sh"
            echo ""
        fi
        
        "${PYTHON_PATH}" 7_host_api_server.py --model_path $ONNX_DIR --onnx --host 0.0.0.0 --port 8000
    else
        # Fall back to PyTorch model if ONNX is not available or not requested
        if [ "$USE_ONNX" = true ]; then
            echo "ONNX model requested but not available. Using PyTorch model instead."
        else
            echo "Using PyTorch model for API server..."
        fi
        "${PYTHON_PATH}" 7_host_api_server.py --model_path $MODEL_DIR --host 0.0.0.0 --port 8000
    fi
else
    echo "==================================================================="
    echo "Step 7: API Server (SKIPPED)"
    echo "==================================================================="
    echo "API server was not started. Use --api-server flag to start it."
fi

echo "==================================================================="
echo "Pipeline completed successfully!"
echo "All build artifacts are in: $BUILD_DIR"
echo "  - Fine-tuned model: $BUILD_DIR/model"
echo "  - ONNX model: $BUILD_DIR/onnx_model"
echo "  - Data: $BUILD_DIR/data"
echo "  - Evaluation results: $BUILD_DIR/evaluation"
echo "==================================================================="
log_checkpoint "Pipeline completed successfully"