#!/bin/bash
# Phi-3-mini API Server shortcut
# This script is a convenient shortcut to start just the API server

# Run the main script with all steps skipped except for the API server
./Pipeline_Phi.sh --skip-data-prep --skip-training --skip-onnx --skip-eval --skip-dependencies --api-server "$@"