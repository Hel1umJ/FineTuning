#!/bin/bash
# CUDA 12.8 Installation Script for Ubuntu on WSL or Linux
# This script installs CUDA 12.8 using apt package manager
# Run with sudo: sudo ./install_cuda_12.8.sh [--linux]

set -e  # Exit on any error

# Parse command line arguments
LINUX_ENV=false
for arg in "$@"; do
  case $arg in
    --linux)
      LINUX_ENV=true
      shift
      ;;
    *)
      # Unknown option
      ;;
  esac
done

#MAKE SURE YOU ARE RUNNING WSL 2: 
#wsl --set-default-version 2
#wsl --update

#Make sure you have the windows GPU drivers as well - Search your GPU (OR download from geforce experience) THEN REBOOT your computer, and recheck nvidia-smi
# https://www.nvidia.com/en-us/drivers/

#Nvidia toolkit docs. Note: WSL2 already comes with drivers, very easy to override them. ALl you need is 1. WOrking driver on windows, 2. Toolkit on WSL.
# https://docs.nvidia.com/cuda/wsl-user-guide/index.html
# https://developer.nvidia.com/cuda-downloads?target_os=Linux&target_arch=x86_64&Distribution=WSL-Ubuntu&target_version=2.0&target_type=deb_local

#cuDNN: https://docs.nvidia.com/deeplearning/cudnn/backend/v9.1.0/installation/linux.html#:~:text=Download%20the%20Debian%20package%20either%20from%20the%20developer,and%20choose%20Deb%20%28local%29%20as%20the%20installer%20type.

#Cuda download for linux: https://developer.nvidia.com/cuda-downloads?target_os=Linux&target_arch=x86_64&Distribution=Ubuntu&target_version=22.04&target_type=deb_local 

#Linux version: Ubuntu 22.04

#Python Version: 3.12.3
#  To set Python 3.12.3 as the default on Ubuntu:

#   1. Install Python 3.12.3:
#   sudo apt update
#   sudo apt install software-properties-common
#   sudo apt install python3-apt
#   sudo add-apt-repository ppa:deadsnakes/ppa
#   sudo apt install python3.12
#   2.Install Python 3.12 venv
#   sudo apt install python3.12-venv
#   3.Set higher priority for Python 3.12
#   sudo update-alternatives --install /usr/bin/python3 python3 /usr/bin/python3.12 2
#   sudo update-alternatives --install /usr/bin/python3 python3 /usr/bin/python3.10 1
#   sudo update-alternatives --config python3 # check alternatives.
#   sudo update-alternatives --set python3 /usr/bin/python3.12 #? What does this do again.
#   3. Verify with python3 --version

#   You may need to reinstall python3-distutils for the new version.






# Python setup - only if running on a Linux environment (with --linux flag)
if [ "$LINUX_ENV" = true ]; then
    echo "============================================================"
    echo "Setting up Python environment (Linux mode)"
    echo "============================================================"
    
    sudo apt-get update
    sudo apt-get upgrade -y
    sudo apt-get install -y software-properties-common
    sudo add-apt-repository -y ppa:deadsnakes/ppa
    
    # Install Python 3.12 from deadsnakes PPA
    echo "Installing Python 3.12 (latest available in PPA)..."
    sudo apt-get install -y python3.12 python3.12-venv python3.12-dev
    
    # Set up alternatives to prefer Python 3.12
    sudo update-alternatives --install /usr/bin/python3 python3 /usr/bin/python3.12 2
    
    # Try to install python3-pip and other dev packages
    sudo apt-get install -y python3-pip python3-dev
    
    # Handle python3-distutils not being available
    echo "Attempting to install python3-distutils or alternatives..."
    if ! sudo apt-get install -y python3-distutils; then
        echo "python3-distutils package not found, trying python3.12-distutils or distutils-extra..."
        sudo apt-get install -y python3.12-distutils || sudo apt-get install -y python3-distutils-extra || echo "Could not install any distutils package, continuing anyway"
    fi
    
    # Install pip for Python 3.12 using wget method
    echo "Installing pip for Python 3.12 using wget method..."
    wget https://bootstrap.pypa.io/get-pip.py
    # Use --break-system-packages to override the externally managed environment warning
    sudo python3.12 get-pip.py --break-system-packages
    
    # Verify Python version
    echo "Verifying Python installation:"
    python3.12 --version
    
    echo "NOTE: Python environment setup completed for Linux mode"
    echo "If you encounter issues with ONNX conversion, consider using python3.10 instead"
else
    echo "Skipping Python setup (WSL mode - using Python from Windows host)"
fi

# Fix Python apt_pkg module for Python 3.12
echo "============================================================"
echo "Fixing apt_pkg module for Python 3.12"
echo "============================================================"

# Install python3-apt for the system Python
sudo apt-get install -y python3-apt

# Find the location of apt_pkg.cpython*.so file
APT_PKG_PATH=$(find /usr/lib/python3/dist-packages -name "apt_pkg.cpython*.so" | head -n 1)

if [ -z "$APT_PKG_PATH" ]; then
  echo "WARNING: Could not find apt_pkg.so file. Will continue with installation."
else
  # Create the directory for Python 3.12 if it doesn't exist
  sudo mkdir -p /usr/lib/python3/dist-packages/apt_pkg

  # Create a symbolic link to the apt_pkg.so file for Python 3.12
  PYTHON_VERSION=$(python3 --version | cut -d ' ' -f 2 | cut -d '.' -f 1-2)
  PYTHON_SITE_DIR="/usr/lib/python3/dist-packages"
  DEST_DIR="/usr/lib/python$PYTHON_VERSION/dist-packages"

  sudo mkdir -p "$DEST_DIR"
  sudo ln -sf "$APT_PKG_PATH" "$DEST_DIR/apt_pkg.so"

  # Fix the paths automatically for current Python version
  CURRENT_PYTHON_PATH=$(which python3)
  CURRENT_PYTHON_VERSION=$($CURRENT_PYTHON_PATH --version | cut -d ' ' -f 2 | cut -d '.' -f 1-2)
  CURRENT_PYTHON_DIR=$(dirname $(dirname $CURRENT_PYTHON_PATH))
  CURRENT_PYTHON_SITE_DIR="$CURRENT_PYTHON_DIR/lib/python$CURRENT_PYTHON_VERSION/site-packages"

  echo "Creating link for current Python $CURRENT_PYTHON_VERSION at $CURRENT_PYTHON_SITE_DIR"
  sudo mkdir -p "$CURRENT_PYTHON_SITE_DIR"
  sudo ln -sf "$APT_PKG_PATH" "$CURRENT_PYTHON_SITE_DIR/apt_pkg.so"

  # Test if the fix worked
  if python3 -c 'import apt_pkg' 2>/dev/null; then
    echo "apt_pkg module successfully fixed for Python $PYTHON_VERSION!"
  else
    echo "WARNING: apt_pkg module fix was not successful, but continuing with installation."
  fi
fi

# Create a temporary directory for downloads
TEMP_DIR=$(mktemp -d)
cd $TEMP_DIR

if [ "$LINUX_ENV" = true ]; then
  echo "============================================================"
  echo "Installing CUDA 12.8 for Native Linux"
  echo "============================================================"
  
  wget https://developer.download.nvidia.com/compute/cuda/repos/ubuntu2204/x86_64/cuda-ubuntu2204.pin
  sudo mv cuda-ubuntu2204.pin /etc/apt/preferences.d/cuda-repository-pin-600
  wget https://developer.download.nvidia.com/compute/cuda/12.8.1/local_installers/cuda-repo-ubuntu2204-12-8-local_12.8.1-570.124.06-1_amd64.deb
  sudo dpkg -i cuda-repo-ubuntu2204-12-8-local_12.8.1-570.124.06-1_amd64.deb
  sudo cp /var/cuda-repo-ubuntu2204-12-8-local/cuda-*-keyring.gpg /usr/share/keyrings/
  sudo apt-get update
  sudo apt-get -y install cuda-toolkit-12-8
else
  echo "============================================================"
  echo "Installing CUDA 12.8 for Ubuntu/WSL"
  echo "============================================================"
  
  wget https://developer.download.nvidia.com/compute/cuda/repos/wsl-ubuntu/x86_64/cuda-wsl-ubuntu.pin
  sudo mv cuda-wsl-ubuntu.pin /etc/apt/preferences.d/cuda-repository-pin-600
  wget https://developer.download.nvidia.com/compute/cuda/12.8.1/local_installers/cuda-repo-wsl-ubuntu-12-8-local_12.8.1-1_amd64.deb
  # Make sure the .deb file exists before trying to install it
  if [ -f "cuda-repo-wsl-ubuntu-12-8-local_12.8.1-1_amd64.deb" ]; then
      sudo dpkg -i cuda-repo-wsl-ubuntu-12-8-local_12.8.1-1_amd64.deb
  else
      echo "ERROR: Downloaded CUDA package not found!"
      echo "Expected: $(pwd)/cuda-repo-wsl-ubuntu-12-8-local_12.8.1-1_amd64.deb"
      ls -la
      exit 1
  fi
  sudo cp /var/cuda-repo-wsl-ubuntu-12-8-local/cuda-*-keyring.gpg /usr/share/keyrings/
  sudo apt-get update
  sudo apt-get -y install cuda-toolkit-12-8
fi

# Return to original directory
cd -

# Clean up the temporary directory
rm -rf $TEMP_DIR

# Install nvidia-smi utility (only needed for WSL)
if [ "$LINUX_ENV" = false ]; then
  echo "Installing nvidia-smi utility..."
  sudo apt-get install -y nvidia-utils-535  # This package contains nvidia-smi
fi

# Install NVIDIA drivers compatible with CUDA 12.8
echo "============================================================"
echo "Installing NVIDIA drivers compatible with CUDA 12.8"
echo "============================================================"

if [ "$LINUX_ENV" = true ]; then
  # For native Linux, install the appropriate driver
  echo "Installing NVIDIA driver for native Linux..."
  sudo apt-get install -y nvidia-driver-535
else
  # For WSL, just make sure we have the utils
  echo "Using NVIDIA driver from Windows host for WSL..."
fi

# Make CUDA 12.8 the default and force it as the only CUDA version to use
echo "Setting CUDA 12.8 as the default and enforcing it as the primary CUDA version..."
sudo update-alternatives --set cuda /usr/local/cuda-12.8 || true

# Ensure other CUDA versions don't interfere by explicitly setting CUDA_HOME and related variables
echo "Setting up CUDA environment variables to enforce CUDA 12.8..."
cat > /tmp/cuda_12_8_config.sh << 'EOF'
# CUDA 12.8 environment variables - enforced configuration
export CUDA_HOME=/usr/local/cuda-12.8
export CUDA_PATH=/usr/local/cuda-12.8
export CUDA_ROOT=/usr/local/cuda-12.8
# Ensure CUDA 12.8 binaries are first in PATH
export PATH=/usr/local/cuda-12.8/bin:$PATH
# Ensure CUDA 12.8 libraries are first in LD_LIBRARY_PATH
export LD_LIBRARY_PATH=/usr/local/cuda-12.8/lib64:$LD_LIBRARY_PATH
# Force nvcc to use CUDA 12.8
export NVCC_PATH=/usr/local/cuda-12.8/bin/nvcc
EOF

# Add to global environment and user profile
sudo cp /tmp/cuda_12_8_config.sh /etc/profile.d/cuda_12_8.sh
cat /tmp/cuda_12_8_config.sh >> ~/.bashrc
rm /tmp/cuda_12_8_config.sh

# Create symbolic links to ensure CUDA 12.8 is used over any other version
echo "Creating symbolic links to enforce CUDA 12.8..."
sudo ln -sf /usr/local/cuda-12.8/bin/nvcc /usr/local/bin/nvcc
sudo ln -sf /usr/local/cuda-12.8 /usr/local/cuda

# Install cuDNN 9 for CUDA 12.8
echo "============================================================"
echo "Installing cuDNN 9 for CUDA 12.8"
echo "============================================================"

# Determine system architecture and distribution
ARCH=$(dpkg --print-architecture)
DISTRO=$(lsb_release -cs)

# Create temporary directory for downloads
TEMP_DIR=$(mktemp -d)
cd $TEMP_DIR

# Download cuDNN package
# Using cuDNN 9.0.0 for CUDA 12.x
echo "Downloading cuDNN 9.0.0 package..."
wget https://developer.download.nvidia.com/compute/cudnn/9.0.0/local_installers/cudnn-local-repo-ubuntu2204-9.0.0_1.0-1_amd64.deb

# Make sure the .deb file exists before trying to install it
if [ -f "cudnn-local-repo-ubuntu2204-9.0.0_1.0-1_amd64.deb" ]; then
    # Install the repository package
    sudo dpkg -i cudnn-local-repo-ubuntu2204-9.0.0_1.0-1_amd64.deb
else
    echo "ERROR: Downloaded cuDNN package not found!"
    echo "Expected: $(pwd)/cudnn-local-repo-ubuntu2204-9.0.0_1.0-1_amd64.deb"
    ls -la
    exit 1
fi

# Import CUDA GPG key
sudo cp /var/cudnn-local-repo-ubuntu2204-9.0.0/cudnn-*-keyring.gpg /usr/share/keyrings/

# Update package list
sudo apt-get update

# Install cuDNN packages (explicitly for CUDA 12)
sudo apt-get install -y libcudnn9-cuda-12 libcudnn9-dev-cuda-12

# Clean up
cd -
rm -rf $TEMP_DIR

echo "cuDNN 9 installation completed."

# Note: The bitsandbytes installation has been removed as it should be handled by the main pipeline

echo "============================================================"
echo "CUDA 12.8 and cuDNN 9 installation completed"
echo "============================================================"
echo "Please run the following commands to update your current shell:"
echo "source ~/.bashrc"
echo ""
echo "Verify installation with:"
echo "nvidia-smi"
echo "nvcc --version"
echo "ldconfig -p | grep libcudnn"
echo ""
echo "To test PyTorch CUDA support:"
echo "python3 -c \"import torch; print('CUDA available:', torch.cuda.is_available()); print('GPU count:', torch.cuda.device_count())\""
echo ""
echo "Please reboot your system to complete the installation:"
echo "sudo reboot"
echo "============================================================"