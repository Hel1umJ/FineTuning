"""
Phi-3-mini Data Augmentation Script (Step 2)

This script performs data augmentation on the input JSON data by leveraging the same
AI model used for auto-processing to generate additional variations of existing examples.

Usage:
    python 2_augment_data.py --input_path ./build/data/RAW_JSON/sample_data.json --output_path ./build/data/AUGMENTED_JSON/augmented_data.json --augment_factor 4
"""

import os
import json
import time
import argparse
import logging
import requests
import random
from pathlib import Path
from typing import List, Dict, Any, Optional
from tqdm import tqdm

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger(__name__)

def parse_args():
    parser = argparse.ArgumentParser(description="Augment data for Phi-3-mini fine-tuning using AI")
    parser.add_argument(
        "--input_path",
        type=str,
        required=True,
        help="Path to the input JSON data file"
    )
    parser.add_argument(
        "--output_path",
        type=str,
        required=True,
        help="Path to save the augmented data"
    )
    parser.add_argument(
        "--augment_factor",
        type=int,
        default=4,
        help="Number of augmented examples to generate per original example"
    )
    parser.add_argument(
        "--api_key",
        type=str,
        default=None,
        help="API key for the AI model"
    )
    parser.add_argument(
        "--model",
        type=str,
        default="gpt-4o",
        help="Model to use for augmentation (gpt-4o, gpt-4-turbo, etc.)"
    )
    parser.add_argument(
        "--api_endpoint",
        type=str,
        default="https://api.openai.com/v1/chat/completions",
        help="API endpoint for the AI model"
    )
    parser.add_argument(
        "--batch_size",
        type=int,
        default=5,
        help="Number of examples to send in each API request"
    )
    parser.add_argument(
        "--temperature",
        type=float,
        default=0.7,
        help="Temperature for generation (higher = more creative)"
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=42,
        help="Random seed for reproducibility"
    )
    return parser.parse_args()

def load_data(input_path: str) -> List[Dict[str, Any]]:
    """Load data from JSON file"""
    try:
        with open(input_path, 'r') as f:
            data = json.load(f)
        logger.info(f"Loaded {len(data)} examples from {input_path}")
        return data
    except Exception as e:
        logger.error(f"Error loading data from {input_path}: {e}")
        raise

def save_data(data: List[Dict[str, Any]], output_path: str):
    """Save data to JSON file"""
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    try:
        with open(output_path, 'w') as f:
            json.dump(data, f, indent=2)
        logger.info(f"Saved {len(data)} examples to {output_path}")
    except Exception as e:
        logger.error(f"Error saving data to {output_path}: {e}")
        raise

def clean_json_string(json_string):
    """Clean a JSON string to make it parseable, handling common issues."""
    if not json_string:
        return json_string
        
    # Step 1: Find the outermost array brackets if they exist
    if '[' in json_string and ']' in json_string:
        start_idx = json_string.find('[')
        end_idx = json_string.rfind(']') + 1
        if start_idx >= 0 and end_idx > start_idx:
            json_string = json_string[start_idx:end_idx]
    
    # Step 2: Replace invalid control characters
    import re
    # Remove all control characters except \n, \r, \t
    json_string = re.sub(r'[\x00-\x08\x0B\x0C\x0E-\x1F\x7F-\x9F]', '', json_string)
    
    # Step 3: Fix common JSON formatting issues
    # Fix trailing commas in arrays
    json_string = re.sub(r',\s*]', ']', json_string)
    # Fix trailing commas in objects
    json_string = re.sub(r',\s*}', '}', json_string)
    
    # Step 4: Handle truncated JSON
    # If we don't have a closing bracket but do have an opening one, it might be truncated
    if '[' in json_string and ']' not in json_string:
        logger.warning("JSON appears to be truncated (missing closing brackets)")
        # Extract complete objects where possible
        try:
            # Find all complete objects and build a valid array
            import json as json_module
            objects = []
            current_pos = json_string.find('{')
            
            while current_pos >= 0:
                # Try to find a complete object
                open_braces = 1
                in_string = False
                escape_next = False
                
                for i in range(current_pos + 1, len(json_string)):
                    char = json_string[i]
                    
                    # Handle string delimiters
                    if char == '"' and not escape_next:
                        in_string = not in_string
                    
                    # Handle escape character
                    if char == '\\' and not escape_next:
                        escape_next = True
                    else:
                        escape_next = False
                    
                    # Count braces if not in a string
                    if not in_string:
                        if char == '{':
                            open_braces += 1
                        elif char == '}':
                            open_braces -= 1
                            
                        # If we've closed all braces, we have a complete object
                        if open_braces == 0:
                            # Found a complete object
                            obj_str = json_string[current_pos:i+1]
                            try:
                                # Validate it's actually valid JSON
                                obj = json_module.loads(obj_str)
                                objects.append(obj)
                                logger.debug(f"Extracted complete object from truncated JSON")
                            except:
                                logger.debug(f"Found object structure but it's not valid JSON")
                            
                            # Move past this object
                            current_pos = json_string.find('{', i + 1)
                            break
                
                # If we didn't find a complete object or we're at the end
                if open_braces > 0 or i == len(json_string) - 1:
                    # No more complete objects
                    break
            
            # If we found any complete objects, create a valid JSON array
            if objects:
                logger.info(f"Recovered {len(objects)} complete objects from truncated JSON")
                return json_module.dumps(objects)
            else:
                logger.warning("Could not recover any complete objects from truncated JSON")
        except Exception as e:
            logger.error(f"Error while trying to recover from truncated JSON: {e}")
    
    # Step 5: Ensure we have a valid JSON array
    json_string = json_string.strip()
    if not json_string.startswith('['):
        json_string = '[' + json_string
    if not json_string.endswith(']'):
        json_string = json_string + ']'
    
    return json_string

def extract_and_parse_json(result_text):
    """Extract JSON from API result text and parse it."""
    if not result_text:
        return None
        
    # Try to extract JSON from the result if it's wrapped in markdown code blocks
    if "```json" in result_text:
        logger.debug("Found ```json marker in response")
        result_text = result_text.split("```json")[1].split("```")[0].strip()
    elif "```" in result_text:
        logger.debug("Found ``` marker in response")
        result_text = result_text.split("```")[1].split("```")[0].strip()
    
    # Extract JSON array if present
    if '[' in result_text and ']' in result_text:
        first_bracket = result_text.find('[')
        last_bracket = result_text.rfind(']')
        if first_bracket > 0 or last_bracket < len(result_text) - 1:
            logger.debug(f"Trimming result to extract JSON array")
            result_text = result_text[first_bracket:last_bracket + 1]
    
    # Clean the JSON string
    result_text = clean_json_string(result_text)
    
    # Try parsing the JSON
    try:
        json_data = json.loads(result_text)
        return json_data
    except json.JSONDecodeError as e:
        logger.error(f"JSON decode error: {e}")
        logger.debug(f"Failed JSON (first 100 chars): {result_text[:100]}...")
        # Save the failed JSON in build/logs directory for debugging
        try:
            logs_dir = Path("./build/logs")
            logs_dir.mkdir(parents=True, exist_ok=True)
            debug_file = logs_dir / f"debug_failed_json_{int(time.time())}.txt"
            with open(debug_file, 'w') as f:
                f.write(result_text)
            logger.debug(f"Saved failed JSON to {debug_file}")
        except Exception as save_error:
            logger.error(f"Could not save debug file: {save_error}")
        return None

def get_augmentation_prompt(examples, augment_factor):
    """Create a prompt for AI to generate augmented examples"""
    
    system_prompt = f"""You are an expert data augmentation assistant for creating training data for language models.
Your task is to generate variations of example question-answer pairs that maintain the same meaning and factual content, 
but with different wording, structure, or style.

For each example provided, you will create {augment_factor} unique variations that:
1. Preserve the exact technical information and factual content
2. Use different wording, sentence structure, or phrasing
3. Maintain the same level of specificity and technical detail
4. Keep any references to specific documents or sections exactly the same

IMPORTANT: Each augmented example MUST:
- Contain the EXACT SAME FACTS as the original
- Not add any information not present in the original
- Not remove any information present in the original
- Preserve the document reference section exactly as written
- Strictly maintain the JSON structure of the original

Format your response as a valid JSON array of objects."""

    user_prompt = f"""Here are examples to augment. For each example, create {augment_factor} variations 
while preserving the exact meaning, facts, and technical information:

{json.dumps(examples, indent=2)}

Return all the augmented examples as a single JSON array. Include variations for all provided examples.
Your output must be valid JSON and nothing else. Do not include any explanations or text outside the JSON array."""

    return system_prompt, user_prompt

def call_ai_api(examples, args, max_retries=3, timeout=60):
    """Call AI API to generate augmented examples with timeout and retry logic"""
    
    system_prompt, user_prompt = get_augmentation_prompt(examples, args.augment_factor)
    
    # Determine API type based on endpoint URL
    is_azure = "azure" in args.api_endpoint
    
    # Prepare the request based on the API provider
    if "openai" in args.api_endpoint or "azure" in args.api_endpoint:
        # OpenAI/Azure API format
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]
        
        payload = {
            "messages": messages,
            "temperature": args.temperature,
            "max_tokens": 4000  # Need larger token limit for augmentations
        }
        
        if not is_azure:
            payload["model"] = args.model
        
        headers = {
            "Content-Type": "application/json"
        }
        
        if is_azure:
            headers["api-key"] = args.api_key
            logger.debug(f"Using Azure OpenAI API with endpoint: {args.api_endpoint}")
        else:
            headers["Authorization"] = f"Bearer {args.api_key}"
            logger.debug(f"Using OpenAI API with endpoint: {args.api_endpoint}")
    
    
    else:
        # Generic fallback format
        payload = {
            "model": args.model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            "temperature": args.temperature,
            "max_tokens": 4000
        }
        
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {args.api_key}"
        }
    
    # Make API request with retries and timeout
    for retry in range(max_retries):
        try:
            logger.debug(f"Making API request to: {args.api_endpoint} (attempt {retry+1}/{max_retries})")
            
            # Add timeout to prevent indefinite hanging
            response = requests.post(args.api_endpoint, headers=headers, json=payload, timeout=timeout)
            
            logger.debug(f"API response status code: {response.status_code}")
            
            if response.status_code >= 400:
                logger.error(f"API error: HTTP {response.status_code}")
                logger.error(f"Response content: {response.text}")
                # For certain error codes, we should wait and retry
                if response.status_code in [429, 500, 502, 503, 504]:
                    wait_time = min(2 ** retry * 5, 60)  # Exponential backoff with max 60s
                    logger.warning(f"Retrying in {wait_time} seconds...")
                    time.sleep(wait_time)
                    continue
                return None
                
            response.raise_for_status()
            response_json = response.json()
            
            # Extract text from different API formats
            if "openai" in args.api_endpoint or "azure" in args.api_endpoint:
                if "choices" not in response_json or not response_json.get("choices"):
                    logger.error(f"Missing 'choices' in API response: {response_json}")
                    return None
                    
                result = response_json.get("choices", [{}])[0].get("message", {}).get("content", "")
                
            # Only OpenAI/Azure APIs are supported now
            else:
                result = response_json.get("response", "")
                
            return result
        
        except requests.exceptions.Timeout:
            logger.error(f"API request timed out after {timeout} seconds (attempt {retry+1}/{max_retries})")
            # Don't retry on the last attempt
            if retry < max_retries - 1:
                logger.info(f"Retrying with increased timeout...")
                timeout = timeout * 1.5  # Increase timeout for next retry
                continue
            return None
            
        except requests.exceptions.ConnectionError as e:
            logger.error(f"Connection error: {e} (attempt {retry+1}/{max_retries})")
            if retry < max_retries - 1:
                wait_time = min(2 ** retry * 5, 60)
                logger.warning(f"Retrying in {wait_time} seconds...")
                time.sleep(wait_time)
                continue
            return None
            
        except Exception as e:
            logger.error(f"API call error: {e} (attempt {retry+1}/{max_retries})")
            if retry < max_retries - 1:
                wait_time = min(2 ** retry * 3, 30)
                logger.warning(f"Retrying in {wait_time} seconds...")
                time.sleep(wait_time)
                continue
            return None
    
    logger.error("All API call attempts failed")
    return None

def augment_data_in_batches(data, args, max_consecutive_failures=3, progress_save_interval=5):
    """Augment data by sending batches to AI API with safeguards against hanging"""
    
    # If no API key is provided, try to get it from environment or hardcoded defaults
    if not args.api_key:
        # Try environment variable
        args.api_key = os.environ.get("OPENAI_API_KEY")
        
        # If still not available, check if we have a hardcoded value in the Azure endpoint path
        if not args.api_key and "azure" in args.api_endpoint:
            # This is just a placeholder, the actual API key should be provided by the user
            args.api_key = "BM1lfygoycUvEg4Gak6qrGkIpzCNG99L42uC2xa3gwrBNKmPBjRjJQQJ99ALAC4f1cMXJ3w3AAABACOGhB6m"
            
    # Verify we have an API key
    if not args.api_key:
        logger.error("No API key provided. Please provide an API key with --api_key or set OPENAI_API_KEY environment variable.")
        return []
    
    all_augmented_data = []
    consecutive_failures = 0
    batch_start_time = time.time()
    last_progress_save_time = time.time()
    progress_file = Path("./build/logs/augmentation_progress.json")
    
    # Check if we can resume from previous progress
    if progress_file.exists():
        try:
            with open(progress_file, 'r') as f:
                saved_progress = json.load(f)
                all_augmented_data = saved_progress.get('augmented_data', [])
                last_processed_index = saved_progress.get('last_processed_index', 0)
                if last_processed_index > 0:
                    logger.info(f"Resuming from previous progress: {len(all_augmented_data)} examples already processed")
                    # Skip already processed batches
                    if last_processed_index < len(data):
                        data = data[last_processed_index:]
                    else:
                        logger.info("All data was already processed in previous run")
                        return all_augmented_data
        except Exception as e:
            logger.warning(f"Could not load previous progress: {e}")
    
    # Add global timeout for the entire batch process
    max_batch_time = 3600  # 1 hour max per batch
    
    # Process data in batches
    for i in range(0, len(data), args.batch_size):
        batch = data[i:i+args.batch_size]
        current_batch_num = i//args.batch_size + 1
        total_batches = (len(data)-1)//args.batch_size + 1
        
        # Reset batch timer
        batch_start_time = time.time()
        
        logger.info(f"Processing batch {current_batch_num}/{total_batches} ({len(batch)} examples)")
        
        # Add progress heartbeat for monitoring
        logger.info(f"HEARTBEAT: Starting batch {current_batch_num}/{total_batches} at {time.strftime('%Y-%m-%d %H:%M:%S')}")
        
        # Generate augmented examples with timeout protection
        try:
            # Set a watchdog timer for this batch
            batch_timeout = time.time() + max_batch_time
            
            # Call API with retry logic built in
            result = call_ai_api(batch, args)
            
            # Check if we've exceeded the batch timeout
            if time.time() > batch_timeout:
                logger.error(f"Batch {current_batch_num} processing timed out after {max_batch_time} seconds")
                consecutive_failures += 1
                if consecutive_failures >= max_consecutive_failures:
                    logger.error(f"Too many consecutive failures ({consecutive_failures}). Saving progress and exiting.")
                    break
                continue
            
            if not result:
                logger.warning(f"Failed to generate augmentations for batch {current_batch_num}")
                consecutive_failures += 1
                if consecutive_failures >= max_consecutive_failures:
                    logger.error(f"Too many consecutive failures ({consecutive_failures}). Saving progress and exiting.")
                    break
                continue
            
            # Parse the result
            parsed_result = extract_and_parse_json(result)
            
            if not parsed_result:
                logger.warning(f"Failed to parse augmented data for batch {current_batch_num}")
                consecutive_failures += 1
                if consecutive_failures >= max_consecutive_failures:
                    logger.error(f"Too many consecutive failures ({consecutive_failures}). Saving progress and exiting.")
                    break
                continue
            
            if not isinstance(parsed_result, list):
                logger.warning(f"Unexpected result format: {type(parsed_result)} (expected list)")
                consecutive_failures += 1
                if consecutive_failures >= max_consecutive_failures:
                    logger.error(f"Too many consecutive failures ({consecutive_failures}). Saving progress and exiting.")
                    break
                continue
            
            # Reset failure counter on success
            consecutive_failures = 0
            
            logger.info(f"Generated {len(parsed_result)} augmented examples")
            all_augmented_data.extend(parsed_result)
            
            # Add heartbeat after successful processing
            logger.info(f"HEARTBEAT: Completed batch {current_batch_num}/{total_batches} at {time.strftime('%Y-%m-%d %H:%M:%S')}")
            
            # Save progress periodically
            current_time = time.time()
            if current_time - last_progress_save_time > progress_save_interval * 60:  # Save every X minutes
                try:
                    with open(progress_file, 'w') as f:
                        progress_data = {
                            'augmented_data': all_augmented_data,
                            'last_processed_index': i + args.batch_size,
                            'timestamp': time.strftime('%Y-%m-%d %H:%M:%S')
                        }
                        json.dump(progress_data, f)
                    logger.info(f"Saved progress: {len(all_augmented_data)} examples processed so far")
                    last_progress_save_time = current_time
                except Exception as e:
                    logger.error(f"Failed to save progress: {e}")
            
            # Add some delay to avoid rate limits
            time.sleep(1)
            
        except Exception as e:
            logger.error(f"Error processing batch {current_batch_num}: {e}")
            consecutive_failures += 1
            if consecutive_failures >= max_consecutive_failures:
                logger.error(f"Too many consecutive failures ({consecutive_failures}). Saving progress and exiting.")
                break
            continue
        
        # Check if this batch took too long - log a warning
        batch_duration = time.time() - batch_start_time
        if batch_duration > 300:  # 5 minutes per batch is suspicious
            logger.warning(f"Batch {current_batch_num} took {batch_duration:.1f} seconds to process, which is longer than expected")
    
    # Final progress save
    try:
        with open(progress_file, 'w') as f:
            progress_data = {
                'augmented_data': all_augmented_data,
                'last_processed_index': len(data),
                'timestamp': time.strftime('%Y-%m-%d %H:%M:%S'),
                'completed': True
            }
            json.dump(progress_data, f)
        logger.info(f"Saved final progress: {len(all_augmented_data)} examples processed")
    except Exception as e:
        logger.error(f"Failed to save final progress: {e}")
    
    return all_augmented_data

def setup_signal_handlers():
    """Set up signal handlers for graceful shutdown"""
    import signal
    import sys
    
    # Global flag to indicate if we're shutting down
    global shutting_down
    shutting_down = False
    
    def signal_handler(sig, frame):
        global shutting_down
        if shutting_down:
            logger.warning("Received second interrupt signal, exiting immediately.")
            sys.exit(1)
        
        shutting_down = True
        logger.warning("Received interrupt signal, shutting down gracefully...")
        logger.warning("The script will save progress at the next opportunity and exit.")
        logger.warning("Send interrupt signal again to force immediate exit.")
    
    # Register signal handlers
    signal.signal(signal.SIGINT, signal_handler)  # Handles Ctrl+C
    signal.signal(signal.SIGTERM, signal_handler)  # Handles termination signal
    
    return shutting_down

def main():
    # Set up signal handlers for graceful shutdown
    global shutting_down
    shutting_down = setup_signal_handlers()
    
    # Add script runtime monitor
    start_time = time.time()
    
    # Get command line arguments
    args = parse_args()
    
    # Set random seed for reproducibility
    random.seed(args.seed)
    
    # Create output directory if it doesn't exist
    os.makedirs(os.path.dirname(args.output_path), exist_ok=True)
    
    # Create logs directory for storing debug information
    logs_dir = Path("./build/logs")
    logs_dir.mkdir(parents=True, exist_ok=True)
    logger.info(f"Debug logs will be saved to: {logs_dir}")
    
    # Add a watchdog timer log file to detect hanging
    watchdog_file = logs_dir / "watchdog.log"
    with open(watchdog_file, 'w') as f:
        f.write(f"Script started at: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
    
    # Load data
    data = load_data(args.input_path)
    
    # Show some stats
    logger.info(f"Input data: {len(data)} examples")
    logger.info(f"Augmentation factor: {args.augment_factor}")
    logger.info(f"Target total: {len(data) * (args.augment_factor + 1)} examples")
    
    # Update watchdog after loading data
    with open(watchdog_file, 'a') as f:
        f.write(f"Data loaded at: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
    
    try:
        # Generate augmentations with progress tracking
        logger.info("Starting data augmentation process...")
        
        # Generate augmentations
        augmented_data = augment_data_in_batches(data, args)
        
        # Check if we're shutting down
        if shutting_down:
            logger.warning("Shutdown requested, finalizing process...")
            # Save partial results
            interim_output = args.output_path.replace('.json', f'_partial_{int(time.time())}.json')
            save_data(data + augmented_data, interim_output)
            logger.info(f"Partial results saved to: {interim_output}")
            return
        
        # Update watchdog after augmentation
        with open(watchdog_file, 'a') as f:
            f.write(f"Augmentation completed at: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
        
        # Combine original and augmented data
        combined_data = data + augmented_data
        
        # Shuffle the data
        random.shuffle(combined_data)
        
        # Save the combined data
        save_data(combined_data, args.output_path)
        
        # Update watchdog after saving
        with open(watchdog_file, 'a') as f:
            f.write(f"Data saved at: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
            
        # Calculate and log script runtime
        runtime_minutes = (time.time() - start_time) / 60
        
        # Print summary
        logger.info("=" * 50)
        logger.info(f"Data augmentation complete!")
        logger.info(f"Original examples: {len(data)}")
        logger.info(f"Augmented examples: {len(augmented_data)}")
        logger.info(f"Total examples: {len(combined_data)}")
        logger.info(f"Output saved to: {args.output_path}")
        logger.info(f"Total runtime: {runtime_minutes:.2f} minutes")
        logger.info("=" * 50)
        
        # Final watchdog update
        with open(watchdog_file, 'a') as f:
            f.write(f"Script completed successfully at: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"Total runtime: {runtime_minutes:.2f} minutes\n")
            
    except Exception as e:
        logger.error(f"Fatal error in main function: {e}")
        # Try to save progress in case of error
        try:
            error_output = args.output_path.replace('.json', f'_error_{int(time.time())}.json')
            save_data(data + augmented_data, error_output)
            logger.info(f"Emergency save to: {error_output}")
        except Exception as save_error:
            logger.critical(f"Could not save data after error: {save_error}")
        
        # Update watchdog with error
        with open(watchdog_file, 'a') as f:
            f.write(f"Script failed at: {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"Error: {e}\n")
        
        raise  # Re-raise the exception for proper exit code

if __name__ == "__main__":
    main()