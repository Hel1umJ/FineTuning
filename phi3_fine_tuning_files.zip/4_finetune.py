"""
Phi-3-mini Fine-tuning Script (Step 4)

This script fine-tunes the Phi-3-mini-4k-instruct model using LoRA.
It supports distributed training with DeepSpeed.

Usage:
    python 4_finetune.py --data_path ./build/data/train.json --output_dir ./build/model
"""

import os
import torch
import json
import argparse
import logging
import traceback
from typing import Dict, List, Optional
from dataclasses import dataclass, field
from pathlib import Path

# Set environment variables for optimal GPU performance
os.environ["CUDA_LAUNCH_BLOCKING"] = "1"  # Enable synchronous execution for debugging
os.environ["CUDA_VISIBLE_DEVICES"] = "0"  # Ensure we're using the primary GPU
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "max_split_size_mb:128"  # Adjust for better allocation
os.environ["OMP_NUM_THREADS"] = "16"  # Limit CPU threads
os.environ["MKL_NUM_THREADS"] = "16"  # Limit MKL threads 
os.environ["CUDA_DEVICE_MAX_CONNECTIONS"] = "1"  # Reduce concurrent CUDA operations

# Additional environment variables can be set here if needed

# GPU Status Check
def check_gpu_status():
    print("=" * 50)
    print("GPU STATUS CHECK")
    print("=" * 50)
    if torch.cuda.is_available():
        device_count = torch.cuda.device_count()
        print(f"CUDA Available: Yes, Devices: {device_count}")
        for i in range(device_count):
            device_name = torch.cuda.get_device_name(i)
            memory_total = torch.cuda.get_device_properties(i).total_memory / (1024**3)
            memory_allocated = torch.cuda.memory_allocated(i) / (1024**3)
            memory_free = memory_total - memory_allocated
            print(f"Device {i}: {device_name}")
            print(f"  Memory: {memory_total:.2f} GB total, {memory_allocated:.2f} GB allocated, {memory_free:.2f} GB free")
    else:
        print("CUDA Available: No")
    print("-" * 50)
    print(f"PyTorch version: {torch.__version__}")
    print(f"CUDA version: {torch.version.cuda if torch.cuda.is_available() else 'N/A'}")
    try:
        import flash_attn
        print(f"Flash Attention: Yes (version {flash_attn.__version__})")
    except ImportError:
        print("Flash Attention: Not installed")
    print("=" * 50)

# Run GPU check
if torch.cuda.is_available():
    check_gpu_status()

import transformers
from transformers import (
    AutoModelForCausalLM, 
    AutoTokenizer, 
    TrainingArguments,
    BitsAndBytesConfig
)
from peft import LoraConfig, get_peft_model, PeftModel

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger(__name__)

# Constants for training
IGNORE_INDEX = -100
DEFAULT_MODEL_ID = "microsoft/Phi-3-mini-4k-instruct"

@dataclass
class ModelArguments:
    model_id: Optional[str] = field(default=DEFAULT_MODEL_ID)

@dataclass
class CustomTrainingArguments(TrainingArguments):
    cache_dir: Optional[str] = field(default=None)
    optim: str = field(default="adamw_torch")
    adam_beta1: float = field(default=0.9)
    adam_beta2: float = field(default=0.999)
    adam_epsilon: float = field(default=1e-8)

    model_max_length: int = field(
        default=4096, # Default max_length for phi3-mini-4k-instruct
        metadata={
            "help": "Maximum sequence length. Sequences will be right padded (and possibly truncated)."
        },
    )

    double_quant: bool = field(
        default=True,
        metadata={"help": "Compress the quantization statistics through double quantization."}
    )
    quant_type: str = field(
        default="nf4",
        metadata={"help": "Quantization data type to use. Should be one of `fp4` or `nf4`."}
    )
    bits: int = field(
        default=16,
        metadata={"help": "How many bits to use."}
    )
    lora_enable: bool = False
    use_dora: bool = False
    lora_rank: int = 16
    lora_alpha: int = 16
    lora_dropout: float = 0.05
    lora_weight_path: str = ""
    lora_bias: str = "none"
    lora_modules_to_save: Optional[List[str]] = field(default=None)
    lora_target_modules: Optional[List[str]] = field(default=None)

@dataclass
class DataArguments:
    data_path: str = field(
        default=None, metadata={"help": "Path to the training data."}
    )
    lazy_preprocess: bool = False

def parse_args():
    parser = argparse.ArgumentParser(description="Fine-tune Phi-3-mini model")
    
    # Model arguments
    parser.add_argument("--model_id", type=str, default=DEFAULT_MODEL_ID,
                        help="Path to pretrained model or model identifier from huggingface.co/models")
    
    # Data arguments
    parser.add_argument("--data_path", type=str, required=True,
                        help="Path to the training data")
    parser.add_argument("--lazy_preprocess", action="store_true",
                        help="Whether to lazy preprocess the data")
    parser.add_argument("--model_max_length", type=int, default=4096,
                        help="Maximum sequence length for tokenization")
    
    # Output arguments
    parser.add_argument("--output_dir", type=str, default="./build/model",
                        help="Directory to save the model")
    
    # Training configuration
    parser.add_argument("--num_train_epochs", type=int, default=3,
                        help="Number of training epochs")
    parser.add_argument("--per_device_train_batch_size", type=int, default=4,
                        help="Batch size per device")
    parser.add_argument("--gradient_accumulation_steps", type=int, default=8,
                        help="Number of update steps to accumulate before backward pass")
    parser.add_argument("--learning_rate", type=float, default=1e-4,
                        help="Initial learning rate")
    parser.add_argument("--bf16", action="store_true",
                        help="Whether to use bf16 (mixed) precision")
    parser.add_argument("--fp16", action="store_true",
                        help="Whether to use fp16 (mixed) precision")
    parser.add_argument("--bits", type=int, default=16,
                        help="How many bits to use for quantization. Use 8 for memory-efficient training")
    
    # LoRA settings
    parser.add_argument("--lora_enable", action="store_true",
                        help="Enable LoRA for parameter-efficient fine-tuning")
    parser.add_argument("--lora_rank", type=int, default=16,
                        help="LoRA rank")
    parser.add_argument("--lora_alpha", type=int, default=16,
                        help="LoRA alpha")
    parser.add_argument("--lora_dropout", type=float, default=0.05,
                        help="LoRA dropout")
    parser.add_argument("--num_lora_modules", type=int, default=-1,
                        help="Number of modules to apply LoRA to (-1 for all)")
    parser.add_argument("--lora_target_modules", type=str, default=None,
                        help="Comma-separated list of module names to apply LoRA to")
    parser.add_argument("--lora_modules_to_save", type=str, default=None,
                        help="Comma-separated list of module names to save separately")
    
    # DeepSpeed configuration
    parser.add_argument("--deepspeed", type=str, default="./build/config/ds_config.json",
                        help="Path to DeepSpeed config file")
    
    args = parser.parse_args()
    
    # Create output directory if it doesn't exist
    os.makedirs(args.output_dir, exist_ok=True)
    
    return args

def find_all_linear_modules(model, exclude_keywords=None):
    """Find all linear modules in the model for LoRA application, optimized for your GPU"""
    if exclude_keywords is None:
        exclude_keywords = []
        
    target_modules = []
    
    # Priority modules that give the best value for LoRA adaptation
    priority_keywords = [
        "q_proj", "k_proj", "v_proj", "o_proj",  # Attention modules
        "gate_proj", "down_proj", "up_proj",  # MLP modules
        "lm_head",  # Output layer
        "dense", "fc",  # General dense layers
    ]
    
    priority_modules = []
    secondary_modules = []
    
    for name, module in model.named_modules():
        # Skip excluded modules
        if any(keyword in name for keyword in exclude_keywords):
            continue
            
        # Check if it's a linear layer
        if isinstance(module, torch.nn.Linear):
            # Separate into priority and secondary modules
            if any(keyword in name for keyword in priority_keywords):
                priority_modules.append(name)
            else:
                secondary_modules.append(name)
    
    # First add all priority modules
    target_modules.extend(priority_modules)
    
    # Then add secondary modules
    target_modules.extend(secondary_modules)
    
    return target_modules

def apply_lora_to_model(model, args):
    """Apply LoRA configuration to model"""
    exclude_modules = []
    
    # Handle special modules to exclude or include
    if args.lora_target_modules:
        # Convert string to list if needed
        if isinstance(args.lora_target_modules, str):
            try:
                import ast
                args.lora_target_modules = ast.literal_eval(args.lora_target_modules)
            except:
                args.lora_target_modules = args.lora_target_modules.split(',')
        target_modules = args.lora_target_modules
    else:
        # Find all linear modules
        target_modules = find_all_linear_modules(model, exclude_modules)
        
        # Limit number of modules if specified
        if hasattr(args, 'num_lora_modules') and args.num_lora_modules > 0:
            target_modules = target_modules[:args.num_lora_modules]
    
    logger.info(f"Applying LoRA to {len(target_modules)} modules")
    logger.info(f"Target modules: {target_modules[:5]}... (showing first 5)")
    
    # Process modules_to_save if provided
    modules_to_save = None
    if args.lora_modules_to_save:
        # Convert string to list if needed
        if isinstance(args.lora_modules_to_save, str):
            try:
                import ast
                modules_to_save = ast.literal_eval(args.lora_modules_to_save)
            except:
                modules_to_save = args.lora_modules_to_save.split(',')
        else:
            modules_to_save = args.lora_modules_to_save

    # Configure LoRA
    lora_config = LoraConfig(
        r=args.lora_rank,
        lora_alpha=args.lora_alpha,
        target_modules=target_modules,
        lora_dropout=args.lora_dropout,
        bias="none",
        task_type="CAUSAL_LM",
        modules_to_save=modules_to_save
    )
    
    # Apply LoRA
    model = get_peft_model(model, lora_config)
    
    # Print trainable parameters
    model.print_trainable_parameters()
    
    return model

def create_optimizer_groups(model, args):
    """Create optimizer parameter groups with different learning rates"""
    no_decay = ["bias", "LayerNorm.weight", "layer_norm.weight"]
    optimizer_grouped_parameters = []
    
    # Get all parameter names
    param_names = [name for name, _ in model.named_parameters() if _.requires_grad]
    
    # Regular parameters (base learning rate)
    regular_params = [
        {
            "params": [p for n, p in model.named_parameters() 
                      if n in param_names and not any(nd in n for nd in no_decay)],
            "weight_decay": args.weight_decay,
        },
        {
            "params": [p for n, p in model.named_parameters() 
                      if n in param_names and any(nd in n for nd in no_decay)],
            "weight_decay": 0.0,
        }
    ]
    optimizer_grouped_parameters.extend(regular_params)
    
    return optimizer_grouped_parameters

def get_peft_state_maybe_zero_3(named_params, bias):
    """Get the state dict of the PEFT model with DeepSpeed ZeRO-3 compatibility"""
    if bias == "none":
        to_return = {k: t for k, t in named_params if "lora_" in k}
    elif bias == "all":
        to_return = {k: t for k, t in named_params if "lora_" in k or "bias" in k}
    elif bias == "lora_only":
        to_return = {}
        maybe_lora_bias = {}
        lora_bias_names = set()
        for k, t in named_params:
            if "lora_" in k:
                to_return[k] = t
                bias_name = k.split("lora_")[0] + "bias"
                lora_bias_names.add(bias_name)
            elif "bias" in k:
                maybe_lora_bias[k] = t
        for k, t in maybe_lora_bias.items():
            if k in lora_bias_names:
                to_return[k] = t
    else:
        raise NotImplementedError
    return to_return

# Create dataset class
from torch.utils.data import Dataset
import torch

class TextDataset(Dataset):
    def __init__(self, data, tokenizer, model_max_length):
        self.data = data
        self.tokenizer = tokenizer
        self.model_max_length = model_max_length
    
    def __len__(self):
        return len(self.data)
    
    def __getitem__(self, idx):
        item = self.data[idx]
        instruction = item["instruction"]
        input_text = item["input"]
        output = item["output"]
        
        # Format as instruction
        if input_text:
            prompt = f"{instruction}\n{input_text}"
        else:
            prompt = instruction
            
        # Format with chat template
        messages = [
            {"role": "user", "content": prompt},
            {"role": "assistant", "content": output}
        ]
        
        # Apply chat template
        text = self.tokenizer.apply_chat_template(
            messages, 
            tokenize=False, 
            add_generation_prompt=False
        )
        
        return text

def process_and_tokenize_data(data_texts, tokenizer, model_max_length):
    """Process and tokenize the data texts"""
    processed_data = []
    
    for text in data_texts:
        # Tokenize the text
        tokenized = tokenizer(
            text,
            truncation=True,
            max_length=model_max_length,
            padding="max_length",
            return_tensors="pt"
        )
        
        # Prepare the labels (set padding tokens to -100)
        input_ids = tokenized["input_ids"][0]
        labels = input_ids.clone()
        
        # Set padding tokens to IGNORE_INDEX
        labels[labels == tokenizer.pad_token_id] = IGNORE_INDEX
        
        # Store processed item
        processed_item = {
            "input_ids": input_ids,
            "labels": labels,
            "attention_mask": tokenized["attention_mask"][0]
        }
        processed_data.append(processed_item)
    
    return processed_data

def collate_fn(batch):
    """Collate function for DataLoader"""
    # Stack the processed items into batches
    input_ids = torch.stack([item["input_ids"] for item in batch])
    labels = torch.stack([item["labels"] for item in batch])
    attention_mask = torch.stack([item["attention_mask"] for item in batch])
    
    return {
        "input_ids": input_ids,
        "labels": labels,
        "attention_mask": attention_mask
    }

def main():
    # Parse arguments
    args = parse_args()
    
    # Initialize tokenizer
    logger.info(f"Loading tokenizer from {args.model_id}")
    tokenizer = AutoTokenizer.from_pretrained(
        args.model_id, 
        trust_remote_code=True,
        use_fast=True
    )
    
    # Ensure padding token is set
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    
    # Set up model loading kwargs with memory optimization for your GPU
    model_kwargs = {
        "trust_remote_code": True,
        "device_map": None,  # Required for DeepSpeed compatibility
        "low_cpu_mem_usage": True,  # Optimize CPU memory usage
        "torch_dtype": torch.bfloat16 if args.bf16 else (torch.float16 if args.fp16 else torch.float32),
        "offload_folder": os.path.join(args.output_dir, "offload"),  # For temporary weight offloading if needed
    }
    
    # Additional memory optimizations
    if args.lora_enable:
        # For LoRA training, we can load model in 8-bit to save GPU memory
        if args.bits == 8:
            logger.info("Loading model in 8-bit mode for memory efficiency")
            quantization_config = BitsAndBytesConfig(
                load_in_8bit=True,
                llm_int8_threshold=6.0
            )
            model_kwargs["quantization_config"] = quantization_config
            del model_kwargs["torch_dtype"]  # Remove torch_dtype when using quantization
    
    # Create offload folder if it doesn't exist
    os.makedirs(os.path.join(args.output_dir, "offload"), exist_ok=True)
    
    # Load model
    # Load the model on CPU first to avoid GPU OOM during loading
    temp_model_kwargs = {
        "trust_remote_code": True,
        "torch_dtype": torch.bfloat16 if args.bf16 else (torch.float16 if args.fp16 else torch.float32),
    }
    
    logger.info(f"Loading model from {args.model_id}")
    # Critical for memory: Load in CPU first, then move to appropriate device by DeepSpeed
    model = AutoModelForCausalLM.from_pretrained(
        args.model_id,
        device_map="cpu",  # Force CPU loading initially
        low_cpu_mem_usage=True,  # Critical for large models
        **temp_model_kwargs
    )
    
    # Free up memory
    torch.cuda.empty_cache()
    
    # Apply LoRA if enabled
    if args.lora_enable:
        logger.info("Applying LoRA to model")
        model = apply_lora_to_model(model, args)
        
        # Print trainable parameters
        model.print_trainable_parameters()
    
    # Load dataset
    logger.info(f"Loading dataset from {args.data_path}")
    with open(args.data_path, 'r') as f:
        train_data = json.load(f)
    
    # Create data processor
    dataset = TextDataset(train_data, tokenizer, args.model_max_length)
    
    # Get all data texts
    data_texts = [dataset[i] for i in range(len(dataset))]
    
    # Process and tokenize data
    processed_data = process_and_tokenize_data(data_texts, tokenizer, args.model_max_length)
    
    # Create training arguments
    training_args = CustomTrainingArguments(
        output_dir=args.output_dir,
        num_train_epochs=args.num_train_epochs,
        per_device_train_batch_size=args.per_device_train_batch_size,
        gradient_accumulation_steps=args.gradient_accumulation_steps,
        learning_rate=args.learning_rate,
        logging_dir=os.path.join(args.output_dir, "logs"),
        logging_steps=10,
        save_steps=100,
        save_total_limit=2,
        bf16=args.bf16,
        fp16=args.fp16,
        torch_compile=False,  # This can cause issues with some models
        gradient_checkpointing=True,
        remove_unused_columns=False,
        dataloader_drop_last=True,
        dataloader_num_workers=4,
        optim="adamw_torch",
        weight_decay=0.0,
        adam_beta1=0.9,
        adam_beta2=0.999,
        adam_epsilon=1e-8,
        max_grad_norm=1.0,
        lr_scheduler_type="cosine",
        warmup_ratio=0.03,
        deepspeed=args.deepspeed,
        model_max_length=args.model_max_length,
        lora_enable=args.lora_enable,
        lora_rank=args.lora_rank,
        lora_alpha=args.lora_alpha,
        lora_dropout=args.lora_dropout,
    )
    
    # Initialize transformers Trainer
    from transformers import Trainer
    
    class CustomTrainer(Trainer):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
        
        def compute_loss(self, model, inputs, return_outputs=False):
            try:
                # Try using model forward
                outputs = model(**inputs)
                loss = outputs.loss
                
                return (loss, outputs) if return_outputs else loss
            except Exception as e:
                logger.error(f"Error in compute_loss: {e}")
                logger.error(traceback.format_exc())
                raise e
        
        def create_optimizer(self):
            """Create optimizer with parameter groups for different learning rates"""
            if self.optimizer is None:
                optimizer_grouped_parameters = create_optimizer_groups(
                    self.model, self.args
                )
                
                self.optimizer = torch.optim.AdamW(
                    optimizer_grouped_parameters,
                    lr=self.args.learning_rate,
                    betas=(self.args.adam_beta1, self.args.adam_beta2),
                    eps=self.args.adam_epsilon,
                    weight_decay=self.args.weight_decay,
                )
            
            return self.optimizer
    
    # Create dataset from processed data
    from torch.utils.data import DataLoader, Dataset
    
    class ProcessedDataset(Dataset):
        def __init__(self, processed_data):
            self.processed_data = processed_data
        
        def __len__(self):
            return len(self.processed_data)
        
        def __getitem__(self, idx):
            return self.processed_data[idx]
    
    train_dataset = ProcessedDataset(processed_data)
    
    # Initialize trainer
    trainer = CustomTrainer(
        model=model,
        args=training_args,
        train_dataset=train_dataset,
        data_collator=collate_fn,
    )
    
    # Optimize CUDA memory management
    if torch.cuda.is_available():
        # Empty cache and reset stats
        torch.cuda.empty_cache()
        torch.cuda.reset_peak_memory_stats()
        
        # Check initial memory usage
        allocated_mem = torch.cuda.memory_allocated() / (1024**3)  # in GB
        reserved_mem = torch.cuda.memory_reserved() / (1024**3)    # in GB
        logger.info(f"CUDA Memory before training: {allocated_mem:.2f} GB allocated, {reserved_mem:.2f} GB reserved")
        
        # Set up memory optimizations
        logger.info("Setting up CUDA caching allocator...")
        
        # Manual garbage collection to free memory
        import gc
        gc.collect()
        
        # Display available GPU memory
        try:
            free_mem = torch.cuda.get_device_properties(0).total_memory / (1024**3) - allocated_mem
            logger.info(f"Available GPU memory: {free_mem:.2f} GB")
        except Exception as e:
            logger.warning(f"Could not determine free memory: {e}")
    
    # Train model
    logger.info("Starting training")
    try:
        trainer.train()
        
        # Save model
        logger.info(f"Saving model to {args.output_dir}")
    except RuntimeError as e:
        if "CUDA out of memory" in str(e):
            logger.error("CUDA out of memory error. Try reducing batch size, sequence length, or LoRA rank.")
            # Print memory stats for debugging
            if torch.cuda.is_available():
                logger.error(f"CUDA Memory allocated: {torch.cuda.memory_allocated() / 1024**2:.2f} MB")
                logger.error(f"CUDA Memory reserved: {torch.cuda.memory_reserved() / 1024**2:.2f} MB")
            raise e
        else:
            logger.error(f"Training error: {e}")
            raise e
    
    # Save tokenizer
    tokenizer.save_pretrained(args.output_dir)
    
    if args.lora_enable:
        try:
            # For LoRA, just save the model directly with PEFT's save_pretrained
            logger.info("Saving LoRA adapter weights...")
            model.save_pretrained(args.output_dir)
        except Exception as e:
            logger.error(f"Error when saving LoRA model: {e}")
            logger.info("Training completed but model saving encountered an error.")
    else:
        # For full model, save the whole model
        trainer.save_model()
    
    logger.info("Training complete!")

if __name__ == "__main__":
    main()