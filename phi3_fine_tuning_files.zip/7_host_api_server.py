"""
Phi-3-mini API Server (Step 7)

This script starts a FastAPI server that hosts the fine-tuned Phi-3-mini model.
It supports both PyTorch and ONNX models and provides both REST and WebSocket endpoints.

Usage:
    python 7_host_api_server.py --model_path ./build/model --port 8000
"""

import os
import sys
import time
import torch
import logging
import argparse
import uuid
from typing import Dict, List, Optional, Union, Any
from pathlib import Path

# Configure logging
logging.basicConfig(
    level=logging.DEBUG,  # Change to DEBUG for more detailed logs
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger(__name__)

def parse_args():
    parser = argparse.ArgumentParser(description="Start API server for Phi-3-mini model")
    
    # Model loading arguments
    parser.add_argument("--model_path", type=str, required=True,
                        help="Path to the model directory (PyTorch or ONNX)")
    parser.add_argument("--base_model", type=str, default="microsoft/Phi-3-mini-4k-instruct",
                        help="Base model identifier (if needed)")
    parser.add_argument("--onnx", action="store_true",
                        help="Use ONNX model for inference")
    parser.add_argument("--load_8bit", action="store_true",
                        help="Load PyTorch model in 8-bit mode")
    parser.add_argument("--load_4bit", action="store_true",
                        help="Load PyTorch model in 4-bit mode")
    
    # Server configuration
    parser.add_argument("--host", type=str, default="0.0.0.0",
                        help="Host for API server")
    parser.add_argument("--port", type=int, default=8000,
                        help="Port for API server")
    parser.add_argument("--auth_token", type=str, default=None,
                        help="Authorization token for API access")
    parser.add_argument("--cors_origins", type=str, default="*",
                        help="Comma-separated list of allowed CORS origins")
    
    # Generation defaults
    parser.add_argument("--max_new_tokens", type=int, default=512,
                        help="Default maximum number of tokens to generate")
    parser.add_argument("--temperature", type=float, default=0.7,
                        help="Default temperature for generation")
    parser.add_argument("--top_p", type=float, default=0.9,
                        help="Default top-p sampling parameter")
    parser.add_argument("--repetition_penalty", type=float, default=1.1,
                        help="Default repetition penalty")
    
    args = parser.parse_args()
    
    return args

class InferenceEngine:
    """Base class for inference engines"""
    
    def __init__(self, model_path, args):
        self.model_path = model_path
        self.args = args
    
    async def generate(self, prompt, generation_args):
        """Generate text based on prompt"""
        raise NotImplementedError("Subclasses must implement this method")
    
    def shutdown(self):
        """Clean up resources"""
        pass

class PyTorchInferenceEngine(InferenceEngine):
    """Inference engine using PyTorch model"""
    
    def __init__(self, model_path, args):
        super().__init__(model_path, args)
        
        from transformers import AutoModelForCausalLM, AutoTokenizer
        
        # Set up model loading kwargs
        model_kwargs = {
            "trust_remote_code": True,
            "device_map": "auto",
        }
        
        # Configure quantization if requested
        if args.load_8bit:
            model_kwargs["load_in_8bit"] = True
            logger.info("Loading model in 8-bit mode")
        elif args.load_4bit:
            from transformers import BitsAndBytesConfig
            model_kwargs["quantization_config"] = BitsAndBytesConfig(
                load_in_4bit=True,
                bnb_4bit_compute_dtype=torch.bfloat16,
                bnb_4bit_quant_type="nf4",
                bnb_4bit_use_double_quant=True
            )
            logger.info("Loading model in 4-bit mode")
        else:
            # Use bfloat16 by default if available
            if torch.cuda.is_available() and torch.cuda.get_device_capability()[0] >= 8:
                model_kwargs["torch_dtype"] = torch.bfloat16
            else:
                model_kwargs["torch_dtype"] = torch.float16
        
        # Try to load tokenizer from model path
        try:
            self.tokenizer = AutoTokenizer.from_pretrained(model_path, trust_remote_code=True)
        except Exception as e:
            logger.warning(f"Could not load tokenizer from {model_path}: {e}")
            logger.info(f"Loading tokenizer from base model: {args.base_model}")
            self.tokenizer = AutoTokenizer.from_pretrained(args.base_model, trust_remote_code=True)
        
        # Check if model is a LoRA model
        is_lora_model = False
        try:
            adapter_config_path = os.path.join(model_path, "adapter_config.json")
            if os.path.exists(adapter_config_path):
                logger.info(f"Found adapter_config.json - model appears to be a LoRA model")
                is_lora_model = True
        except:
            pass
        
        # Load model
        try:
            # If it's a LoRA model, load base model first
            if is_lora_model and args.base_model:
                logger.info(f"Loading base model from {args.base_model} for LoRA")
                self.model = AutoModelForCausalLM.from_pretrained(
                    args.base_model,
                    **model_kwargs
                )
                
                # Then load LoRA adapters
                from peft import PeftModel
                logger.info(f"Loading LoRA weights from {model_path}")
                self.model = PeftModel.from_pretrained(self.model, model_path)
                
                # Merge weights if not using quantization
                if not args.load_8bit and not args.load_4bit:
                    logger.info("Merging LoRA weights with base model")
                    self.model = self.model.merge_and_unload()
            else:
                self.model = AutoModelForCausalLM.from_pretrained(
                    model_path,
                    **model_kwargs
                )
        except Exception as e:
            logger.error(f"Error loading model: {e}")
            raise e
    
    async def generate(self, prompt, generation_args):
        """Generate text based on prompt"""
        # Format as chat
        messages = [{"role": "user", "content": prompt}]
        
        # Apply chat template
        formatted_prompt = self.tokenizer.apply_chat_template(
            messages, 
            tokenize=False, 
            add_generation_prompt=True
        )
        
        # Tokenize
        inputs = self.tokenizer(
            formatted_prompt,
            return_tensors="pt"
        )
        inputs = {k: v.to(self.model.device) for k, v in inputs.items()}
        
        # Generate
        with torch.no_grad():
            outputs = self.model.generate(
                **inputs,
                eos_token_id=self.tokenizer.eos_token_id,
                pad_token_id=self.tokenizer.pad_token_id,
                **generation_args
            )
        
        # Decode
        generated_text = self.tokenizer.decode(
            outputs[0][inputs["input_ids"].shape[1]:],
            skip_special_tokens=True
        )
        
        return generated_text
    
    def shutdown(self):
        """Clean up resources"""
        # Free GPU memory
        if hasattr(self, 'model'):
            self.model = self.model.cpu()
            del self.model
            torch.cuda.empty_cache()

class ONNXInferenceEngine(InferenceEngine):
    """Inference engine using ONNX model with onnxruntime-genai for faster initialization"""
    
    def __init__(self, model_path, args):
        super().__init__(model_path, args)
        
        # Skip onnxruntime-genai attempt as it requires a different format
        # Go directly to standard ONNX implementation
        from transformers import AutoTokenizer
        from optimum.onnxruntime import ORTModelForCausalLM
        import onnxruntime as ort
        
        # Try to load tokenizer from model path
        try:
            self.tokenizer = AutoTokenizer.from_pretrained(model_path, trust_remote_code=True)
        except Exception as e:
            logger.warning(f"Could not load tokenizer from {model_path}: {e}")
            logger.info(f"Loading tokenizer from base model: {args.base_model}")
            self.tokenizer = AutoTokenizer.from_pretrained(args.base_model, trust_remote_code=True)
        
        # Load ONNX model
        try:
            # Use just one provider (CUDA if available, otherwise CPU)
            preferred_provider = "CUDAExecutionProvider" if torch.cuda.is_available() else "CPUExecutionProvider"
            logger.info(f"Using single provider: {preferred_provider}")
            
            self.model = ORTModelForCausalLM.from_pretrained(
                model_path,
                provider=preferred_provider,  # Use single preferred provider
                library_name="transformers",  # Explicitly set the library name to transformers
                use_cache=False,
                use_io_binding=False  # Disable IO binding when cache is disabled
            )
            logger.info("ONNX model loaded successfully with optimum/onnxruntime")
            self._use_optimum = True
        except Exception as e:
            logger.error(f"Error loading ONNX model: {e}")
            logger.warning(f"Failed to load with CUDA: {e}")
            logger.info("Falling back to CPU provider")
            try:
                self.model = ORTModelForCausalLM.from_pretrained(
                    model_path,
                    provider="CPUExecutionProvider",  # Fall back to CPU
                    library_name="transformers",
                    use_cache=False,
                    use_io_binding=False  # Disable IO binding when cache is disabled
                )
                logger.info("ONNX model loaded successfully with CPU")
                self._use_optimum = True
            except Exception as cpu_e:
                logger.error(f"Error loading ONNX model: {cpu_e}")
                raise cpu_e
    
    async def generate(self, prompt, generation_args):
        """Generate text based on prompt"""
        # Standard optimum/onnxruntime generation
        # Format as chat
        messages = [{"role": "user", "content": prompt}]
        
        # Apply chat template
        formatted_prompt = self.tokenizer.apply_chat_template(
            messages, 
            tokenize=False, 
            add_generation_prompt=True
        )
        
        # Process inputs (ONNX uses numpy arrays)
        inputs = self.tokenizer(
            formatted_prompt,
            return_tensors="np"
        )
        
        # Generate
        outputs = self.model.generate(
            **inputs,
            eos_token_id=self.tokenizer.eos_token_id,
            pad_token_id=self.tokenizer.pad_token_id,
            **generation_args
        )
        
        # Decode
        generated_text = self.tokenizer.decode(
            outputs[0][inputs["input_ids"].shape[1]:],
            skip_special_tokens=True
        )
        
        return generated_text

def create_api_server(engine, args):
    """Create FastAPI server for model inference"""
    try:
        from fastapi import FastAPI, Form, Request, Header, WebSocket, WebSocketDisconnect, HTTPException, Depends
        from fastapi.responses import JSONResponse, HTMLResponse
        from fastapi.middleware.cors import CORSMiddleware
        from fastapi.staticfiles import StaticFiles
        import uvicorn
    except ImportError:
        logger.error("FastAPI and uvicorn are required for API server. "
                     "Install with: pip install fastapi uvicorn")
        raise
    
    # Create FastAPI app
    app = FastAPI(title="Phi-3-mini API Server")
    
    # Add CORS middleware
    origins = args.cors_origins.split(",")
    app.add_middleware(
        CORSMiddleware,
        allow_origins=origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    
    # Set up default generation arguments
    default_generation_args = {
        "max_new_tokens": args.max_new_tokens,
        "temperature": args.temperature,
        "top_p": args.top_p,
        "do_sample": args.temperature > 0,
        "repetition_penalty": args.repetition_penalty
    }
    
    # Auth token middleware if specified
    async def verify_token(authorization: Optional[str] = Header(None)):
        if args.auth_token:
            if not authorization or authorization != f"Bearer {args.auth_token}":
                raise HTTPException(status_code=401, detail="Invalid authorization token")
        return True
    
    # Define static directory path
    static_dir = Path(__file__).parent / "static"
    
    # Ensure static directory exists
    os.makedirs(static_dir, exist_ok=True)
    
    # Mount static files
    app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")
    
    # Create WebSocket connection manager
    class ConnectionManager:
        def __init__(self):
            self.active_connections = {}
        
        async def connect(self, websocket: WebSocket, client_id: str):
            await websocket.accept()
            self.active_connections[client_id] = websocket
        
        def disconnect(self, client_id: str):
            if client_id in self.active_connections:
                del self.active_connections[client_id]
        
        async def send_json(self, client_id: str, data: Dict):
            if client_id in self.active_connections:
                await self.active_connections[client_id].send_json(data)
    
    manager = ConnectionManager()
    
    # API routes
    @app.get("/", response_class=HTMLResponse)
    async def get_root():
        # Serve the index.html from the static directory
        index_path = static_dir / "index.html"
        if index_path.exists():
            with open(index_path, "r") as f:
                return f.read()
        else:
            # Fallback if the file doesn't exist
            return """<!DOCTYPE html><html><body><h1>Phi-3 API Server</h1><p>The server is running.</p></body></html>"""
    
    @app.post("/generate", dependencies=[Depends(verify_token)])
    async def generate(
        prompt: str = Form(...),
        max_new_tokens: Optional[int] = Form(None),
        temperature: Optional[float] = Form(None),
        top_p: Optional[float] = Form(None),
        repetition_penalty: Optional[float] = Form(None)
    ):
        try:
            # Set up generation args
            gen_args = default_generation_args.copy()
            if max_new_tokens is not None:
                gen_args["max_new_tokens"] = max_new_tokens
            if temperature is not None:
                gen_args["temperature"] = temperature
                gen_args["do_sample"] = temperature > 0
            if top_p is not None:
                gen_args["top_p"] = top_p
            if repetition_penalty is not None:
                gen_args["repetition_penalty"] = repetition_penalty
            
            # Generate
            start_time = time.time()
            response = await engine.generate(prompt, gen_args)
            end_time = time.time()
            
            # Log timing information
            logger.info(f"Generation took {end_time - start_time:.2f} seconds")
            
            return {"response": response}
        
        except Exception as e:
            logger.error(f"Error in generate endpoint: {e}")
            return JSONResponse(
                status_code=500,
                content={"error": str(e)}
            )
    
    @app.post("/generate_json", dependencies=[Depends(verify_token)])
    async def generate_json(request: Request):
        try:
            # Parse request body
            data = await request.json()
            
            # Get prompt
            prompt = data.get("prompt", "")
            
            # Set up generation args
            gen_args = default_generation_args.copy()
            if "max_new_tokens" in data:
                gen_args["max_new_tokens"] = data["max_new_tokens"]
            if "temperature" in data:
                gen_args["temperature"] = data["temperature"]
                gen_args["do_sample"] = data["temperature"] > 0
            if "top_p" in data:
                gen_args["top_p"] = data["top_p"]
            if "repetition_penalty" in data:
                gen_args["repetition_penalty"] = data["repetition_penalty"]
            
            # Generate
            start_time = time.time()
            response = await engine.generate(prompt, gen_args)
            end_time = time.time()
            
            # Log timing information
            logger.info(f"Generation took {end_time - start_time:.2f} seconds")
            
            return {"response": response}
        
        except Exception as e:
            logger.error(f"Error in generate_json endpoint: {e}")
            return JSONResponse(
                status_code=500,
                content={"error": str(e)}
            )
    
    # WebSocket endpoint
    @app.websocket("/ws")
    async def websocket_endpoint(websocket: WebSocket):
        client_id = str(uuid.uuid4())
        await manager.connect(websocket, client_id)
        
        try:
            while True:
                message = await websocket.receive_text()
                
                try:
                    # Parse message as JSON
                    import json
                    data = json.loads(message)
                    
                    # Get prompt
                    prompt = data.get("prompt", "")
                    
                    # Set up generation args
                    gen_args = default_generation_args.copy()
                    if "max_new_tokens" in data:
                        gen_args["max_new_tokens"] = data["max_new_tokens"]
                    if "temperature" in data:
                        gen_args["temperature"] = data["temperature"]
                        gen_args["do_sample"] = data["temperature"] > 0
                    if "top_p" in data:
                        gen_args["top_p"] = data["top_p"]
                    if "repetition_penalty" in data:
                        gen_args["repetition_penalty"] = data["repetition_penalty"]
                    
                    # Generate
                    start_time = time.time()
                    response = await engine.generate(prompt, gen_args)
                    end_time = time.time()
                    
                    # Log timing information
                    logger.info(f"Generation took {end_time - start_time:.2f} seconds")
                    
                    # Send response
                    await manager.send_json(client_id, {"response": response})
                    
                except Exception as e:
                    logger.error(f"Error processing WebSocket message: {e}")
                    await manager.send_json(client_id, {"error": str(e)})
        
        except WebSocketDisconnect:
            manager.disconnect(client_id)
        except Exception as e:
            logger.error(f"WebSocket error: {e}")
            manager.disconnect(client_id)
    
    # Health check endpoint
    @app.get("/health")
    async def health_check():
        return {"status": "ok"}
    
    # Return the app
    return app

def main():
    args = parse_args()
    
    # Create inference engine
    if args.onnx:
        engine = ONNXInferenceEngine(args.model_path, args)
    else:
        engine = PyTorchInferenceEngine(args.model_path, args)
    
    # Create API server
    app = create_api_server(engine, args)
    
    # Run server
    logger.info(f"Starting API server at http://{args.host}:{args.port}")
    import uvicorn
    
    # Print a clear message for the user
    print("\n" + "="*70)
    print(f"API SERVER IS RUNNING AT: http://{args.host}:{args.port}")
    print("Visit this URL in your browser or use the following curl command to test:")
    print('curl -X POST "http://localhost:8000/generate" -F "prompt=What is machine learning?" -F "temperature=0.7"')
    print("Press CTRL+C to stop the server")
    print("="*70 + "\n")
    
    try:
        uvicorn.run(app, host=args.host, port=args.port)
    finally:
        # Clean up resources
        engine.shutdown()

if __name__ == "__main__":
    main()